
/* this function is used to get the ticket details from zoho */
function getTiketDetails(module_api_name,record_id)
{ 

	var ext = localStorage.getItem("domain_extension");
	var reqObj= {
     url : 'https://www.zohoapis.'+ext+'/crm/v2/'+module_api_name+'/'+record_id,
      headers : { 'Content-Type' : 'application/json' },
      type : 'GET',
      data : {}, 
      postBody : {},
      fileObj: [],
      connectionLinkName: "zohodeskcon"
	} 
	ZOHODESK.request( reqObj ).then(function(response){ 
	//	hide_loader();
	var responseArr = JSON.parse(response);
	var dataArrJson = responseArr.response; 
	var dataArr = JSON.parse(dataArrJson);
	
	var accountDataArr = dataArr.statusMessage.data;
	if(accountDataArr != undefined){
		for (var i = 0; i < accountDataArr.length; i++) {   
			var Simpro_Site_Id = accountDataArr[i].Simpro_Site_Id; 
			////console.log(Simpro_Site_Id);
			$("#Simpro_Site_Id").val(Simpro_Site_Id);  
			if(Simpro_Site_Id != "")
			break;
		}
	}
	}).catch(function(err){ 
		//console.log(err);
$('#Hidden_Message_Log').text(err); 
	})
}


/* this function is used to show the message on popup */

function modalPopup(status,message)
{ 
	ZOHODESK.showpopup({ 
	    title : "Alert Message",
	    content: message, 
	    type : "alert",
	    contentType : "html", 
	    color : "red", 
	    okText : "Close",
	    cancelText : ""
	}).then(res=>{
	    //console.log("success"); 
	    location.reload();
	},(err)=>{
	    //console.log(err);
	    location.reload();
	}); 
}

/* this function is used to show the message on popup related to update status */

function update_status(tick,refresh=1)
{

	
	hide_loader();  
	if(refresh == 1){ 
		status == "1";
		var message = "SimPRO Status Updated Successfully! ";
		modalPopup(status,message); 
		 location.reload();
	}else
	{
		 location.reload();
	}
							
	
}
 

/* this function is used to update the newly createde quote/job in zohodesk */
function updateticket(ticket_id,updateData,refresh=1)
{ 
	var ext = localStorage.getItem("domain_extension");
	var reqObj= {
		url : 'https://desk.zoho.'+ext+'/api/v1/tickets/'+ticket_id,
		headers : { 'Content-Type' : 'application/json' },
		type : 'PATCH',
		data : {},
		postBody : updateData,
		fileObj: [],
		connectionLinkName: "zohodeskcon"
	}   
	ZOHODESK.request( reqObj ).then(function(response){   
		//console.log(response);
		hide_loader();   
		hide_jobloader();   
		if(refresh == 1){
			modalPopup(status=1,message="Desk Ticket Updated Successfully!");
			// alert("Desk Ticket Updated Successfully! "); 
			 location.reload();
		}else
		{
			 location.reload();
		} 			
	}).catch(function (err) { 
		console.log(err);
$('#Hidden_Message_Log').text(err); 
	}); 
}


/* this function is used to get the thread data to find first thread data */

function getthreadData(ticket_id)
{ 
	var ext = localStorage.getItem("domain_extension");
	var reqObj= {
		url : 'https://desk.zoho.'+ext+'/api/v1/tickets/'+ticket_id+'/threads',
		headers : { 'Content-Type' : 'application/json' },
		type : 'GET',
		data : {},
		postBody : {},
		fileObj: [],
		connectionLinkName: "zohodeskcon"
	}  
	ZOHODESK.request( reqObj ).then(function(response){ 
	    
			var responseArr = JSON.parse(response);
			var dataArrJson = responseArr.response; 
			var dataArr = JSON.parse(dataArrJson);
			var threadDataArr = dataArr.statusMessage.data;  
			if(threadDataArr.length > 0){
						var messageIndex = threadDataArr.length - 1; 
						if(threadDataArr[messageIndex].hasAttribute('summary'))
						$("#description").val(threadDataArr[messageIndex].summary);
				}
			// hide_loader();
			// var updateData = {"description":threadDataArr[messageIndex].summary};
			// updateticket(ticket_id,updateData,0); 
	}).catch(function (err) { 
		//console.log(err);
$('#Hidden_Message_Log').text(err); 
	}); 
}


/* this function is used to show the loader */
function show_loader(){
	$("#loader").addClass("spinner-border");
  //event.preventDefault();
}

/* this function is used to hide the loader */
function hide_loader(){
	$("#loader").removeClass("spinner-border");
  //event.preventDefault();
} 

/* this function is used to show the job loader */
function show_jobloader(){
	$("#jobloader").addClass("spinner-border"); 
}

/* this function is used to hide the job loader */
function hide_jobloader(){
	$("#jobloader").removeClass("spinner-border"); 
} 

/* this function is used to get customer full details from simpro */
function getCustomerFullDetail(globarr,full_detail_link){

	if(globarr.simprodomain.includes("simprosuite") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com';
	}
	else if(globarr.simprodomain.includes("simprocloud") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com';
	}


	 var reqObj= {
	     url : baseurl+''+full_detail_link,
	     headers : { 'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
	     type : 'GET',
	     data : {},
	     postBody : {},
	     fileObj: [],
	     // connectionLinkName: "zohodeskcon"
	}     
	ZOHODESK.request( reqObj ).then(function(response)
	{  
		var responseArr = JSON.parse(response);
		var dataArrJson = responseArr.response; 
		var customerfulldataArr = JSON.parse(dataArrJson);   
		// //console.log(customerfulldataArr.ID);
		if(customerfulldataArr.hasOwnProperty('ID')){
				$("#simpro_customer_id").val(customerfulldataArr.ID);
				cusotmerSites = customerfulldataArr.Sites; 

				$("#Simpro_Site_name_val").empty();
				if(cusotmerSites.length > 0)
				{


counti = 0;
		for (var i = 0; i < cusotmerSites.length; i++) {

			var Simpro_Site_Id = cusotmerSites[i].ID;
			var Simpro_Site_Name = cusotmerSites[i].Name;
			counti = counti + 1;


			if(counti == 1)
			{
			$('#Simpro_Site_name_val').append($("<option></option>").attr("value", Simpro_Site_Id).attr("selected","selected").text(Simpro_Site_Name));

			$("#simpro_customer_site_id").val(Simpro_Site_Id);  

			}
			else
			{
			 $('#Simpro_Site_name_val').append($("<option></option>").attr("value", Simpro_Site_Id).text(Simpro_Site_Name));
			} 

		}

					// var customerSite = cusotmerSites[0].ID; 
					// $("#simpro_customer_site_id").val(customerSite); 
				}
				else{

default_site_name(globarr);
						// $('#Simpro_Site_name_val').append($("<option></option>").attr("value", "").text(globarr.default_site_name_simpro));
					  // $("#simpro_customer_site_id").val(); 
				} 
				 hide_loader(); 
		     hide_jobloader();
		 }
		 else{
				$("#simpro_customer_id").val();
		 }
	}).catch(function(err){ 
		//console.log(err);
$('#Hidden_Message_Log').text(err); 
	}) 
}  	 

/* this function is used to check the default site in simpro */

function default_site_name(globarr)
{
	var ext = localStorage.getItem("domain_extension");


	if(globarr.simprodomain.includes("simprosuite") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com';
	}
	else if(globarr.simprodomain.includes("simprocloud") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com';
	}

	var reqObj= 
	{  
      url : baseurl+'/api/v1.0/companies/'+globarr.company_id+'/sites/'+globarr.default_site_id,
      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
      type : 'GET',
      data : {},
	  postBody : {},
	  fileObj: [],
	}
		//console.log(reqObj);

	ZOHODESK.request( reqObj ).then(function(response){ 

	var responseArr = JSON.parse(response);
	var dataArrJson = responseArr.response; 
	var dataArr = JSON.parse(dataArrJson); 

	//console.log(dataArr);
	globarr.default_site_name_simpro = dataArr.Name;

	if(dataArr.errors != '' && dataArr.errors != undefined )
	{ 
		simproerrors = dataArr.errors;  
		$('#Quote_Message_Log').text("");
		if(simproerrors.length > 0){
		for (var i = 0; i < simproerrors.length; i++) { 
		$('#Quote_Message_Log').append("Default Site not found for this Site ID - "+globarr.default_site_id);  
		}
		hide_loader();   
		} 
	}
	else
	{
		globarr.default_site_name_simpro = dataArr.Name;
	$('#Simpro_Site_name_val').append($("<option></option>").attr("value", "").text(globarr.default_site_name_simpro));
	$("#Simpro_Site_Id").val(""); 
	
	}


	}).catch(function(err){
	      // Error handling
	  console.log(err);
		hide_loader();
	})


}

/* this function is used to check the default site in simpro */

function default_site_name_check(globarr)
{
	var ext = localStorage.getItem("domain_extension");


	if(globarr.simprodomain.includes("simprosuite") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com';
	}
	else if(globarr.simprodomain.includes("simprocloud") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com';
	}

	var reqObj= 
	{  
      url : baseurl+'/api/v1.0/companies/'+globarr.company_id+'/sites/'+globarr.default_site_id,
      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
      type : 'GET',
      data : {},
	  postBody : {},
	  fileObj: [],
	}
	
	ZOHODESK.request( reqObj ).then(function(response){ 

	var responseArr = JSON.parse(response);
	var dataArrJson = responseArr.response; 
	var dataArr = JSON.parse(dataArrJson); 
	globarr.default_site_name_simpro = dataArr.Name;

	if(dataArr.errors != '' && dataArr.errors != undefined )
	{ 
		simproerrors = dataArr.errors;  
		$('#Quote_Message_Log').text("");
		if(simproerrors.length > 0){
		for (var i = 0; i < simproerrors.length; i++) { 
		$('#Quote_Message_Log').append("Default Site not found for this Site ID - "+globarr.default_site_id);  
		}
		hide_loader();   
		} 
	}
	else
	{
	
	}
	

	}).catch(function(err){
	      // Error handling
	  console.log(err);
		hide_loader();
	})


}


/* this function is used to check passed perameter is number or not */
function isNumber(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}


/* this function is used to check passed string is parseable */

const IsParsable = (data) => {
  try {
        JSON.parse(data);
       } catch (e) {
        return false;
      }
   return true;
}

/* this function is used to display the response errors */

function print_errors(errors,display_field){ 
  var responseText = errors.responseText; 
  var parseable = IsParsable (responseText) ?  true : false;
  if(parseable){
    var responseTextJSON = JSON.parse(responseText);
    var simproerrors = responseTextJSON.errors;
    if(simproerrors.length > 0){
      for (var i = 0; i < simproerrors.length; i++) { 
        $('#'+display_field).text(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
      }    
    } 
  }
  if(errors.hasOwnProperty('statusText'))
  { 
    $('#'+display_field).append(" simPRO Status:"+errors.statusText+" OR Please also check if your configuration is correct.");
  }
  hide_loader();
  hide_jobloader();
}


/* this function is used to getcustomer full detail */


function getCustomerFullDetail_FRomContact(globarr,full_detail_link)
{  

	if(globarr.simprodomain.includes("simprosuite") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com';
	}
	else if(globarr.simprodomain.includes("simprocloud") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com';
	}

	var reqObj= {
		  url : baseurl+''+full_detail_link,
		  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
		  type : 'GET',
		  data : {},
			postBody : {}
	}
	ZOHODESK.request( reqObj ).then(function(response)
	{ 
		 
		var responseArr = JSON.parse(response);
		if(responseArr.statusCode == 401)
  	{
  		token_message();
  	}
		var dataArrJson = responseArr.response; 
		var results = JSON.parse(dataArrJson);   
		 if(results.hasOwnProperty('ID')){  
      var Customers = results.Customers;
      if(Customers.length > 0)
        { 
          $("#simpro_customer_id").val(Customers[0].ID);
          globarr.simpro_customer_id = Customers[0].ID; 
		      if(Customers[0].hasOwnProperty('CompanyName') && Customers[0].CompanyName != "" && Customers[0].GivenName == "") 
		      var full_cust_ttpe = "companies";
		      if(Customers[0].hasOwnProperty('GivenName') && Customers[0].GivenName != "")  
		      var full_cust_ttpe = "individuals"; 

					var full_detail_link_new = "/api/v1.0/companies/"+globarr.company_id+"/customers/"+full_cust_ttpe+"/"+Customers[0].ID;
					getCustomerFullDetail(globarr,full_detail_link_new); 
				} 
        else
	      {
	        globarr.simpro_customer_site_id = null; 
	        hide_loader(); 
     			hide_jobloader();
	      }   
    }
	}).catch(function(err){  
		//console.log(err);
$('#Hidden_Message_Log').text(err);  
	})  
} 


/* this function is used to search customer in contact */
var search_customer_in_contact = function search_customer_in_contact(globarr)
{ 
	return new Promise(function(resolve, reject)
	 {   
	 	//var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
	 	if(globarr.simprodomain.includes("simprosuite") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
	}
	else if(globarr.simprodomain.includes("simprocloud") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
	}

		var reqObj= {
			  url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/contacts/?Email='+globarr.email,
			  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
			  type : 'GET',
			  data : {},
				postBody : {}
			} 
	  ZOHODESK.request( reqObj ).then(function(response)
		{ 
		 resolve(response); 
	  }).catch(function(err){ 
	     reject(err); 
		}) 
	})  
}

/* this function is used to search customer in contact */

function search_customer_incontacts(globarr)
{
  search_customer_in_contact(globarr).then(
        function(results) {
        	//console.log(results);

        	//globarr.default_site_name_simpro
        	var responseArr = JSON.parse(results); 
					if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
					var dataArrJson = responseArr.response; 
					var dataArr = JSON.parse(dataArrJson); 
        	//console.log(dataArr);
          if(dataArr.length > 0)
            { 
              for (var i = 0; i < dataArr.length; i++) {  
                var full_detail_link= "/api/v1.0/companies/"+globarr.company_id+"/contacts/"+dataArr[i]['ID']; 
                globarr.contact_id = dataArr[i]['ID']; 
                getCustomerFullDetail_FRomContact(globarr,full_detail_link); 
                break;
              } 
            }
            else{

                  $("#simpro_customer_id").val("");
                  default_site_name(globarr);
                  // $('#Simpro_Site_name_val').append($("<option></option>").attr("value", "").text(globarr.default_site_name_simpro));
					  			// $("#simpro_customer_site_id").val(); 
                  hide_loader();
                  hide_jobloader();

            }  
        },
        function(errors) {
          print_errors(errors,"Quote_Message_Log");
        }
      ).catch(err => {   
			//console.log(err);
$('#Hidden_Message_Log').text(err); 
  });  
}


/* this function is used to search customer in customers */


var search_customer = function search_customer(globarr)
{    
	 return new Promise(function(resolve, reject)
	 {    
	 //	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
	 	if(globarr.simprodomain.includes("simprosuite") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
	}
	else if(globarr.simprodomain.includes("simprocloud") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
	}

		var reqObj= {
			  url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/customers/?Email='+globarr.email,
			  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
			  type : 'GET',
			  data : {},
				postBody : {}
			}   
	  ZOHODESK.request( reqObj ).then(function(response)
		{  
			 resolve(response); 
	  }).catch(function(err){  
			//console.log(err);
$('#Hidden_Message_Log').text(err); 
		    reject(err); 
		}) 
	 }) 
}

/* this function is used to display message */

function token_message()
{ 
	ZOHODESK.showpopup({ 
	    title : "Alert Message",
	    content: "Invalid api key! or please check your config settings properly!", 
	    type : "alert",
	    contentType : "html", 
	    color : "red", 
	    okText : "Close",
	    cancelText : ""
	}).then(res=>{
			location.reload();
	    //console.log("success");  
	    return; 
	},(err)=>{
	    //console.log(err); 
	}); 
	return;  
}


/* this function is used to display message */


function key_message(msg_con)
{ 
	ZOHODESK.showpopup({ 
	    title : "Alert Message",
	    content: msg_con, 
	    type : "alert",
	    contentType : "html", 
	    color : "red", 
	    okText : "Close",
	    cancelText : ""
	}).then(res=>{
			location.reload();
	    //console.log("success");  
	    return; 
	},(err)=>{
	    //console.log(err); 
	}); 
	return;  
}


/* this function is used to display custom message */

function company_site_customer_message()
{ 
	ZOHODESK.showpopup({ 
	    title : "Alert Message",
	    content: "Please check your config setting values of default site and default cusotmer for simpro companies!", 
	    type : "alert",
	    contentType : "html", 
	    color : "red", 
	    okText : "Close",
	    cancelText : ""
	}).then(res=>{
	    //console.log("success");  
	},(err)=>{
	    //console.log(err); 
	}); 
	return;  
}


/* this function is used to search customer */


function searchcustomer(globarr)
{ 
  	search_customer(globarr).then(
        function(results) { 
        	var responseArr = JSON.parse(results); 
        	if(responseArr.statusCode == 401)
        	{
        		token_message();
        	}
					var dataArrJson = responseArr.response; 
					var dataArr = JSON.parse(dataArrJson);  
					
            if(dataArr.length > 0)
            { 
              for (var i = 0; i < dataArr.length; i++) {  
                $("#simpro_customer_id").val(dataArr[i]['ID']);
                globarr.simpro_customer_id = dataArr[i]['ID']; 
                var full_detail_link = dataArr[i]['_href']; 
                getCustomerFullDetail(globarr,full_detail_link); 

                break;
              } 
            }
            else
            {   
              search_customer_incontacts(globarr);
            } 
        },
        function(errors) {
          print_errors(errors,"Quote_Message_Log");
        }
      ).catch(err => {  
		//console.log(err);
$('#Hidden_Message_Log').text(err);  
  });  
}

window.onload = function () {
	let DefaultSiteArr = []; 
	let comapnyIdArr = [];
	let DefaultCustomerArr = [];
	var globarr = {};
	show_loader();  

	const myTimeout = setTimeout(myGreeting, 5000); 

	function myGreeting() {
	    hide_loader(myTimeout);
	}  

	hide_jobloader(); 



/* this function is used when extension loads */

	ZOHODESK.extension.onload().then(function (App) 
	{   
		var domainMap = new Map();
		domainMap.set("US","com");
		domainMap.set("EU","eu"); 
		domainMap.set("AU","com.au"); 
		let currentDomain = App.meta.dcType;  
		localStorage.setItem("domain_extension", domainMap.get(currentDomain));
		globarr.domain_extension = currentDomain;


/* below function is used to read extension config */
		ZOHODESK.get("extension.config").then(function(response)
		{ 
			  // response returns the installation parameters of the extension 

				var configArr = response['extension.config'];  
				//console.log(configArr)
				var coufig_counter = 1;
				var first_company_id = 0;
				var multicompany = false;
				for (var i = 0; i < configArr.length; i++) 
				{   
					if("default_site_id" == configArr[i].name)
					{
						var sitesArr = configArr[i].value;
						var sarray = sitesArr.split(',');  
						$.each(sarray,function(j)
						{  
							if(!isNumber(sarray[j])){
						           var _default_site_error = "Please check the configuration settings... Please set value for default sites only number as comma seperated.";
						            $('#Quote_Message_Log').text(_default_site_error); 
						            $('#Job_Message_Log').text(_default_site_error);  
						            hide_loader();
						            return; 
						   }
						   else{
						   	DefaultSiteArr[j] = sarray[j];
								if(j === 0){ 
							    $('#Default_Site_ID').append($("<option></option>")
					              .attr("value", sarray[j])
					              .attr("selected","selected")
					              .text(sarray[j]));    
							    globarr.default_site_id = sarray[j];
								}
								else
								{
								  $('#Default_Site_ID').append($("<option></option>")
					              .attr("value", sarray[j])
					              .text(sarray[j])); 
								}
						   }
							
						}); 
					
					}  
			if("simpro_api_key" == configArr[i].name)
					{					
						globarr.simpro_api_key = configArr[i].value;
 
					}  
					if("default_customer_type" == configArr[i].name)
					{
						$("#Default_Customer_Type").val(configArr[i].value); 
						globarr.default_customer_type = configArr[i].value;
						let default_customer_type = configArr[i].value;
						if(default_customer_type.toLowerCase() != "companies" && default_customer_type.toLowerCase() != "individuals")
						{
							let default_customer_type_error = "Please check the value for customer type in configuration settings... Please set only the values companies Or individuals"; 							
							$('#Quote_Message_Log').text(default_customer_type_error); 
					    $('#Job_Message_Log').text(default_customer_type_error);
				      hide_loader();
							return true; 
						}

					} 
					if("Create_Customer_Check" == configArr[i].name)
				  { 
				    	var Create_Customer_Check_Value = configArr[i].value;
						if(Create_Customer_Check_Value.toUpperCase() == "YES")
					      globarr.create_customer = true;
					      else if(Create_Customer_Check_Value.toUpperCase() == "NO")
					      globarr.create_customer = false;
					  	else
					  	{
					  		var _default_cust_error = "Please check the configuration settings... Please set value for create customer only Yes/NO.";
				            $('#Quote_Message_Log').text(_default_cust_error); 
				            $('#Job_Message_Log').text(_default_cust_error);  
				            hide_loader();
				            hide_jobloader();
				            return true;
					  	}
				    }
			    if("Default_Customer_Id" == configArr[i].name)
				  {
				      var defaultcustArr = configArr[i].value;
				      var defaultcustArr = defaultcustArr.split(',');   
				      $.each(defaultcustArr,function(j)
				      {  
				        if(!isNumber(defaultcustArr[j])){
				           var _default_cust_error = "Please check the configuration settings... Please set value for default customer only number.";
				            $('#Quote_Message_Log').text(_default_cust_error); 
				            $('#Job_Message_Log').text(_default_cust_error);  
				            hide_loader();
				            return;
				          }
				          else{
				          	DefaultCustomerArr[j] = defaultcustArr[j];
						        if(j === 0){ 
						          $('#Default_Cusotmer_ID').append($("<option></option>")
						                .attr("value", defaultcustArr[j])
						                .attr("selected","selected")
						                .text(defaultcustArr[j]));    
						          globarr.default_customer_id = defaultcustArr[j];
						        }
						        else
						        {
						          $('#Default_Cusotmer_ID').append($("<option></option>")
						                .attr("value", defaultcustArr[j])
						                .text(defaultcustArr[j]));  
						        } 
				          } 
				      });  
				    }  			
					if("multi_company" == configArr[i].name)
					{ 
						$("#Multi_Company").val(configArr[i].value); 
						var Multi_Company_Value = configArr[i].value;
						globarr.multi_company = configArr[i].value;
						if(Multi_Company_Value.toUpperCase() === 'YES')
						{
							multicompany = true;
							$("#Simpro_Company_ID_block").css("display","block");  
						} 
  
								if(Multi_Company_Value.toUpperCase() != "YES" && Multi_Company_Value.toUpperCase() != "NO")
								{
									let _multicomany_error = "Please check the value for multi_company in configuration settings... Please set only the values Yes Or No"; 							
									$('#Quote_Message_Log').text(_multicomany_error); 
							    $('#Job_Message_Log').text(_multicomany_error);
						      hide_loader();
									return true; 
								}

					}  

					if("Update_simPRO_Status_from_Desk" == configArr[i].name)
					{
						globarr.Update_simPRO_Status_from_Desk = configArr[i].value;
					}  			
					if("simprosubdomain" == configArr[i].name)
					{
						globarr.simproSubDomain = configArr[i].value;
					} 
					if("simprodomain" == configArr[i].name)
					{
						globarr.simprodomain = configArr[i].value;
					} 
					if("syncezy_key" == configArr[i].name)
					{
						globarr.syncezy_key = configArr[i].value;
					} 						
					if("simpro_companies" == configArr[i].name)
					{
						var Simpro_Companiesd = configArr[i].value;
						var array = Simpro_Companiesd.split(',');    
						var fisrt_company_id = "";
						$.each(array,function(k)
						{   
							var companyArr = array[k].split('-'); 
							if(companyArr.length == 2)
							{
									var comp_id = companyArr[0].trim();
									var comp_name = companyArr[1].trim();   
									comapnyIdArr[k] = comp_id;
									if(!isNumber(comp_id)){
							           var _default_comp_error = "Please check the configuration settings... Please set value for simpro companies only numbers as 10 - India, 12 - AUS, 15 - NYZ";
							            $('#Quote_Message_Log').text(_default_comp_error); 
							            $('#Job_Message_Log').text(_default_comp_error);  
							            hide_loader();
							            return true; 
							   }
							   else{
							   	if(k === 0) {
										first_company_id = comp_id;

										//globarr.default_company_id = comp_id;  
										$('#Simpro_Company_ID').append($("<option></option>")
								              .attr("value", comp_id)
								              .text(comp_name))
							              .attr("selected","selected");
							              globarr.company_id = comp_id;
									}else{
										$('#Simpro_Company_ID').append($("<option></option>")
									              .attr("value", comp_id)
									              .text(comp_name)); 
									}	
							   }
							}else{
													var _default_comp_error_array = "Please check the configuration settings... Please set value for simpro companies only numbers as 10 - India, 12 - AUS, 15 - NYZ";
							            $('#Quote_Message_Log').text(_default_comp_error_array); 
							            $('#Job_Message_Log').text(_default_comp_error_array);  
							            hide_loader();
							            return true; 
							}
							
						});  

					}  
					coufig_counter = coufig_counter + 1; 
				}

				/*********multicompany case**********/
				if(multicompany == true){
						var set_company = ""; 
						var old_comapny_id = localStorage.getItem("comapny_id"); 

						if(old_comapny_id == "" || old_comapny_id == undefined) 
						 set_company = first_company_id; 
						else
						 set_company = old_comapny_id; 

						if( coufig_counter == configArr.length)
						{  
							$('#Simpro_Company_ID').val(set_company);   
							let indexOfComapnyId = comapnyIdArr.indexOf(set_company);  
							let setSiteId =  DefaultSiteArr[indexOfComapnyId]; 
							if(setSiteId != "") {
								$('#Default_Site_ID').val(setSiteId); 
							} 
						    globarr.company_id = set_company;
						    globarr.default_site_id = setSiteId; 

						}
					} 


					default_site_name_check(globarr); 
				key_check_syncezy(globarr);
				fetch_quote_cost_center(globarr);
				fetch_quote_report_tag(globarr);
					

				if((comapnyIdArr.length !=  DefaultSiteArr.length) && (comapnyIdArr.length != DefaultCustomerArr.length))  {
    		company_site_customer_message();
  			}

			// find data in crm
			ZOHODESK.get('ticket').then(function (res) 
			{ 
				//console.log(res);
				email = res.ticket.email;
				globarr.ticket_url = res.ticket.link; 
				var tic_id = res.ticket.id;
				var description = res.ticket.description; 
				var contactName = res.ticket.contactName;  
				var dueDate = res.ticket.dueDate;  
				var ticket_subject = res.ticket.subject;
				var tic_number = res.ticket.number;
				globarr.tic_number = tic_number;


				if(dueDate != "No Due Date set"){ 
				// const duedateString = timeSolver.getString(dueDate, "YYYY-MM-DD");  
				// $("#due_date").val(duedateString);
				}
				
				globarr.email = email; 
				globarr.phone = res.ticket.phone; 
				globarr.description = description; 
				globarr.tic_id = tic_id; 
				globarr.ticket_subject = ticket_subject; 
				var timeline_notes_quote = {"Subject":"This quote has been linked from the Zoho Desk ticket ID #"+globarr.tic_number,"Note":"Zoho Desk ticket URL: <a target='_blank' href='"+globarr.ticket_url+"'>"+globarr.ticket_url+"</a>"};
				var timeline_notes_job = {"Subject":"This Job has been linked from the Zoho Desk ticket ID #"+globarr.tic_number,"Note":"Zoho Desk ticket URL: <a  target='_blank' href='"+globarr.ticket_url+"'>"+globarr.ticket_url+"</a>"};
				globarr.timeline_notes_quote = timeline_notes_quote; 
				globarr.timeline_notes_job = timeline_notes_job; 

				$("#description").val(description);
				$("#contactName").val(contactName);
				$("#email").val(email);
				if(description == null)
					{
						show_loader();
						getthreadData(tic_id);
					}
				$("#tic_id").val(tic_id); 
				searchcustomer(globarr); 
			}).catch(function (res) { 
				$('#Hidden_Message_Log').text(res); 
			}); 

			ZOHODESK.get('ticket.cf').then(function (res) 
			{
			  //response Handling  
				 if(res['ticket.cf'] != null){
						cf_simpro_quote_number = res['ticket.cf'].cf_simpro_quote_number; 
						cf_simpro_job_number = res['ticket.cf'].cf_simpro_job_number;    
						cf_simpro_company_id = res['ticket.cf'].cf_simpro_company_id; 

						  globarr.cf_simpro_quote_number = cf_simpro_quote_number;
						  globarr.cf_simpro_job_number = cf_simpro_job_number;
						  globarr.cf_simpro_company_id = cf_simpro_company_id;

						tic_id =  $("#tic_id").val();


		  
		  				if(cf_simpro_company_id != null){
		  					$("#Simpro_Company_ID").val(cf_simpro_company_id).trigger('change');
		  					// let indexOfComapnyId = comapnyIdArr.indexOf(cf_simpro_company_id); 
		  					// let setSiteId =  DefaultSiteArr[indexOfComapnyId]; 
		  					// if(setSiteId != "") 
		  					// $('#Default_Site_ID').val(setSiteId); 
		  				} 
				  	} 
				var ext = localStorage.getItem("domain_extension");

				if(cf_simpro_quote_number != null )
				{  

					if(globarr.simprodomain.includes("simprosuite") == true)
					{
						 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
					}
					else if(globarr.simprodomain.includes("simprocloud") == true)
					{
						 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
					}

					var reqObj= {
					     url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/quotes/'+cf_simpro_quote_number,
					     headers : { 'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
					     type : 'GET',
					     data : {},
					     postBody : {},
					     fileObj: [],
					 //    connectionLinkName: "zohodeskcon"
					}   
					ZOHODESK.request( reqObj ).then(function(response)
					{   
						var responseArr = JSON.parse(response); 
						if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
						var dataArrJson = responseArr.response; 
						//console.log(dataArrJson);
						var dataArr = JSON.parse(dataArrJson);
						if(dataArr.errors != '' && dataArr.errors != undefined )
						{ 
							simproerrors = dataArr.errors;  
						$('#Quote_Message_Log').text("");
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Quote_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}
								hide_loader();   
							} 
						}
						else{ 
								var quote_id = dataArr.ID; 
								if(quote_id != "")
								{
									getallquotenotes(globarr,"quotes",quote_id);

									//$('#Quote_Message_Log').text("Quote loaded Successfully.");
									$('#Quote_Message_Log').text("Quote linked successfully.");   
									quote_url =  "https://"+globarr.simproSubDomain+"."+globarr.simprodomain+".com/staff/editProject.php?quoteID="+quote_id;

									$("#Quote_Number").val(quote_id);
									$("#quote_link").text(quote_url);
									$("#quote_link").attr("href",quote_url); 
									//$("#createQuote").css("display","none");
									quote_number_button_change(quote_id,quote_url);
								}
							} 
					}).catch(function(err){ 
						//console.log(err);
						$('#Hidden_Message_Log').text(err); 
					})   

				}
				else{
				$("#createQuote").css("display","block");  
				}

				if(globarr.Update_simPRO_Status_from_Desk == "No")
				{

					$("#updatestatus").css("display","none");

				}
 


				if(cf_simpro_job_number != null )
				{ 
					if(globarr.simprodomain.includes("simprosuite") == true)
					{
						 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
					}
					else if(globarr.simprodomain.includes("simprocloud") == true)
					{
						 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
					}

					var reqObj= {
					     url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/jobs/'+cf_simpro_job_number,
					     headers : { 'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
					     type : 'GET',
					     data : {},
					     postBody : {},
					     fileObj: [],
					}   
					ZOHODESK.request( reqObj ).then(function(response)
					{   
						var responseArr = JSON.parse(response); 
						if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
						var dataArrJson = responseArr.response; 
						var dataArr = JSON.parse(dataArrJson);
						if(dataArr.errors != '' && dataArr.errors != undefined )
						{ 
							simproerrors = dataArr.errors;  
						$('#Job_Message_Log').text("");
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Job_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}
								hide_loader();   
							} 
						}
						else{ 
								var job_id = dataArr.ID; 
								if(job_id != "")
								{
 									getallquotenotes(globarr,"jobs",job_id);
									$('#Job_Message_Log').text("Job linked successfully.");

									//$('#Job_Message_Log').text("Job loaded Successfully.");

									job_url =  "https://"+globarr.simproSubDomain+"."+globarr.simprodomain+".com/staff/editProject.php?jobID="+job_id;
									$("#Job_Number").val(job_id);
									$("#job_link").text(job_url);
									$("#job_link").attr("href",job_url); 
									//$("#createJob").css("display","none");
									job_number_button_change(job_id,job_url);

								}
							} 
					}).catch(function(err){ 
						//console.log(err);
$('#Hidden_Message_Log').text(err); 
					})   
				}
				else
				{ 
					$("#createJob").css("display","block");   
				}  

			}).catch(function (err) { 
				//console.log(err);
        $('#Hidden_Message_Log').text(err); 
			}); 

			// *********/

		}).catch(function(err){
			//console.log(err);
     $('#Hidden_Message_Log').text(err); 
		})    


/* below function is triggerd when we change company from front end of Simpro Company */

		$("#Simpro_Company_ID").change(function()
		{ 
			$('#Quote_Message_Log').text(""); 
			show_loader(); 
      show_jobloader();
			let comapny_id =  $(this).val();

			if((comapnyIdArr.length !=  DefaultSiteArr.length) && (comapnyIdArr.length != DefaultCustomerArr.length))  {
    		company_site_customer_message();
  		} 

			let indexOfComapnyId = comapnyIdArr.indexOf(comapny_id); 
			localStorage.setItem("comapny_id",comapny_id);
			let setSiteId =  DefaultSiteArr[indexOfComapnyId]; 
			if(setSiteId == undefined)
			{
			 let setSiteId =  DefaultSiteArr[0]; 
			}
			let setdefaultcustId =  DefaultCustomerArr[indexOfComapnyId]; 
			$("#Default_Site_ID").val(setSiteId);  
			globarr.company_id = comapny_id;
			globarr.default_site_id = setSiteId; 
			globarr.company_id = comapny_id;
			globarr.default_customer_id = setdefaultcustId;
		  $("#simpro_customer_id").val("");
		  $("#simpro_customer_site_id").val("");
		  globarr.simpro_customer_id = null;
		  globarr.simpro_customer_site_id = null;  
		  $("#Simpro_Site_name_val").empty();
		  default_site_name_check(globarr);
			searchcustomer(globarr);  

		//console.log("cf_simpro_quote_number "+globarr.cf_simpro_quote_number);
			//console.log("cf_simpro_job_number "+globarr.cf_simpro_job_number);
			// if(globarr.cf_simpro_job_number != null)
			// {
			// 						$('#Job_Message_Log').text("Job loaded Successfully.");
			// 						job_url =  "https://"+globarr.simproSubDomain+"."+globarr.simprodomain+".com/staff/editProject.php?jobID="+globarr.cf_simpro_job_number;
			// 						$("#Job_Number").val(globarr.cf_simpro_job_number);
			// 						$("#job_link").text(job_url);
			// 						$("#job_link").attr("href",job_url); 
			// 						$("#createJob").css("display","none");
			// }
			// else if(globarr.cf_simpro_quote_number != null)
			// {
			// 						$('#Quote_Message_Log').text("Quote loaded successfully.");  
			// 	                quote_url =  "https://"+globarr.simproSubDomain+"."+globarr.simprodomain+".com/staff/editProject.php?quoteID="+globarr.cf_simpro_quote_number;
			// 	                $("#Quote_Number").val(globarr.cf_simpro_quote_number);
			// 	                $("#quote_link").text(quote_url);
			// 	                $("#quote_link").attr("href",quote_url); 
			// 	                $("#createQuote").css("display","none")

			// }
		});	


/* below function is triggerd when we change company from front end of Simpro Site */
 

		$("#Simpro_Site_name_val").change(function()
		{

			show_loader();
			let site_id =  $(this).val();
			
			globarr.simpro_customer_site_id = site_id;
			$("#simpro_customer_site_id").val(site_id); 

			hide_loader();


		});

/* below function is triggerd when we change company from front end of Refresh Site */
		$("#refreshSite").click(function(e)
		{
		show_loader(); 
  	$("#Simpro_Site_name_val").empty();
  	default_site_name_check(globarr);
			searchcustomer(globarr);
      show_jobloader();


		});

/* below function is triggerd when we change company from front end of Update Status */

	  $("#updatestatus").click(function(e)
		{
			


			 if(globarr.simprodomain.includes("simprosuite") == true)
					{
						 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
					}
					else if(globarr.simprodomain.includes("simprocloud") == true)
					{
						 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
					}

			var reqObj= 
			{
		      url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/setup/statusCodes/projects/',
		      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
		      type : 'GET',
				     data : {},
				     postBody : {},
				     fileObj: [],
			}

			ZOHODESK.get('ticket').then(function (res) 
			{  
			
			quo_status = res.ticket.status; 

			quo_number = res.ticket.cf.cf_simpro_quote_number; 
			job_number = res.ticket.cf.cf_simpro_job_number; 

			ZOHODESK.request( reqObj ).then(function(response)
			{ 
				var responseArr = JSON.parse(response); 
				if(responseArr.statusCode == 401)
				{
				  	token_message();
				}
				var dataArrJson = responseArr.response; 

				var dataArr = JSON.parse(dataArrJson);
				
				var simpro_status_id = "";
				if(dataArr.length > 0)
				{
					for (var i = 0; i < dataArr.length; i++) { 
					var  quo_status_name = dataArr[i]['Name'];
					var  quo_status_id = dataArr[i]['ID'];

					//console.log(quo_status_name+" - "+quo_status_id);
					if((quo_status_name == quo_status)){  
					var simpro_status_id = quo_status_id;
					break;
					}
					}

					if(simpro_status_id != "")
					{ 
					globarr.simpro_status_code = simpro_status_id;
					
					if(job_number == null)
					{
					$('#Quote_Message_Log').text("Updating quote please wait.....");  
					quotestatusupdate(globarr,quo_number);
					}
					else
					{
						$('#Job_Message_Log').text("Updating Job please wait.....");  
						jobstatusupdate(globarr,job_number);
					}	

					}

					else
					{

					if(job_number == null)
					{
						$('#Quote_Message_Log').append("The Zoho Desk status does not match with a simPRO Status. Please change to another status and retry");  
					}
					else
					{
						$('#Job_Message_Log').append("The Zoho Desk status does not match with a simPRO Status. Please change to another status and retry");  
					}

					}
				}

				
			}).catch(function(err)
			{
				//console.log(err);
				$('#Hidden_Message_Log').text(err); 
				// var responseArr = JSON.parse(err); 
				// if(responseArr.statusCode == 401)
				//   	{
				//   		token_message();
				//   	}
				// var dataArrJson = responseArr.response; 
				// var dataArr = JSON.parse(dataArrJson);
				// if(dataArr.errors != '' && dataArr.errors != undefined )
				// { 
				// 	simproerrors = dataArr.errors;  
				// $('#'+display_log).text("");
				// 	if(simproerrors.length > 0){
				// 		for (var i = 0; i < simproerrors.length; i++) { 
				// 			$('#'+display_log).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
				// 		}  
				// 	hide_loader();
				// 	} 
				// }
			}) 



	}).catch(function (res) {
		//error Handling
		hide_loader();
	});  


		});


		$("#keycheck").click(function(e)
		{

				key_check_syncezy(globarr);

		});

/* this function is used when integrating with syncezy platform */


		function key_check_syncezy(globarr)
		{

			show_loader(); 
			ZOHODESK.get("user.email").then(function(userResponse){
		  useremail = userResponse["user.email"];
		  globarr.useremail = useremail;
		  var keyData = {};
		  keyData.app_key = globarr.syncezy_key;
			uat_url = "https://api.integration.syncezy.com/api/validate-external-integration-api-key";

			var reqObj= {
				  url : uat_url,
				  headers : { 'Content-Type': 'application/json', 'SyncEzy-Api-Key' : 'oCfZY9BzG*A6Gj-TLv^ymoLB!ImlK4z@qAglBz*k6Kqfs%x6DVLEgCP3OQx6BLO5jfK8^g-B9Q!fPiZjrAtZc5xH57ed0Yx4D0z%!dmYklp8e1CrT-P5IM5Glq6er_*Z'},
				  type : 'POST',
				  data : keyData,
				  postBody : {},
				}

		
				ZOHODESK.request( reqObj ).then(function(response)
				{


						var responseArr = JSON.parse(response);
						if(responseArr.statusCode == 400)
						{

							var responseMsgArr = JSON.parse(responseArr.response);

							var responseMsg = responseMsgArr.msg;

									key_message(responseMsg);
									$("#createQuote").css("display","none");
									$("#updatestatus").css("display","none");
									$("#refreshSite").css("display","none");
									$("#createJob").css("display","none");
									globarr.simpro_api_key = "";
															  		//token_message();
						 }
						 else if(responseArr.statusCode == 500)
						 {
						 	var responseMsgArr = JSON.parse(responseArr.response);
							var responseMsg = responseMsgArr.msg;

									key_message(responseMsg);
									$("#createQuote").css("display","none");
									$("#updatestatus").css("display","none");
									$("#refreshSite").css("display","none");
									$("#createJob").css("display","none");
									globarr.simpro_api_key = "";

						 }
						 else if(responseArr.statusCode == 200)
						 {

						 	var responseMsgArr = JSON.parse(responseArr.response);
							var dataArrJson = responseMsgArr.data;
							var dataPlanDetails = dataArrJson.plan_details;
							var planPrice = dataPlanDetails.price;

							if(planPrice == 0 || planPrice == undefined)
							{

								$("#createQuote").css("display","none");
								$("#updatestatus").css("display","none");
								$("#refreshSite").css("display","none");
								$("#quote_details2").css("display","none");
								$("#quote_details1").css("display","none");
								$("#quote_details").css("display","none");

								document.getElementById("quote_job_type_label").innerText = "Job Type";
								document.getElementById("due_date_label").innerText = "Job Due Date";

							}



						 }

						
						
				}).catch(function(err){
					console.log(err);
					$('#Hidden_Message_Log').text(err); 
				}) 


		    
			}).catch(function(error){
				    //handle your error here...
			})
   // show_jobloader();

    hide_loader();
		}

/* this function is used to change button style */

		function quote_number_button_change(quote_job_id,quote_job_url)
		{

				 								const createQuoteButton = document.getElementById("createQuote");
							          const quoteButtonLink = document.createElement("a");
				                quoteButtonLink.href = quote_job_url;
				                quoteButtonLink.className  = createQuoteButton.className;
				                quoteButtonLink.innerHTML   =  "QN :"+quote_job_id ;
				                quoteButtonLink.target = '_blank';
				                quoteButtonLink.rel = 'noopener noreferrer';
				                quoteButtonLink.style.cssText = createQuoteButton.style.cssText;
				                createQuoteButton.parentNode.replaceChild(quoteButtonLink, createQuoteButton);

		}
		/* this function is used to change button style */

		function job_number_button_change(quote_job_id,quote_job_url)
		{

				 								const createJobButton = document.getElementById("createJob");
							          const jobButtonLink = document.createElement("a");
				                jobButtonLink.href = quote_job_url;
				                jobButtonLink.className  = createJobButton.className;
				                jobButtonLink.innerHTML   =  "JN :"+quote_job_id ;
				                jobButtonLink.target = '_blank';
				                jobButtonLink.rel = 'noopener noreferrer';
				                jobButtonLink.style.cssText = createJobButton.style.cssText;
				                createJobButton.parentNode.replaceChild(jobButtonLink, createJobButton);

		}

/* this function is used to update statu in simpro */

function quotestatusupdate(globarr,quo_number)
		{ 
			
			
			 var customerData  = {"Status":globarr.simpro_status_code,"AutoAdjustStatus":false};
				/* updated code */

 		if(globarr.simprodomain.includes("simprosuite") == true)
					{
						 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
					}
					else if(globarr.simprodomain.includes("simprocloud") == true)
					{
						 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
					}

				var reqObj= {
				  url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/quotes/'+quo_number,
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'PATCH',
				  data : {}, 
				  postBody : customerData,
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{
						var responseArr = JSON.parse(response);
						if(responseArr.statusCode == 401)
						  	{
						  		token_message();
						  	}
						
						var messages="";
						if(responseArr.statusCode == 422 )
						{
							var dataArrJson = responseArr.response; 
							var quoteDataArr = JSON.parse(dataArrJson);  

							simproerrors = quoteDataArr.errors; 
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Quote_Message_Log').html(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}   
								hide_loader(); 
							} 
						}
						else 
						{  
							
							$('#Quote_Message_Log').append("Quote Updated Successfully!");  
							hide_loader(); 
							update_status(quo_number);
								
						}
				}).catch(function(err){
					//console.log(err);
					$('#Hidden_Message_Log').text(err); 
				}) 

		}

/* this function is used to update statu in simpro */

function jobstatusupdate(globarr,job_number)
		{ 
			
			
			 var customerData  = {"Status":globarr.simpro_status_code,"AutoAdjustStatus":false};
				/* updated code */
if(globarr.simprodomain.includes("simprosuite") == true)
					{
						 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
					}
					else if(globarr.simprodomain.includes("simprocloud") == true)
					{
						 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
					}


				var reqObj= {
				  url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/jobs/'+job_number,
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'PATCH',
				  data : {}, 
				  postBody : customerData,
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{
						var responseArr = JSON.parse(response);
						if(responseArr.statusCode == 401)
						  	{
						  		token_message();
						  	}
						
						var messages="";
						if(responseArr.statusCode == 422 )
						{
							var dataArrJson = responseArr.response; 
						var quoteDataArr = JSON.parse(dataArrJson); 
					
							simproerrors = quoteDataArr.errors; 
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Job_Message_Log').html(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}   
								hide_loader(); 
							} 
						}
						else 
						{  
							
							$('#Job_Message_Log').append("Job Updated Successfully!");  
							hide_loader(); 
							update_status(job_number);
								
						}
				}).catch(function(err){
					//console.log(err);
					$('#Hidden_Message_Log').text(err); 
				}) 

		}

/* below function is used to update record in simpro either it is quote / job  */
 
		function updateSimproRecord(globarr,module_id,module_name)
		{ 
      var pushArr = {};  
      pushArr.Notes = globarr.Notes;  

      if(globarr.simprodomain.includes("simprosuite") == true)
					{
						 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
					}
					else if(globarr.simprodomain.includes("simprocloud") == true)
					{
						 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
					}

      let options = {
      url: baseurl+'api/v1.0/companies/'+globarr.company_id+'/'+module_name+'/'+module_id,
        headers: {"Authorization":"Bearer "+globarr.simpro_api_key,"Content-Type": "application/json"}, 
        secure: true,
        type: 'PATCH', 
     		data : {},
        postBody:JSON.stringify(pushArr) ,
    	 fileObj: [],
      };
      ZOHODESK.request( options ).then(function(response)
			{ 
       //console.log(response); 
      }).catch(err => { 
        //console.log(err);
$('#Hidden_Message_Log').text(err); 
      });  
		} 

		


/* below function is used to update zoho desk ticket id in simpro custom fields   */

		function updateDeskTicketIdInSimpro(globarr,cf_simpro_quote_number,simpro_ticket_field_id,module_name,displaybox)
		{
			var pushArr = {}; 
			pushArr.Value = globarr.tic_id; 
			if(globarr.simprodomain.includes("simprosuite") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
	}
	else if(globarr.simprodomain.includes("simprocloud") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
	}

			var reqObj= {
			     url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/'+module_name+'/'+cf_simpro_quote_number+'/customFields/'+simpro_ticket_field_id,
			     headers : { 'Content-Type' : 'multipart/form-data', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
			     type : 'PATCH',
			     data : {},
			     postBody : JSON.stringify(pushArr),
			     fileObj: [],
			}   
			ZOHODESK.request( reqObj ).then(function(response)
			{ 
				hide_loader();   
				var responseArr = JSON.parse(response); 
				if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
				if(responseArr.statusCode == 204)
				{
					$('#'+displaybox).append("\n Ticket id synched successfully in simpro");
				}

				if(responseArr.response != "")
				{
					var dataArrJson = responseArr.response; 
					var dataArr = JSON.parse(dataArrJson);

						if(dataArr.errors != '' && dataArr.errors != undefined )
						{ 
							simproerrors = dataArr.errors;   
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#'+displaybox).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
									$('#'+displaybox).append("\n Unable to link ticket to simPRO record.");
								} 
							} 
						}
						else
						{
							$('#'+displaybox).append("\n Ticket Synched Successfully");
						} 
				}
			}).catch(function(err){
				//console.log(err);
$('#Hidden_Message_Log').text(err); 
			})
 
		}



/* below function is triggered when you made changes ticket fields   */

		App.instance.on("ticket.changed", function(data)
		{  
			//console.log(data);
		});


/* below function is triggered when you made changes ticket custom fields   */

		App.instance.on("ticket_customFields.changed", function(data)
		{  
			//console.log(data);
			show_loader();  
			if(data['ticket.customFields']['Simpro Quote Number'] != null)
			{   
				$('#Quote_Message_Log').text("Processing...");  
				var cf_simpro_quote_number = data['ticket.customFields']['Simpro Quote Number']; 

				if(globarr.simprodomain.includes("simprosuite") == true)
				{
					 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
				}
				else if(globarr.simprodomain.includes("simprocloud") == true)
				{
					 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
				}

				var reqObj= {
				     url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/quotes/'+cf_simpro_quote_number,
				     headers : { 'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				     type : 'GET',
				     data : {},
				     postBody : {},
				     fileObj: [],
				}   
				ZOHODESK.request( reqObj ).then(function(response)
				{  
				if(IsParsable(response)) {
					var responseArr = JSON.parse(response); 
					if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
					var dataArrJson = responseArr.response; 
					if(IsParsable(response)) {
								var dataArr = JSON.parse(dataArrJson);
								if(dataArr.errors != '' && dataArr.errors != undefined )
								{ 
									simproerrors = dataArr.errors;  
									if(simproerrors.length > 0){

								$('#Quote_Message_Log').text("");
										for (var i = 0; i < simproerrors.length; i++) { 
											$('#Quote_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
										}
										$("#quote_link").html("");   
										$("#Quote_Number").val(""); 
										hide_loader();   
									}  
								}
								else{  
											let results = dataArr;
											if(results.hasOwnProperty('ID'))
				              {
				                var quote_id = results.ID; 

				                let ticket_url = globarr.ticket_url;
				                let private_notes = '=====================================================<br><br>This Job / Quote has been created from the ZohoDesk Ticket: '+globarr.tic_id+' <br><br>\n ZohoDesk Ticket URL : <a href="'+ticket_url+'">'+ticket_url+'</a><br><br>====================================================='; 
				                let existing_notes =  results.Notes;
				                let position = existing_notes.search(ticket_url);
				                if(position == -1){
				                  globarr.Notes = results.Notes +" \n "+private_notes; 
				                  updateSimproRecord(globarr,quote_id,'quotes',"Quote_Message_Log"); 
				                }
				                $('#Quote_Message_Log').text("Quote linked successfully.");
				               // $('#Quote_Message_Log').text("Quote loaded successfully.");  
				                quote_url =  "https://"+globarr.simproSubDomain+"."+globarr.simprodomain+".com/staff/editProject.php?quoteID="+quote_id;
				                $("#Quote_Number").val(quote_id);
				                $("#quote_link").text(quote_url);
				                $("#quote_link").attr("href",quote_url); 
				                //$("#createQuote").css("display","none");
				                quote_number_button_change(quote_id,quote_url);
				                getallquotenotes(globarr,'quotes',quote_id);
				              }else{
				                $('#Quote_Message_Log').text("Quote not found.");
				              }  
				              hide_loader(); 
									
								} 
							} else{
							  $('#Quote_Message_Log').text("Quote not found."); 
						}
					} else{
						$('#Quote_Message_Log').text("Quote not found.");
					}
				}).catch(function(err){
					//console.log(err);
         $('#Hidden_Message_Log').text(err); 
				})  
			}
			else if(data['ticket.customFields']['Simpro Job Number'] != null)
			{
				$('#Job_Message_Log').text("Processing...");  
				var cf_simpro_job_number = data['ticket.customFields']['Simpro Job Number'];

				if(globarr.simprodomain.includes("simprosuite") == true)
				{
					 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
				}
				else if(globarr.simprodomain.includes("simprocloud") == true)
				{
					 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
				}

				var reqObj= {
				     url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/jobs/'+cf_simpro_job_number,
				     headers : { 'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				     type : 'GET',
				     data : {},
				     postBody : {},
				     fileObj: [],
				}   
				ZOHODESK.request( reqObj ).then(function(response)
				{   
					if(IsParsable(response)) { 
						var responseArr = JSON.parse(response); 
						if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
						var dataArrJson = responseArr.response;  
						if(IsParsable(dataArrJson)) { 
							var dataArr = JSON.parse(dataArrJson);
							if(dataArr.errors != '' && dataArr.errors != undefined )
							{ 
								simproerrors = dataArr.errors;  
								$('#Job_Message_Log').text("");
								if(simproerrors.length > 0){
									for (var i = 0; i < simproerrors.length; i++) { 
										$('#Job_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
									}
									$("#job_link").html("");   
									$("#Job_Number").val("");
									hide_loader();   
								} 
							}
							else{ 
								let results = dataArr;
								var job_id = results.ID; 
		                    let ticket_url = globarr.ticket_url;
		                    let private_notes = '=====================================================<br><br>This Job / Quote has been created from the ZohoDesk Ticket: '+globarr.tic_id+' <br><br> \n ZohoDesk Ticket URL : <a href="'+ticket_url+'">'+ticket_url+'</a><br><br>=====================================================';
		                    let existing_notes =  results.Notes;
		                    let position = existing_notes.search(ticket_url);
		                    if(position == -1){
		                      globarr.Notes = results.Notes +" \n "+private_notes; 
		                      updateSimproRecord(globarr,job_id,'jobs',"Job_Message_Log");
		                    } 
		                    $('#Job_Message_Log').text("Job linked successfully.");
		                    //$('#Job_Message_Log').text("Job loaded successfully.");
		                    job_url =  "https://"+globarr.simproSubDomain+"."+globarr.simprodomain+".com/staff/editProject.php?jobID="+job_id;
		                    $("#Job_Number").val(job_id);
		                    $("#job_link").text(job_url);
		                    $("#job_link").attr("href",job_url); 
		                   // $("#createJob").css("display","none"); 
		                    job_number_button_change(job_id,job_url);
		                    getallquotenotes(globarr,'jobs',job_id);
								} 
						}else{
							$('#Job_Message_Log').text("Job not found.");
						} 
					}else{
						$('#Job_Message_Log').text("Job not found.");
					}
					}).catch(function(err){ 
						//console.log(err);
$('#Hidden_Message_Log').text(err);
					})  
			}
 
			hide_loader();
		})  


/* below function is used to display message based in configruation setup if wrong   */

		function addMessageOnError(globarr,logmesg)
		{

			// default_project_type = globarr.default_project_type;
			// default_project_type = default_project_type.toLowerCase();
			// if(default_project_type != "service" && default_project_type != "project")
			// {
			// 	$('#'+logmesg).text("Please check the value for project type in configuration settings... Please set only the values Service Or Project"); 
			// 	hide_loader();
			// 	return true; 
			// }

			default_customer_type = globarr.default_customer_type;
			default_customer_type = default_customer_type.toLowerCase();
			if(default_customer_type != "companies" && default_customer_type != "individuals")
			{  
			$('#'+logmesg).text("Please check the value for customer type in configuration settings... Please set only the values Individuals Or Companies"); 
				hide_loader();
				return true;
			}

			multi_company = globarr.multi_company;
			multi_company = multi_company.toLowerCase();
			if(multi_company != "yes" && multi_company != "no")
			{  
			$('#'+logmesg).text("Please check the value for multi_company value in configuration settings... Please set only the values Yes Or No"); 
				hide_loader();
				return true;
			}  

			return false;
		}


async function processTags(tagArray,globarr,module) {

if(globarr.Simpro_Selected_Tag_Ids != "")
			{
	let finalList = [];
	let newtag_list = "";

    for (let i = 0; i < tagArray.length; i++) {
    let tag = tagArray[i];

    // Trim spaces
    let trimmed = tag.trim();

    if (!isNaN(trimmed) && trimmed !== '') {
        finalList.push(Number(trimmed));
    } else {

        var reportTagData = {};
        reportTagData.Name = trimmed;
        reportTagData.Archived = false;

        let baseurl = '';
        if (globarr.simprodomain.includes("simprosuite") === true) {
            baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
        } else if (globarr.simprodomain.includes("simprocloud") === true) {
            baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
        }

        var reqObj = {
            url: baseurl + 'api/v1.0/companies/' + globarr.company_id + '/setup/tags/projects/',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + globarr.simpro_api_key },
            type: 'POST',
            data: {},
            postBody: JSON.stringify(reportTagData),
        };

        try {
				    const response = await ZOHODESK.request(reqObj); // wait for request to finish
				    const responseArr = JSON.parse(response);

				    if (responseArr.statusCode == 401) {
				        token_message();
				    } else if (responseArr.statusCode == 422) {
				        const quoteDataArr = JSON.parse(responseArr.response);
				        simproerrors = quoteDataArr.errors;
				        if (simproerrors.length > 0) {
				            for (let j = 0; j < simproerrors.length; j++) {
				                $('#Quote_Message_Log').html(" " + simproerrors[j].path + "-" + simproerrors[j].message);
				            }
				            hide_loader();
				        }
				    } else {
				        const quoteDataArr = JSON.parse(responseArr.response);
				        const simpro_Tag_creation_Id = quoteDataArr.ID;

				       // console.log("simpro_Tag_creation_Id -" + simpro_Tag_creation_Id);

				        finalList.push(simpro_Tag_creation_Id);

				        // Append to newtag_list and store in globarr
				        newtag_list = newtag_list + "," + simpro_Tag_creation_Id;
				        globarr.newtag_list = newtag_list;
				    }
				} catch (err) {
				    console.log(err);
				    $('#Hidden_Message_Log').text(err);
				}
    }
}


   // console.log("All tags processed:", finalList);
    globarr.tagfinalList = finalList;

$("#All_Tag_Ids").val(finalList);
}
if(module == "Quote")
{
	createQuoteinSimpro(globarr);

}
else if(module == "Job")
{
createJobinSimpro(globarr);  
}




}


/* below function is used to create quote in simpro   */

		function createQuoteinSimpro(globarr)
		{ 

			let private_notes = '=====================================================<br><br>This Job / Quote has been created from the Zohodesk Ticket: '+globarr.tic_id+' <br> <br> \n Zohodesk Ticket URL : <a href="'+globarr.ticket_url+'">'+globarr.ticket_url+'</a><br><br>=====================================================';
			if(globarr.simpro_customer_site_id == "")
			{
				globarr.simpro_customer_site_id = globarr.default_site_id;
			}
			var company_id = globarr.company_id; 
			var customerData = {};
			customerData.Customer = parseInt(globarr.simpro_customer_id); 
			customerData.Type = globarr.default_project_type; 	
			customerData.Name = globarr.ticket_subject;			
			if(globarr.due_date != "")
			{ 
				customerData.DueDate = globarr.due_date; 
			}
			if(globarr.order_number)
			customerData.OrderNo = globarr.order_number
			customerData.Description = globarr.description;   
			customerData.Site = parseInt(globarr.simpro_customer_site_id); 

			// if (globarr.simpro_report_tag) {
			//   customerData.Tags = [parseInt(globarr.simpro_report_tag)];
			// }


			var All_Tag_Ids = $("#All_Tag_Ids").val();
			globarr.All_Tag_Ids = All_Tag_Ids;
 			//console.log("All_Tag_Ids - "+ All_Tag_Ids);

			if (All_Tag_Ids) {
			  var Tags_li = [All_Tag_Ids];
			  var Tags = Tags_li[0].split(',').map(Number);
			  customerData.Tags = Tags;

			}
			//customerData.Notes = private_notes; 
			if(globarr.contact_id != "" || globarr.contact_id != undefined ||  globarr.contact_id != null){
		    customerData.CustomerContact = globarr.contact_id;
		  }
		 	//var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
		 	if(globarr.simprodomain.includes("simprosuite") == true)
			{
				 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
			}
			else if(globarr.simprodomain.includes("simprocloud") == true)
			{
				 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
			}
			var reqObj= {
			  url : baseurl+'api/v1.0/companies/'+company_id+'/quotes/',
			  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
			  type : 'POST',
			  data : {}, 
			  postBody : customerData,
			}
			ZOHODESK.request( reqObj ).then(function(response)
			{ 
					var responseArr = JSON.parse(response);
					if(responseArr.statusCode == 401)
					{
					  		token_message();
					}
					var dataArrJson = responseArr.response; 
					var quoteDataArr = JSON.parse(dataArrJson);    
					var messages="";
					//console.log(quoteDataArr);
					if(responseArr.statusCode == 422 && quoteDataArr.errors != undefined && quoteDataArr.errors.length > 0)
					{
						simproerrors = quoteDataArr.errors; 
						if(simproerrors.length > 0){
							for (var i = 0; i < simproerrors.length; i++) { 
								$('#Quote_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
							}   
							hide_loader(); 
						} 
					}
					else
					{ 
						var quote_id = quoteDataArr.ID; 
						//console.log(quoteDataArr);
						// var CustomFieldsArr = quoteDataArr.CustomFields;  
						// //console.log(CustomFieldsArr);
						// for (var i = 0; i < CustomFieldsArr.length; i++) {
						// 	if(CustomFieldsArr[i]['CustomField']['Name'] == "Ticket Id")
						// 	{  
						// 		updateDeskTicketIdInSimpro(globarr,quote_id,CustomFieldsArr[i]['CustomField']['ID'],'quotes',"Quote_Message_Log"); 
						// 		break;
						// 	} 
						// }  
						var quote_url =  "https://"+globarr.simproSubDomain+"."+globarr.simprodomain+".com/staff/editProject.php?quoteID="+quoteDataArr.ID;
						$("#quote_link").html(quote_url); 
						$("#quote_link").attr("href",quote_url); 
						$("#Quote_Message_Log").html("Quote Created Successfully!");
						$("#Quote_Number").val(quoteDataArr.ID);
						var postedData = { "cf_simpro_quote_number":quoteDataArr.ID,"cf_simpro_company_id":globarr.company_id};
						var updateData = {"cf":postedData};
						if(globarr.simpro_cost_center != null)
							{
							create_costcenter(globarr,'quotes',quote_id);
							}
						getallquotenotes(globarr,'quotes',quote_id);
						updateticket(globarr.tic_id,updateData);		
					}
			}).catch(function(err){
				//console.log(err);
$('#Hidden_Message_Log').text(err); 
			}) 


		}

		function getallquotenotes(globarr,module_name,module_id)
		{   

		 	if(globarr.simprodomain.includes("simprosuite") == true)
			{
				 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
			}
			else if(globarr.simprodomain.includes("simprocloud") == true)
			{
				 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
			}

			var reqObj= {
			  url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/'+module_name+'/'+module_id+'/notes/',
			  headers : { 'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
		     type : 'GET',
		     data : {},
		     postBody : {},
		     fileObj: [],
		 	} 
		 	// console.log(reqObj);
			ZOHODESK.request( reqObj ).then(function(response)
			{
				var create_new = true;
				var responseArr = JSON.parse(response);  
				var responseResponseArr = JSON.parse(responseArr.response); 
				// console.log(responseResponseArr);
				// console.log(globarr.tic_number);
				if(responseResponseArr.length > 0)
				{
					for (var i = 0; i < responseResponseArr.length; i++) { 
					var ReferenceArr = responseResponseArr[i]['Reference'];
					var tic_Subject = responseResponseArr[i]['Subject'];
						if((tic_Subject.indexOf(globarr.tic_number) !== -1)){  
							var create_new = false;
							break;
						}
					}
					if(create_new == true)
					{ 
						createquotenote(globarr,module_name,module_id);
					}
				}
				else{ 
						createquotenote(globarr,module_name,module_id);
				}
				hide_loader(); 
			    hide_jobloader();
			}).catch(function(err){
			    hide_loader(); 
			    hide_jobloader(); 
				// console.log(err); 
			}) 
		}

		function createquotenote(globarr,module_name,module_id)
		{  
 
			var quote_job_note = globarr.timeline_notes_quote;
			if(module_name == "quotes")
			quote_job_note = globarr.timeline_notes_quote;
			else 
			quote_job_note = globarr.timeline_notes_job; 

//			var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/'; 

			if(globarr.simprodomain.includes("simprosuite") == true)
			{
				 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
			}
			else if(globarr.simprodomain.includes("simprocloud") == true)
			{
				 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
			}

			var reqObj= {
			  url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/'+module_name+'/'+module_id+'/notes/',
			  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
			  type : 'POST',
			  data : {}, 
			  postBody : quote_job_note,
			}
			ZOHODESK.request( reqObj ).then(function(response)
			{
			//console.log(response); 
			}).catch(function(err){
				//console.log(err);
				// $('#Hidden_Message_Log').text(err); 
			}) 
		}



/* below function is triggerd when somebody clicked on create quote button   */
		$("#createQuote").click(function()
		{ 


			// console.log(globarr);
			$('#Quote_Message_Log').text("Processing..."); 
			show_loader();    
			var Report_Tag = $("#Report_Tag").val();
			var Selected_Tags = $("#Selected_Tags").val();
			var Simpro_New_Tag_ids = $("#New_Tag_Ids").val(); 
			var Simpro_Selected_Tag_Ids = $("#Selected_Tag_Ids").val(); 


			globarr.simpro_report_tag = Report_Tag;	
			globarr.Simpro_Selected_Tag_Ids = Simpro_Selected_Tag_Ids;	
			globarr.Simpro_New_Tag_ids = Simpro_New_Tag_ids;

			var Cost_Center = $("#Cost_Center").val();			
			var default_project_type_new = $("#default_project_type_new").val(); 
			globarr.simpro_cost_center = Cost_Center;
			if(default_project_type_new != "Service")
			{
				globarr.simpro_cost_center = null;
			}

			var due_date = $("#due_date").val();
			var simpro_customer_id = $("#simpro_customer_id").val();
			var simpro_customer_site_id = $("#simpro_customer_site_id").val(); 
			var description = $("#description").val(); 
			var company_id = $("#Simpro_Company_ID").val();   
			var contactName = $("#contactName").val();  
			var order_number = $("#Order_Number").val(); 

			var default_project_type_new = $("#default_project_type_new").val(); 
			globarr.default_project_type = default_project_type_new;

			globarr.due_date = due_date;
			globarr.order_number = order_number;

			globarr.simpro_customer_id = simpro_customer_id;
			globarr.simpro_customer_site_id = simpro_customer_site_id; 
			globarr.description = description;
			globarr.company_id = company_id;
			globarr.contactName = contactName; 
 			let returnm = addMessageOnError(globarr,"Quote_Message_Log") ; 

			if(returnm == true)
			{
				return;
			}

			if(simpro_customer_id == "" && globarr.create_customer == false)
			{ 
				$("#simpro_customer_id").val(globarr.default_customer_id); 
				simpro_customer_id = globarr.default_customer_id;
				globarr.simpro_customer_id = globarr.default_customer_id;
			}

			if(simpro_customer_id == "")
			{ 
				$('#Quote_Message_Log').text("Creating Customer In Simpro..."); 
				var customerData = {};
					// customerData.CompanyName = globarr.contactName; 
					customerData.Email = globarr.email; 
					customerData.Phone = globarr.phone;  
					let default_customer_type = globarr.default_customer_type;
					default_customer_type = default_customer_type.toLowerCase();
				    if(default_customer_type == "companies")
					{ 
						customerData.CompanyName = globarr.contactName;
					}
					else if(default_customer_type == "individuals")
					{
						var flnameArr = globarr.contactName;
						flnameArr = flnameArr.split(" ");
						customerData.GivenName = flnameArr[0];
						if(flnameArr.length > 1)
						customerData.FamilyName = flnameArr[1]; 
						else
						customerData.FamilyName = flnameArr[0]; 	

					}
					else
					{
						$('#Quote_Message_Log').text("Please check your customers type configruation settings... Please set only Individuals Or Companies"); 
						hide_loader();
						return;
					}


			if(globarr.simprodomain.includes("simprosuite") == true)
				{
					 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
				}
				else if(globarr.simprodomain.includes("simprocloud") == true)
				{
					 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
				}


				var reqObj= {
			      url : baseurl+'api/v1.0/companies/'+company_id+'/customers/'+default_customer_type+'/',
			      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
			      type : 'POST',
			      data : {}, 
			      postBody : customerData,
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{ 
					// console.log(response);
					var responseArr = JSON.parse(response); 
					if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
					var dataArrJson = responseArr.response; 
					var dataArr = JSON.parse(dataArrJson);
					// console.log(dataArr);
					if(dataArr.errors != '' && dataArr.errors != undefined )
					{ 
						simproerrors = dataArr.errors;  
					$('#Quote_Message_Log').text("");
						if(simproerrors.length > 0){
							for (var i = 0; i < simproerrors.length; i++) { 
								$('#Quote_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
							}  
						hide_loader();
						} 
					}
					else
					{
						simpro_customer_id = dataArr.ID; 
						globarr.simpro_customer_id = simpro_customer_id;
						$("#simpro_customer_id").val(globarr.simpro_customer_id);
						if(simpro_customer_id == "")
						{
							$('#Quote_Message_Log').text("Some Technical Error..."); 
							hide_loader();
						}
						else
						{
							$('#Quote_Message_Log').text("Customer Created Successfully...Now creating quote please wait..."); 

						let tags =globarr.Simpro_Selected_Tag_Ids;
						let tagArray = tags.split(',');	

						processTags(tagArray,globarr,"Quote"); 
			//				createQuoteinSimpro(globarr);
						}
					}
				}).catch(function(err){

					$('#Hidden_Message_Log').text(err); 
					var responseArr = JSON.parse(err); 
					if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
					var dataArrJson = responseArr.response; 
					var dataArr = JSON.parse(dataArrJson);
					if(dataArr.errors != '' && dataArr.errors != undefined )
					{ 
						simproerrors = dataArr.errors;  
					$('#Quote_Message_Log').text("");
						if(simproerrors.length > 0){
							for (var i = 0; i < simproerrors.length; i++) { 
								$('#Quote_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
							}  
						hide_loader();
						} 
					}
				}) 
			}
			else
			{ 
				let tags =globarr.Simpro_Selected_Tag_Ids;
				let tagArray = tags.split(',');	

				processTags(tagArray,globarr,"Quote"); 
			  //createQuoteinSimpro(globarr);    
			} 
		});

 
/* below function is triggerd when somebody clicked on create job button   */
		// createJob
		$("#createJob").click(function()
		{ 

			//console.log(globarr);
			$('#Job_Message_Log').text("Processing...");  
			show_jobloader();	  
			var Report_Tag = $("#Report_Tag").val();

			var Selected_Tags = $("#Selected_Tags").val();
			var Simpro_New_Tag_ids = $("#New_Tag_Ids").val(); 
			var Simpro_Selected_Tag_Ids = $("#Selected_Tag_Ids").val(); 


			globarr.simpro_report_tag = Report_Tag;	
			globarr.Simpro_Selected_Tag_Ids = Simpro_Selected_Tag_Ids;	
			globarr.Simpro_New_Tag_ids = Simpro_New_Tag_ids;


			var Cost_Center = $("#Cost_Center").val();			
			var default_project_type_new = $("#default_project_type_new").val(); 
			globarr.simpro_cost_center = Cost_Center;
			if(default_project_type_new != "Service")
			{
				globarr.simpro_cost_center = null;
			}
			var due_date = $("#due_date").val();
			var simpro_customer_id = $("#simpro_customer_id").val();
			var simpro_customer_site_id = $("#simpro_customer_site_id").val();
			var Default_Site_ID = $("#Default_Site_ID").val();  
			var description = $("#description").val(); 
			var company_id = $("#Simpro_Company_ID").val();  
			var cf_simpro_quote_number = $("#Quote_Number").val();   
			var contactName = $("#contactName").val();  
			var order_number = $("#Order_Number").val();  

			var default_project_type_new = $("#default_project_type_new").val(); 
			globarr.default_project_type = default_project_type_new;
			globarr.due_date = due_date;
			globarr.order_number = order_number;
			globarr.simpro_customer_id = simpro_customer_id;
			globarr.simpro_customer_site_id = simpro_customer_site_id;
			globarr.Default_Site_ID = Default_Site_ID; 
			globarr.description = description;
			globarr.company_id = company_id;
			globarr.contactName = contactName; 
			globarr.quote_number = cf_simpro_quote_number; 
 
			let returnm = addMessageOnError(globarr,"Job_Message_Log") ; 

			if(returnm == true)
			{
				return;
			}
			if(simpro_customer_id == "" && globarr.create_customer == false)
			{ 
				$("#simpro_customer_id").val(globarr.default_customer_id); 
				simpro_customer_id = globarr.default_customer_id;
				globarr.simpro_customer_id = globarr.default_customer_id;
			}

			//console.log(globarr);
			if(simpro_customer_id == "")
			{ 
				$('#Job_Message_Log').text("Creating Customer In Simpro..."); 
				var customerData = {};
					// customerData.CompanyName = globarr.contactName; 
					customerData.Email = globarr.email; 
					customerData.Phone = globarr.phone;  
					var sentdata = {};  

					let default_customer_type = globarr.default_customer_type;
			        default_customer_type = default_customer_type.toLowerCase();
				    if(default_customer_type == "companies")
					{ 
						customerData.CompanyName = globarr.contactName;
					}
					else if(default_customer_type == "individuals")
					{
						var flnameArr = globarr.contactName;
						flnameArr = flnameArr.split(" ");
						customerData.GivenName = flnameArr[0];
						if(flnameArr.length > 1)
						customerData.FamilyName = flnameArr[1]; 
						else
						customerData.FamilyName = flnameArr[0]; 	

					}
					else
					{
						$('#Quote_Message_Log').text("Please check your customers type configruation settings... Please set only Individuals Or Companies"); 
						hide_jobloader();
						return;
					}

					if(globarr.simprodomain.includes("simprosuite") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
	}
	else if(globarr.simprodomain.includes("simprocloud") == true)
	{
		 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
	}


					var reqObj= {
			      url : baseurl+'api/v1.0/companies/'+company_id+'/customers/'+default_customer_type+'/',
			      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
			      type : 'POST',
			      data : {}, 
			      postBody : customerData,
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{ 
					var responseArr = JSON.parse(response); 
					if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
					var dataArrJson = responseArr.response; 
					var dataArr = JSON.parse(dataArrJson);
					if(dataArr.errors != '' && dataArr.errors != undefined )
					{ 
						simproerrors = dataArr.errors;  
					$('#Job_Message_Log').text("");
						if(simproerrors.length > 0){
							for (var i = 0; i < simproerrors.length; i++) { 
								$('#Job_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
							}  
							hide_jobloader();
						} 
					}
					else
					{
						simpro_customer_id = dataArr.ID; 

						globarr.simpro_customer_id = simpro_customer_id; 
						$("#simpro_customer_id").val(globarr.simpro_customer_id);
						if(simpro_customer_id == "")
						{
							$('#Job_Message_Log').text("Some Technical Error..."); 
							hide_jobloader();
						}
						else
						{
							$('#Job_Message_Log').text("Customer Created Successfully...Now creating Job please wait...");  
								let tags =globarr.Simpro_Selected_Tag_Ids;
						let tagArray = tags.split(',');	
							processTags(tagArray,globarr,"Job"); 
							//createJobinSimpro(globarr);
						}
					}
				}).catch(function(err){ 
					//console.log(err);
$('#Hidden_Message_Log').text(err); 
					var responseArr = JSON.parse(err); 
					if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
					var dataArrJson = responseArr.response; 
					var dataArr = JSON.parse(dataArrJson);
					if(dataArr.errors != '' && dataArr.errors != undefined )
					{ 
						simproerrors = dataArr.errors;  
					$('#Job_Message_Log').text("");
						if(simproerrors.length > 0){
							for (var i = 0; i < simproerrors.length; i++) { 
								$('#Job_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
							}  
							hide_jobloader();
						} 
					}
				}) 
			}
			else
			{ 
					let tags =globarr.Simpro_Selected_Tag_Ids;
						let tagArray = tags.split(',');	
				processTags(tagArray,globarr,"Job"); 
			  //createJobinSimpro(globarr);    
			} 

		}); 

$("#default_project_type_new").click(function()
		{

			show_loader(); 
 			
				var default_project_type_new = $("#default_project_type_new").val(); 
				if(default_project_type_new == "Project")
				{
					
		$("#Simpro_Type_Cost_Center_Block").css("display","none");  
	
				}
				else
				{

					$("#Simpro_Type_Cost_Center_Block").css("display","block"); 

				}

			globarr.default_project_type = default_project_type_new;

 			hide_loader();



		});


function fetch_quote_cost_center(globarr)
		{
		show_loader();  	

			if(globarr.simprodomain.includes("simprosuite") == true)
			{
				 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
			}
			else if(globarr.simprodomain.includes("simprocloud") == true)
			{
				 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
			}

//get /api/v1.0/companies/{companyID}/setup/accounts/costCenters/


			var reqObj= 
			{
		      url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/setup/accounts/costCenters/',
		      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
		      type : 'GET',
				     data : {},
				     postBody : {},
				     fileObj: [],
			}

			ZOHODESK.request( reqObj ).then(function(response)
			{ 
				var responseArr = JSON.parse(response); 
				
				var dataArrJson = responseArr.response; 
				var dataArr = JSON.parse(dataArrJson);
				if(dataArr.length > 0)
				{
					for (var i = 0; i < dataArr.length; i++) {

					var  costcenter_name = dataArr[i].Name;
					var   costcenter_id = dataArr[i].ID;
					$('#Cost_Center').append($('<option></option>').val(costcenter_id).text(costcenter_name));
					}
				}

			}).catch(function(err)
			{
				console.log(err);
				// $('#Hidden_Message_Log').text(err); 
				// var responseArr = JSON.parse(err); 
				// if(responseArr.statusCode == 401)
				//   	{
				//   		token_message();
				//   	}
				// var dataArrJson = responseArr.response; 
				// var dataArr = JSON.parse(dataArrJson);
				// if(dataArr.errors != '' && dataArr.errors != undefined )
				// { 
				// 	simproerrors = dataArr.errors;  
				// $('#'+display_log).text("");
				// 	if(simproerrors.length > 0){
				// 		for (var i = 0; i < simproerrors.length; i++) { 
				// 			$('#'+display_log).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
				// 		}  
				// 	hide_loader();
				// 	} 
				// }
			}) 

			show_jobloader();
			hide_loader();
			hide_jobloader();
		}

		function create_costcenter(globarr,module_name,quo_number)
		{ 
			 	var customerData1  = {};

				if(globarr.simprodomain.includes("simprosuite") == true)
				{
					 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
				}
				else if(globarr.simprodomain.includes("simprocloud") == true)
				{
					 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
				}

				var reqObj= {
				  url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/'+module_name+'/'+quo_number+'/sections/',
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'POST',
				  data : {}, 
				  postBody : JSON.stringify(customerData1),
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{
						var responseArr = JSON.parse(response);						
						if(responseArr.statusCode == 401)
						  	{
						  		token_message();
						  	}
						
						var messages="";
						if(responseArr.statusCode == 422 )
						{
							var dataArrJson = responseArr.response; 
							var quoteDataArr = JSON.parse(dataArrJson);  
							simproerrors = quoteDataArr.errors; 
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Quote_Message_Log').html(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}   
								hide_loader(); 
							} 
						}
						else 
						{  
							var dataArrJson = responseArr.response; 
						var quoteDataArr = JSON.parse(dataArrJson); 

					var Simpro_Section_ID =  quoteDataArr.ID;
					globarr.Simpro_Section_ID = Simpro_Section_ID;
					if(Simpro_Section_ID != null)
					{

				var customerData1  = {"CostCenter":parseInt(globarr.simpro_cost_center)};

				if(globarr.simprodomain.includes("simprosuite") == true)
				{
					 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
				}
				else if(globarr.simprodomain.includes("simprocloud") == true)
				{
					 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
				}

				var reqObj1= {
				  url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/'+module_name+'/'+quo_number+'/sections/'+Simpro_Section_ID+'/costCenters/',
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'POST',
				  data : {}, 
				  postBody : customerData1,
				}
				ZOHODESK.request( reqObj1 ).then(function(response)
				{
						var responseArr1 = JSON.parse(response);
						var responseArr = JSON.parse(response);
						if(responseArr.statusCode == 401)
						  	{
						  		token_message();
						  	}
						
						var messages="";
						if(responseArr.statusCode == 422 )
						{
							var dataArrJson = responseArr.response; 
							var quoteDataArr = JSON.parse(dataArrJson);  

							simproerrors = quoteDataArr.errors; 
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Quote_Message_Log').html(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}   
								hide_loader(); 
							} 
						}
						else 
						{  
							var dataArrJson = responseArr.response; 
							var quoteDataArr = JSON.parse(dataArrJson); 
							//$('#Quote_Message_Log').append("Quote Updated Successfully!");  
							hide_loader(); 
								
								
						}
				}).catch(function(err){
					//console.log(err);
					$('#Hidden_Message_Log').text(err); 
				}) 


					}
							
							
								
						}
				}).catch(function(err){
					console.log(err);
					$('#Hidden_Message_Log').text(err); 
				}) 

		}


		function fetch_quote_report_tag(globarr)
		{
		
			show_loader(); 
			if(globarr.simprodomain.includes("simprosuite") == true)
				{
					 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
				}
				else if(globarr.simprodomain.includes("simprocloud") == true)
				{
					 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
				}

			var reqObj= 
			{
		      url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/setup/tags/projects/',
		      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
		      type : 'GET',
				     data : {},
				     postBody : {},
				     fileObj: [],
			}
			ZOHODESK.request( reqObj ).then(function(response)
			{ 
				var responseArr = JSON.parse(response); 
				var dataArrJson = responseArr.response; 
				var dataArr = JSON.parse(dataArrJson);
				// console.log("tag -");
				// console.log(dataArr);
				if(dataArr.length > 0)
				{
					for (var i = 0; i < dataArr.length; i++) {
					var  reporttag_name = dataArr[i].Name;
					var   reporttag_id = dataArr[i].ID;
					$('#Report_Tag').append($('<option></option>').val(reporttag_id).text(reporttag_name));
					}
				}

			}).catch(function(err)
			{
				console.log(err);
				$('#Hidden_Message_Log').text(err); 
				// var responseArr = JSON.parse(err); 
				// if(responseArr.statusCode == 401)
				//   	{
				//   		token_message();
				//   	}
				// var dataArrJson = responseArr.response; 
				// var dataArr = JSON.parse(dataArrJson);
				// if(dataArr.errors != '' && dataArr.errors != undefined )
				// { 
				// 	simproerrors = dataArr.errors;  
				// $('#'+display_log).text("");
				// 	if(simproerrors.length > 0){
				// 		for (var i = 0; i < simproerrors.length; i++) { 
				// 			$('#'+display_log).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
				// 		}  
				// 	hide_loader();
				// 	} 
				// }
			}) 
			show_jobloader();
			hide_loader();
			hide_jobloader();
		}
		
/* below function is used to proccess job responses   */
		function processJobinSimpro(globarr,response)
		{ 
			var responseArr = JSON.parse(response);
			if(responseArr.statusCode == 401)
			{
					token_message();
			}
			var dataArrJson = responseArr.response; 
			var quoteDataArr = JSON.parse(dataArrJson);    
			var messages="";
			if(quoteDataArr.hasOwnProperty('errors') && quoteDataArr.errors != undefined  && quoteDataArr.errors.length > 0)
			{ 
				simproerrors = quoteDataArr.errors; 
				if(simproerrors.length > 0){
					for (var i = 0; i < simproerrors.length; i++) { 
						$('#Job_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
					}    
				hide_jobloader();
				} 
			}
			else
			{
				//console.log(quoteDataArr);
				var job_id = quoteDataArr.ID; 
				// var CustomFieldsArr = quoteDataArr.CustomFields;  
				// //console.log(CustomFieldsArr);
				// for (var i = 0; i < CustomFieldsArr.length; i++) {
				// 	if(CustomFieldsArr[i]['CustomField']['Name'] == "Ticket Id")
				// 	{  
				// 		updateDeskTicketIdInSimpro(globarr,job_id,CustomFieldsArr[i]['CustomField']['ID'],'jobs',"Job_Message_Log"); 
				// 		break;
				// 	} 
				// }

				var quote_url =  "https://"+globarr.simproSubDomain+"."+globarr.simprodomain+".com/staff/editProject.php?jobID="+quoteDataArr.ID;
				$("#job_link").html(quote_url); 
				$("#job_link").attr("href",quote_url); 
				$("#Job_Message_Log").html("Job Created Successfully!");
				$("#Job_Number").val(quoteDataArr.ID);
				var postedData = { "cf_simpro_job_number":quoteDataArr.ID,"cf_simpro_company_id":globarr.company_id};
				var updateData = {"cf":postedData};
				if(globarr.simpro_cost_center != null)
				{
				create_costcenter(globarr,'jobs',job_id);
				}
				getallquotenotes(globarr,'jobs',job_id);
				updateticket(globarr.tic_id,updateData);		
			} 
		}

/* below function is used create job in simpro   */
		function createJobinSimpro(globarr)
		{ 
			let private_notes = '=====================================================<br><br>This Job / Quote has been created from the Zohodesk Ticket: '+globarr.tic_id+' <br> <br> \n Zohodesk Ticket URL : <a href="'+globarr.ticket_url+'">'+globarr.ticket_url+'</a><br><br>=====================================================';

			if(globarr.simpro_customer_site_id == "")
				globarr.simpro_customer_site_id = globarr.default_site_id;
 
			var company_id = globarr.company_id; 
			var customerData = {};
			customerData.Customer = parseInt(globarr.simpro_customer_id); 
			customerData.Type = globarr.default_project_type;

			if(globarr.due_date != "") 
			customerData.DueDate = globarr.due_date; 

			if(globarr.order_number)
			customerData.OrderNo = globarr.order_number;

		// if (globarr.simpro_report_tag) {
		// 	  customerData.Tags = [parseInt(globarr.simpro_report_tag)];
		// 	}

			var All_Tag_Ids = $("#All_Tag_Ids").val();
			globarr.All_Tag_Ids = All_Tag_Ids;
 			//console.log("All_Tag_Ids - "+ All_Tag_Ids);

			if (All_Tag_Ids) {
			  var Tags_li = [All_Tag_Ids];
			  var Tags = Tags_li[0].split(',').map(Number);
			  customerData.Tags = Tags;

			}

			customerData.Description = globarr.description;   
			customerData.Site = parseInt(globarr.simpro_customer_site_id); 
		//	customerData.Notes = private_notes;
			customerData.Name = globarr.ticket_subject;

			if(globarr.contact_id != "" || globarr.contact_id != undefined ||  globarr.contact_id != null){
		    customerData.CustomerContact = globarr.contact_id;
		  }

		 	//var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
		 	if(globarr.simprodomain.includes("simprosuite") == true)
			{
				 	var baseurl = 'https://{{simprosubdomain}}.simprosuite.com/';
			}
			else if(globarr.simprodomain.includes("simprocloud") == true)
			{
				 	var baseurl = 'https://{{simprosubdomain}}.simprocloud.com/';
			}
		 	var quote_aim = "jobs";
		 	if(globarr.quote_number == "")
		 	{   
				var reqObj= {
				  url : baseurl+'api/v1.0/companies/'+company_id+'/jobs/',
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'POST',
				  data : {}, 
				  postBody : customerData,
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{  
					processJobinSimpro(globarr,response);
						
				}).catch(function(err){
					//console.log(err);
$('#Hidden_Message_Log').text(err); 
				})   
			}
			else if(globarr.quote_number != "")
			{  
				$('#Job_Message_Log').text("Processing...Converting quote to job.");  

				var reqObj= {
				  url : baseurl+'api/v1.0/companies/'+company_id+'/quotes/'+globarr.quote_number+'/convert/',
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'POST',
				  data : {}, 
				  postBody : customerData,
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{  
					processJobinSimpro(globarr,response);
						
				}).catch(function(err){
					//console.log(err);
$('#Hidden_Message_Log').text(err); 
				})  

			} 
		}  		
	}).catch(function(err){
		//console.log(err);
$('#Hidden_Message_Log').text(err); 
	})
};








