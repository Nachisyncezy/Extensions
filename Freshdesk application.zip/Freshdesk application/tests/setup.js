// Global test setup - using CommonJS syntax

// Mock Freshworks Client
global.mockClient = {
  initialized: jest.fn(),
  events: { on: jest.fn() },
  instance: { resize: jest.fn() },
  data: { get: jest.fn() },
  iparams: { get: jest.fn() },
  request: { invokeTemplate: jest.fn() }
};

// Mock app object
global.app = {
  initialized: jest.fn().mockResolvedValue(global.mockClient)
};

// Mock jQuery
global.$ = jest.fn((selector) => ({
  text: jest.fn().mockReturnThis(),
  val: jest.fn().mockReturnThis(),
  append: jest.fn().mockReturnThis(),
  addClass: jest.fn().mockReturnThis(),
  removeClass: jest.fn().mockReturnThis(),
  css: jest.fn().mockReturnThis(),
  change: jest.fn().mockReturnThis(),
  click: jest.fn().mockReturnThis(),
  each: jest.fn().mockReturnThis(),
  attr: jest.fn().mockReturnThis()
}));

global.$.each = jest.fn((array, callback) => {
  if (Array.isArray(array)) {
    array.forEach((item, index) => callback(index, item));
  }
});

// Mock DOM
global.document = {
  getElementById: jest.fn(() => ({
    value: '',
    textContent: '',
    innerHTML: '',
    innerText: '',
    style: { display: 'block' },
    setAttribute: jest.fn(),
    insertAdjacentText: jest.fn()
  })),
  addEventListener: jest.fn()
};

// Mock localStorage
global.localStorage = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn()
};

// Mock console to reduce test noise
global.console = {
  ...console,
  log: jest.fn(),
  error: jest.fn(),
  warn: jest.fn()
};

// Reset before each test
beforeEach(() => {
  jest.clearAllMocks();
  global.client = global.mockClient;
  global.GlobalArr = {};
});
