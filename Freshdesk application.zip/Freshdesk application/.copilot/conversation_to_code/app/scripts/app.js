let client;
const globalArray = []; // Global array to store contact and ticket details
=======
```

app/scripts/app.js
```javascript
<<<<<<< SEARCH
async function fetchContactAndTicket() {
    const textElement = document.getElementById("apptext");
    let comapnyIdArr  = {};
    let DefaultSiteArr = {};
    const DefaultCustomerArr = {};

//nm

    try {

      client.instance.resize({ height: "500px" });
        const contactData = await client.data.get("contact");
        const iparams = await client.iparams.get();
        const {
            contact: { name, email, phone },
        } = contactData;

        const ticketData = await client.data.get("ticket");
        const {
            ticket: { subject, description_text, ticket_number, id },
        } = ticketData;

        
=======
async function fetchContactAndTicket() {
    const textElement = document.getElementById("apptext");
    let comapnyIdArr  = {};
    let DefaultSiteArr = {};
    const DefaultCustomerArr = {};

//nm

    try {

      client.instance.resize({ height: "500px" });
        const contactData = await client.data.get("contact");
        const iparams = await client.iparams.get();
        const {
            contact: { name, email, phone },
        } = contactData;

        const ticketData = await client.data.get("ticket");
        const {
            ticket: { subject, description_text, ticket_number, id },
        } = ticketData;

        setGlobalArray(contactData, ticketData, iparams);

init();

async function init() {
    client = await app.initialized();
    client.events.on("app.activated", fetchContactAndTicket);

    //document.getElementById("createQuote").addEventListener("click", getContacts);
}
const currentContact = {};
const currentTicket = {};

async function fetchContactAndTicket() {
    const textElement = document.getElementById("apptext");
    let comapnyIdArr  = {};
    let DefaultSiteArr = {};
    const DefaultCustomerArr = {};

//nm

    try {

      client.instance.resize({ height: "500px" });
        const contactData = await client.data.get("contact");
        const iparams = await client.iparams.get();
        const {
            contact: { name, email, phone },
        } = contactData;

        const ticketData = await client.data.get("ticket");
        const {
            ticket: { subject, description_text, ticket_number, id },
        } = ticketData;

        GlobalArr.email = email;
        GlobalArr.phone = phone;
        GlobalArr.contactName = name;
        GlobalArr.ticket_subject = subject;
        GlobalArr.description = description_text;
        GlobalArr.tic_number = ticket_number;
        GlobalArr.tic_id = id;
        
        GlobalArr.Freshdesk_admin_email = iparams.admin_email;
        GlobalArr.freshdesk_subdomain = iparams.freshdesk_subdomain;
        GlobalArr.freshdesk_api_key = iparams.freshdesk_api_key;
        GlobalArr.simpro_domain_prefix = iparams.simpro_domain_prefix;
        GlobalArr.multi_company = iparams.multi_company;
        GlobalArr.simpro_api_key = iparams.simpro_api_key;
        GlobalArr.simpro_customer_type = iparams.simpro_customer_type;
        GlobalArr.simpro_project_type = iparams.simpro_project_type;
        GlobalArr.create_customer_check = iparams.create_customer_check;

        const freshdesk_ticket_url = "https://"+globalArray.freshdesk_subdomain +".freshdesk.com/a/tickets/"+globalArray.tic_id;
        globalArray.ticket_url = freshdesk_ticket_url;
        const timeline_notes_quote = {"Subject":"This quote has been linked from the FreshDesk ticket ID #"+globalArray.tic_number,"Note":"FreshDesk ticket URL: <a target='_blank' href='"+globalArray.ticket_url+"'>"+globalArray.ticket_url+"</a>"};
        const timeline_notes_job = {"Subject":"This Job has been linked from the FreshDesk ticket ID #"+globalArray.tic_number,"Note":"FreshDesk ticket URL: <a  target='_blank' href='"+globalArray.ticket_url+"'>"+globalArray.ticket_url+"</a>"}; 
        globalArray.timeline_notes_quote = timeline_notes_quote; 
        globalArray.timeline_notes_job = timeline_notes_job;

        //console.log("ticketData - "+ ticketData.custom_fields)   ; 

        let multicompany = false;
        if (globalArray.multi_company.toUpperCase() === "YES") {
            multicompany = true;
           // document.getElementById("Simpro_Company_ID_block").style.display = "block";
            $("#Simpro_Company_ID_block").css("display","block");  

        }
        //console.log(multicompany);

        //********************Default Customer******************


        const defaultcustarray = iparams.default_customer_id;
        const defaultcustArr = defaultcustarray.split(',');   
          $.each(defaultcustArr,function(j)
          {  
            if(isNaN(defaultcustArr[j]))
            {
               const _default_cust_error = "Please check the configuration settings... Please set value for default customer only number.";
                $('#Quote_Message_Log').text(_default_cust_error); 
                $('#Job_Message_Log').text(_default_cust_error);  
                hide_loader();
                return;
              }
              else{
                DefaultCustomerArr[j] = defaultcustArr[j];
                if(j === 0){ 
                  $('#Default_Cusotmer_ID').append($("<option></option>")
                        .attr("value", defaultcustArr[j])
                        .attr("selected","selected")
                                .text(defaultcustArr[j]));    
                          globalArray.default_customer_id = defaultcustArr[j];
                        }
                        else
                        {
                          $('#Default_Cusotmer_ID').append($("<option></option>")
                                .attr("value", defaultcustArr[j])
                                .text(defaultcustArr[j]));  
                        } 
                      } 
          });  


        //********************Default Site******************
        const sitesArr = iparams.default_site_id;
        const sarray = sitesArr.split(",");

            $.each(sarray,function(j)
            {  
              if(isNaN(sarray[j])){
                  $('#Quote_Message_Log').text("Please check the configuration settings... Please set value for default sites only number."); 
                  hide_loader();
                  return true; 
                }

              DefaultSiteArr[j] = sarray[j];
              if(j === 0){ 
                $('#Default_Site_ID').append($("<option></option>")
                      .attr("value", sarray[j])
                      .attr("selected","selected")
                      .text(sarray[j]));    
                  $('#Default_Site_ID option[value="'+sarray[j]+'"]').attr("selected", "selected");


                globalArray.default_site_id = sarray[j];
              }
              else
              {
                $('#Default_Site_ID').append($("<option></option>")
                      .attr("value", sarray[j])
                      .text(sarray[j]));  
              }
            }); 

      //********************Default SimPRO Companies******************
      const Simpro_Companiesd = iparams.simpro_companies;
      const array = Simpro_Companiesd.split(',');
      let first_company_id = "";
      const companyDropdown = document.getElementById("Simpro_Company_ID");
       companyDropdown.innerHTML = ""; 
      $.each(array,function(k)
            {   
              if(array[k].search("-") === -1){
                $('#Quote_Message_Log').text("Please check the configuration settings... Please set value for Simpro Companies like '6 - Zoho Simpro, 10 - Dev Admin'."); 
                hide_loader();
                return true; 
              }
              const companyArr = array[k].split('-');    
              if(companyArr.length > 0)
              {
                const comp_id = companyArr[0].trim();
                const comp_name = companyArr[1].trim();   
                comapnyIdArr[k] = comp_id;
                if(k === 0) { 
                  first_company_id = comp_id;  
                //console.log("first_company_id");
                //console.log(first_company_id);
                  $('#Simpro_Company_ID').append($("<option></option>")
                            .attr("value", comp_id)
                            .text(comp_name))
                          .attr("selected","selected");

                  $('#Simpro_Company_ID option[value="'+comp_id+'"]').attr("selected", "selected");
                          globalArray.company_id = comp_id;
                }else{
                  $('#Simpro_Company_ID').append($("<option></option>")
                              .attr("value", comp_id)
                              .text(comp_name)); 
                } 
              }
            }); 

           //********************Multi Company  *****************
            if(multicompany === true)
            {
              let set_company = ""; 
              const old_comapny_id = localStorage.getItem("company_id"); 
              if(old_comapny_id === "" || old_comapny_id === undefined) 
               set_company = first_company_id; 
              else
               set_company = old_comapny_id;    
              $('#Simpro_Company_ID option[value="'+set_company+'"]').attr("selected", "selected"); 
              comapnyIdArr = Object.values(comapnyIdArr)
              DefaultSiteArr = Object.values(DefaultSiteArr)
              const indexOfComapnyId = comapnyIdArr.indexOf(set_company);  
              const setSiteId =  DefaultSiteArr[indexOfComapnyId]; 
              if(setSiteId !== "") {
                 $('#Default_Site_ID option[value="'+setSiteId+'"]').attr("selected", "selected"); 
              }  
              globalArray.company_id = set_company;                
            }
         // eventCallback1(GlobalArr);
         //****************Simpro Company change***************
        
            $("#Simpro_Company_ID").change(function()
              { 
                show_loader();
                show_jobloader();
                const company_id =  $(this).val();  
                comapnyIdArr = Object.values(comapnyIdArr);
                DefaultSiteArr = Object.values(DefaultSiteArr);

                const indexOfComapnyId = comapnyIdArr.indexOf(company_id); 
                localStorage.setItem("company_id",company_id);
                const setSiteId =  DefaultSiteArr[indexOfComapnyId]; 
                // $("#Default_Site_ID").val(setSiteId);  
                 $('#Default_Site_ID option[value="'+setSiteId+'"]').attr("selected", "selected"); 
                GlobalArr.company_id = company_id;
                GlobalArr.default_site_id = setSiteId;

                const setdefaultcustId =  DefaultCustomerArr[indexOfComapnyId]; 
                GlobalArr.default_customer_id = setdefaultcustId;
                $("#simpro_customer_id").val("");
                $("#simpro_customer_site_id").val("");
                GlobalArr.simpro_customer_id = null;
                GlobalArr.simpro_customer_site_id = null;  
                getContacts(globalArray,0);    
                 //console.log(globalArray);
                loadticketnumbers(globalArray);
              }); 



//*****************GET CONTACT**************
//    try {
//     const contactData = await client.data.get("contact");
//     GlobalArr.contactData = contactData;
// //    //console.log(search_in_simpro);
//     //console.log(GlobalArr.company_id +"---"+GlobalArr.email);
//     const contactResponse = await client.request.invokeTemplate("getSimproContact", {
//             context: { company_id: GlobalArr.company_id, email: GlobalArr.email },
//         });
//     const contactsFromSimPRO = JSON.parse(contactResponse.response);
//     //console.log(contactsFromSimPRO);

//         if(contactsFromSimPRO.length > 0)
//         {
//           const full_detail_link = contactsFromSimPRO[0]['_href'];
//           getContactsSites(globalArray, full_detail_link);
//           //console.log(full_detail_link);
//         }
//         else
//         { 
//             searchincontacts(globalArray).then(function(data){
//             console.log("contact_customer_response");
//             console.log(data); 
//             if(data.status === 404)
//             {
//               status404(data,"Quote_Message_Log");
//             }
//             else
//             {
//               if(data.length === 0){
//                 $("#simpro_customer_id").val("");
//                 $("#simpro_customer_site_id").val("");
//                 hide_loader();
//                hide_jobloader();
//               } 
//               else
//               {
//                 const full_detail_link= "/api/v1.0/companies/"+GlobalArr.company_id+"/contacts/"+data[0]['ID']; 
//                 GlobalArr.contact_id = data[0]['ID']; 
//                 //getChildCustomerSites(GlobalArr,full_detail_link);
//                 getContactsSites(GlobalArr, full_detail_link);

//             // for (var i = 0; i < data.length; i++) 
//             // {  
//             //   var full_detail_link= "/api/v1.0/companies/"+globarr.company_id+"/contacts/"+data[i]['ID']; 
//             //   globarr.contact_id = data[i]['ID']; 
//             //   getChildCustomerSites(globarr,full_detail_link); 
//             //   break;
//             // } 


//               }
//             }
          
//           }).catch((err) => { 
//         console.log("contact not found",err);
//       }); 
//         }



// loadticketnumbers(GlobalArr);

//     }
//     catch (error) {
//         console.error("Error fetching Contact:", error);
//         document.getElementById("apptext").innerText = "Failed to fetch Simpro site details.";
//     }

//       client.events.on('ticket.propertiesUpdated', eventCallback1);
//       function eventCallback1() {
//       loadticketnumbers(GlobalArr);  
//   }


        //console.log("GlobalArr:", GlobalArr);
    } catch (error) {
        console.error("Error fetching data:", error);
        textElement.innerHTML = "Unable to fetch contact or ticket details.";
    }
}


describe('createQuoteinSimpro', () => {
  it('should create a quote in Simpro', async () => {
    const mockClient = {
      iparams: {
        get: jest.fn().mockResolvedValue({ simpro_domain_prefix: 'test' })
      },
      request: {
        invokeTemplate: jest.fn().mockResolvedValue({ response: JSON.stringify({ ID: 123 }) })
      }
    };
    global.client = mockClient;
    const GlobalArr = {
      company_id: 1,
      simpro_customer_id: 2,
      simpro_project_type: 'service',
      ticket_subject: 'Test Subject',
      due_date: '2023-10-10',
      description: 'Test Description',
      simpro_customer_site_id: 3
    };
    await createQuoteinSimpro(globalArray);
    expect(mockClient.request.invokeTemplate).toHaveBeenCalledWith('createSimproQuote', expect.any(Object));
  });
});

describe('fetchContactAndTicket', () => {
  it('should fetch contact and ticket data', async () => {
    const mockClient = {
      data: {
        get: jest.fn().mockResolvedValueOnce({ contact: { name: 'John Doe', email: 'john@example.com', phone: '1234567890' } })
                          .mockResolvedValueOnce({ ticket: { id: 1, subject: 'Test Ticket' } })
      },
      instance: {
        resize: jest.fn()
      },
      iparams: {
        get: jest.fn().mockResolvedValue({})
      }
    };
    global.client = mockClient;
    await fetchContactAndTicket();
    expect(mockClient.data.get).toHaveBeenCalledWith('contact');
    expect(mockClient.data.get).toHaveBeenCalledWith('ticket');
    expect(mockClient.instance.resize).toHaveBeenCalledWith({ height: '500px' });
  });
});

 async function searchincontacts(GlobalArr) 
  {    

     const contactResponse = await client.request.invokeTemplate("getSimproContact", {
            context: { company_id: GlobalArr.company_id, email: GlobalArr.email },
        });
    const contactsFromSimPRO = JSON.parse(contactResponse.response);

    return contactsFromSimPRO;
  }


// async function loadticketnumbers(GlobalArr)
//  {
//   try{
//      show_loader(); 
//      //show_jobloader(); 
//      const response = await client.request.invokeTemplate("getFreshdeskTicket", {
//       context: {
//         ticketID: GlobalArr.tic_id
//       }
//     });  
//     const ticketData = JSON.parse(response.response || "{}");
//     const customFields = ticketData.custom_fields || {};

//     // 2. Load Quote from SimPRO if available
//     if (customFields.cf_simpro_quote_number) {
//       const quoteId = String(customFields.cf_simpro_quote_number);
//       GlobalArr.quote_number = quoteId;

//       try {
//         const quoteResponse = await client.request.invokeTemplate("getSimproQuote", {
//           context: {
//             company_id: GlobalArr.company_id,
//             quote_id: quoteId
//           }
//         });
 
//              const quoteData = JSON.parse(quoteResponse.response || "{}");
//               if (quoteData.ID) {
//                 const quoteUrl = "https://"+globalArray.simpro_domain_prefix+".simprosuite.com/staff/editProject.php?quoteID="+quoteId;
//                 document.getElementById("Quote_Number").value = quoteId;
//                 document.getElementById("quote_link").textContent = quoteUrl;
//                 document.getElementById("quote_link").setAttribute("href", quoteUrl);
//                 document.getElementById("createQuote").style.display = "none";
//                 document.getElementById("Quote_Message_Log").value = "Quote loaded successfully.";
//                 //getallquotenotes(GlobalArr, "quotes", quoteId);
//               }
      

//       } catch (quoteErr) {


//         if (quoteErr.status === 404) {

//            // const errData = JSON.parse(quoteErr.response || "{}");
//             //const errors = errData.errors || [];
//             const message = JSON.parse(quoteErr.response)?.errors?.[0]?.message || "Unknown error";

//             showQuoteErrorUI(message);

//           } else {
//             console.log("❌ Unexpected error:", quoteErr);
//             //notify("danger", "Unexpected error occurred while loading quote.");
//           }

//      //   console.log(" Failed to fetch quote - loadticketnumbersnmnm:", quoteErr);

//         resetQuoteUI();
//       } finally {
//         hide_loader();
//       }

//     } else {
//       resetQuoteUI();
//     }



//    }
//    catch (error)
//    {
//          console.log("Error fetching loadticketnumbers:", error);
//          //document.getElementById("apptext").innerText = "Failed to fetch Simpro site details.";
//     }


// }


async function loadticketnumbers(globalArray) {
  try {
    show_loader(); 
    const ticketData = await fetchTicketData(globalArray.tic_id);
    if (!ticketData) return;  // Early exit if ticket data is unavailable

    const customFields = ticketData.custom_fields || {};
    if (customFields.cf_simpro_quote_number) {
      await loadSimproQuote(globalArray, customFields.cf_simpro_quote_number);
    } else {
      //resetQuoteUI();
        document.getElementById("Quote_Number").value = "";
  document.getElementById("quote_link").textContent = "";
  document.getElementById("createQuote").style.display = "block";
  document.getElementById("Quote_Message_Log").textContent = "";
  hide_loader();
    }
  } catch (error) {
    console.log("Error fetching loadticketnumbers:", error);
  } finally {
    hide_loader();
  }
}

async function fetchTicketData(ticketID) {
  try {
    const response = await client.request.invokeTemplate("getFreshdeskTicket", {
      context: { ticketID }
    });
    return JSON.parse(response.response || "{}");
  } catch (error) {
    console.log("Error fetching ticket data:", error);
    return null;
  }
}

async function loadSimproQuote(globalArray, quoteId) {
  try {
    const quoteResponse = await client.request.invokeTemplate("getSimproQuote", {
      context: { company_id: globalArray.company_id, quote_id: String(quoteId) }
    });
    const quoteData = JSON.parse(quoteResponse.response || "{}");
    if (quoteData.ID) {
      const quoteUrl = "https://"+GlobalArr.simpro_domain_prefix+".simprosuite.com/staff/editProject.php?quoteID="+quoteId;
      document.getElementById("Quote_Number").value = quoteId;
      document.getElementById("quote_link").textContent = quoteUrl;
      document.getElementById("quote_link").setAttribute("href", quoteUrl);
      document.getElementById("createQuote").style.display = "none";
      document.getElementById("Quote_Message_Log").value = "Quote loaded successfully.";
    }
  } catch (quoteErr) {
    handleQuoteError(quoteErr);
  }
}

function handleQuoteError(quoteErr) {
  if (quoteErr.status === 404) {
    const message = JSON.parse(quoteErr.response)?.errors?.[0]?.message || "Unknown error";
    showQuoteErrorUI(message);
  } else {
    console.log("❌ Unexpected error:", quoteErr);
  }
  //resetQuoteUI();

    document.getElementById("Quote_Number").value = "";
  document.getElementById("quote_link").textContent = "";
  document.getElementById("createQuote").style.display = "block";
  document.getElementById("Quote_Message_Log").textContent = "";
  hide_loader();
}


// function resetQuoteUI() {
//   document.getElementById("Quote_Number").value = "";
//   document.getElementById("quote_link").textContent = "";
//   document.getElementById("createQuote").style.display = "block";
//   document.getElementById("Quote_Message_Log").textContent = "";
//   hide_loader();
// }


function showQuoteErrorUI(message) {
 document.getElementById("Quote_Message_Log").value = message;
            document.getElementById("Quote_Number").value = "";
            document.getElementById("quote_link").textContent = "";
            document.getElementById("createQuote").style.display = "block";
}


// function getallquotenotes(globarr,module_name,module_id)
//   {   
//     //let err, reply; 
//     //   console.log("getallquotenotes- in");
//     var url = 'https://'+globarr.simpro_domain_prefix+'.simprosuite.com/';  
//     url = url+'api/v1.0/companies/'+globarr.company_id+'/'+module_name+'/'+module_id+'/notes/';   
//     var headers = {"Authorization": "Bearer <%= iparam.simpro_api_key %>","Accept" : "application/json,charset=utf-8"};
//     var options = { headers: headers,cors:true}; 
  
//     client.request.get(url, options)
//     .then (
//     function(data) {
//       console.log("datasssssssssssssssssss"); 
//       console.log(data);    
//       var responseArr = JSON.parse(data.response);
//       console.log(responseArr);
//       var create_new = true;
//       if(responseArr.length > 0)
//         {
//           for (var i = 0; i < responseArr.length; i++) {  
//           var tic_Subject = responseArr[i]['Subject'];
//             if((tic_Subject.indexOf(globarr.tic_number) !== -1)){  
//               create_new = false;
//               break;
//             }
//           }
//           if(create_new == true)
//           { 
//             createquotenote(globarr,module_name,module_id);
//           }
//         }
//         else{ 
//             createquotenote(globarr,module_name,module_id);
//         }
//     },
//     function(error) {  
//       console.log(error);
//     }); 
//   } 
 async function getContacts(globalArray,search_in_simpro=0) 
  {  

 try {
      globalArray.search_in_simpro = search_in_simpro;

    const contactData = await client.data.get("contact");
    globalArray.contactData = contactData;
    //console.log(globalArray.company_id +"---"+globalArray.email);
    const contactResponse = await client.request.invokeTemplate("getSimproContact", {
            context: { company_id: globalArray.company_id, email: globalArray.email },
        });
    const contactsFromSimPRO = JSON.parse(contactResponse.response);
    //console.log(contactsFromSimPRO);

        if(contactsFromSimPRO.length > 0)
        {
          const full_detail_link = contactsFromSimPRO[0]['_href'];
          getContactsSites(GlobalArr, full_detail_link);
          //console.log(full_detail_link);
        }
        else
        { 
            searchincontacts(GlobalArr).then(function(data){
            //console.log("contact_customer_response");
            //console.log(data); 
            if(data.status === 404)
            {
              status404(data,"Quote_Message_Log");
            }
            else
            {
              if(data.length === 0){
                $("#simpro_customer_id").val("");
                $("#simpro_customer_site_id").val("");
                hide_loader();
               hide_jobloader();
              } 
              else
              {
                // for (let i = 0; i < data.length; i++) 
                // {  
                //   let full_detail_link= "/api/v1.0/companies/"+GlobalArr.company_id+"/contacts/"+data[i]['ID']; 
                //   GlobalArr.contact_id = data[i]['ID']; 
                // //  getChildCustomerSites(GlobalArr,full_detail_link); 
                //   break;
                // } 
                // //console.log(data); 

                const full_detail_link= "/api/v1.0/companies/"+globalArray.company_id+"/contacts/"+data[0]['ID']; 
                globalArray.contact_id = data[0]['ID']; 
              //  getChildCustomerSites(globalArray,full_detail_link);
                          getContactsSites(globalArray, full_detail_link);

              }
            }
          }).catch((err) => { 
        console.error("Contact not found:", err);
        // Handle the error appropriately, e.g., show a user-friendly message or retry logic
        //alert("An error occurred while fetching the contact. Please try again later.");
      });  
        }




    }
    catch (error) {
        console.error("Error fetching Contact:", error);
        document.getElementById("apptext").innerText = "Failed to fetch Simpro site details.";
    }

    
  } 



  async function getContactsSites(globalArray,full_detail_link) 
  {  
    //console.log("inside getContactsSites");

    try {
     const ticketDate = await client.data.get("ticket");
     globalArray.ticketData = ticketDate;
      const maindetailsArr = await client.request.invokeTemplate("getSimproContactSite", {
            context: { link: full_detail_link },
        });
    const responseArr = JSON.parse(maindetailsArr.response);
    //console.log(responseArr);
    if(responseArr.ID){
    globalArray.simpro_customer_id = responseArr.ID;
      $("#simpro_customer_id").val(responseArr.ID); 
      const  Sites = responseArr.Sites;
      if(Sites.length > 0)
      { 
        const customerSite = Sites[0].ID;  
        globalArray.simpro_customer_site_id = customerSite;
        $("#simpro_customer_site_id").val(customerSite); 
      }
      else{ 
       $("#simpro_customer_site_id").val("");
      }
      //console.log(Sites);
    }
   hide_loader();
   hide_jobloader();
   
        }
        catch (error) {
                console.error("Error fetching Contact:", error);
                //document.getElementById("apptext").innerText = "Failed to fetch Simpro site details.";
            }

  }


  function status404(data,divid)
  {

      let simproerrors_status = [];
      let errDataArr_st = [];
    if(data.status === 404)
      {
        errDataArr_st =  JSON.parse(data.response);
        simproerrors_status = errDataArr_st.errors; 
        if(simproerrors_status.length > 0){
          $('#'+divid).text("");
          for (let i = 0; i < simproerrors_status.length; i++) { 
            $('#'+divid).append(" "+simproerrors_status[i].path+"-"+simproerrors_status[i].message);  
          }  
        }  
      }
  }
   
function setGlobalArray(contactData, ticketData, iparams) {
  const { name, email, phone } = contactData.contact;
  const { subject, description_text, ticket_number, id } = ticketData.ticket;

  globalArray.email = email;
  globalArray.phone= phone;
  globalArray.contactName = name;
  globalArray.ticket_subject = subject;
  globalArray.description = description_text;
  globalArray.tic_number = ticket_number;
  globalArray.tic_id = id;

  globalArray.Freshdesk_admin_email = iparams.admin_email;
  globalArray.freshdesk_subdomain = iparams.freshdesk_subdomain;
  globalArray.freshdesk_api_key = iparams.freshdesk_api_key;
  globalArray.simpro_domain_prefix = iparams.simpro_domain_prefix;
  globalArray.multi_company = iparams.multi_company;
  globalArray.simpro_api_key = iparams.simpro_api_key;
  globalArray.simpro_customer_type = iparams.simpro_customer_type;
  globalArray.simpro_project_type = iparams.simpro_project_type;
  globalArray.create_customer_check = iparams.create_customer_check;
}
   



    $("#createQuote").click(function(){   

      try{


        $('#Quote_Message_Log').text("Processing..."); 
        show_loader();    
        const due_date = $("#due_date").val();
        let simpro_customer_id = $("#simpro_customer_id").val();
        const simpro_customer_site_id = $("#simpro_customer_site_id").val(); 
        globalArray.due_date = due_date;   
        globalArray.simpro_customer_id = simpro_customer_id;
        globalArray.simpro_customer_site_id = simpro_customer_site_id; 
        if(simpro_customer_id === "" && globalArray.create_customer === false)
        { 
          $("#simpro_customer_id").val(globalArray.default_customer_id); 
          simpro_customer_id = globalArray.default_customer_id;
          globalArray.simpro_customer_id = globalArray.default_customer_id;
        }


        //console.log(GlobalArr);

        if(globalArray.simpro_customer_id === "")
        { 

          createCustomerinSimPRO(globalArray);
        }
        else
        { 
          createQuoteinSimpro(globalArray);      
        }
}
    catch (error) {
        console.error("Error fetching - createQuote button:", error);
    }


        });


/* below function is executed when we click in create job button on front end */
//   $("#createJob").click(function(){    
//        $('#Job_Message_Log').text("Processing...");  
//         show_jobloader();    
//         getsitedetails(GlobalArr,comapnyIdArr,DefaultSiteArr);
//         const due_date = $("#due_date").val();

//         const cf_sim_pro_quote_number = $("#Quote_Number").val();  
//         const simpro_customer_id = $("#simpro_customer_id").val();
//         const simpro_customer_site_id = $("#simpro_customer_site_id").val(); 


//       GlobalArr.due_date = due_date; 
//       globalArray.simpro_customer_id = simpro_customer_id; 
//       GlobalArr.simpro_customer_site_id = simpro_customer_site_id;  
//       //let company_id = GlobalArr.company_id; 
//       GlobalArr.quote_number = cf_sim_pro_quote_number; 
//       //console.log(cf_sim_pro_quote_number +"--"+simpro_customer_id+"--"+simpro_customer_site_id+"--"+company_id);


//     const returnm = addMessageOnError(GlobalArr,"Job_Message_Log") ; 
//     if(returnm === true)
//     {
//       return;
//     }
//     // var simpro_customer_id = globarr.simpro_customer_id;

//     // if(empty(simpro_customer_id))
//     // { 
//     //   $('#Job_Message_Log').text("Creating Customer In Simpro..."); 
//     //   var customerData = {}; 
//     //   customerData.Email = globarr.requester_email;  

//     //   default_customer_type = globarr.simpro_customer_type;
//     //   default_customer_type = default_customer_type.toLowerCase();
//     //   if(default_customer_type == "company")
//     //   { 
//     //     customerData.CompanyName = globarr.contactName;
//     //   }
//     //   else if(default_customer_type == "individual")
//     //   {
//     //     var flnameArr = globarr.contactName;
//     //     flnameArr = flnameArr.split(" ");
//     //     customerData.GivenName = flnameArr[0];
//     //     if(flnameArr.length > 1)
//     //     customerData.FamilyName = flnameArr[1]; 
//     //     else
//     //     customerData.FamilyName = flnameArr[0];    
//     //   }
//     //   else
//     //   {
//     //     $('#Job_Message_Log').text("Please check the value for customer type in configuration settings... Please set only the values Individual Or Company"); 
//     //     hide_jobloader();
//     //     return;
//     //   } 

//     //   var url = 'https://'+globarr.simpro_domain_prefix+'.simprosuite.com/api/v1.0/companies/'+company_id+'/customers/'+default_customer_type+'/';
//     //       //console.log("customerData");
//     //       //console.log(customerData);
//     //       var headers = {"Authorization": "Bearer <%= iparam.simpro_api_key %>","Accept" : "application/json,charset=utf-8","Content-Type" : "application/json"};
//     //       var options = { headers: headers,cors:true,body:JSON.stringify(customerData)};
//     //       client.request.post(url, options)
//     //       .then (
//     //       function(data) {
//     //         //console.log(data);

//     //         var dataArr = JSON.parse(data.response); 
//     //         if(dataArr.errors != '' && dataArr.errors != undefined )
//     //         { 
//     //           simproerrors = dataArr.errors;  
//     //           $('#Job_Message_Log').text("");
//     //           if(simproerrors.length > 0){
//     //             for (var i = 0; i < simproerrors.length; i++) { 
//     //               $('#Job_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
//     //             } 
//     //           } 
//     //         }
//     //         else 
//     //         {
//     //           var simpro_customer_id = dataArr.ID; 
//     //           globarr.simpro_customer_id = simpro_customer_id; 
//     //           $("#simpro_customer_id").val(simpro_customer_id);
//     //           if(simpro_customer_id == "")
//     //           {
//     //             $('#Job_Message_Log').text("Some Technical Error..."); 
//     //             hide_loader();
//     //           }
//     //           else
//     //           {
//     //             $('#Job_Message_Log').text("Customer Created Successfully...Now creating job please wait...");  
//     //             createJobinSimpro(globarr);
//     //           }
//     //         }
//     //       },
//     //       function(error) {
//     //         //console.log(error);
//     //       });  
//     // }
//     // else
//     // {
//     // //console.log(globarr);
//     // createJobinSimpro(globarr);
//     // }   
// });


/* below function is used to display error if setting has inaccurate values */

// function addMessageOnError(GlobalArr,logmesg)
//   { 
//     //console.log("GlobalArr"); 
//     //console.log(GlobalArr); 
//     if(GlobalArr === undefined)
//     {
//       $('#'+logmesg).text("Please check the configuration settings"); 
//         hide_loader();
//         return true;  
//     }
   
//     simpro_project_type = GlobalArr.simpro_project_type;
//     if(simpro_project_type !== "" || simpro_project_type !== undefined || simpro_project_type !== null){
//       //console.log(simpro_project_type);
//       simpro_project_type = simpro_project_type.toLowerCase();
//       if(simpro_project_type !== "service" && simpro_project_type !== "project")
//       {
//         $('#'+logmesg).text("Please check the value for project type in configuration settings... Please set only the values Service Or Project"); 
//         hide_loader();
//         return true; 
//       }
//     }

//     simpro_customer_type = GlobalArr.simpro_customer_type;
//     if(simpro_customer_type !== "" || simpro_customer_type !== undefined || simpro_customer_type !== null){
//       simpro_customer_type = simpro_customer_type.toLowerCase();
//       if(simpro_customer_type !== "company" && simpro_customer_type !== "individual")
//       {  
//       $('#'+logmesg).text("Please check the value for customer type in configuration settings... Please set only the values Individual Or Company"); 
//         hide_loader();
//         return true;
//       }
//     }

//     multi_company_check = GlobalArr.multi_company;
//     if(multi_company_check !== "" || multi_company_check !== undefined || multi_company_check !== null){
//       if(multi_company_check.toLowerCase() !== "yes" && multi_company_check.toLowerCase() !== "no")
//       {  
//       $('#'+logmesg).text("Please check the value for multi_company value in configuration settings... Please set only the values Yes Or No"); 
//         hide_loader();
//         return true;
//       }  
//     }

//     return false;
//   }

function addMessageOnError(globalArray, logmesg) { 
  if (!globalArray) {
    displayError(logmesg, "Please check the configuration settings");
    return true;
  }

  // if (isInvalidProjectType(GlobalArr.simpro_project_type)) {
  //   displayError(logmesg, "Please check the value for project type in configuration settings... Please set only the values Service Or Project");
  //   return true;
  // }

  // if (isInvalidCustomerType(GlobalArr.simpro_customer_type)) {
  //   displayError(logmesg, "Please check the value for customer type in configuration settings... Please set only the values Individual Or Company");
  //   return true;
  // }

  // if (isInvalidMultiCompany(GlobalArr.multi_company)) {
  //   displayError(logmesg, "Please check the value for multi_company value in configuration settings... Please set only the values Yes Or No");
  //   return true;
  // }

  return false;
}

function displayError(logmesg, message) {
  $('#' + logmesg).text(message);
  hide_loader();
}

// function isInvalidProjectType(projectType) {
//   return projectType && projectType.toLowerCase() !== "service" && projectType.toLowerCase() !== "project";
// }

// function isInvalidCustomerType(customerType) {
//   return customerType && customerType.toLowerCase() !== "company" && customerType.toLowerCase() !== "individual";
// }

// function isInvalidMultiCompany(multiCompanyCheck) {
//   return multiCompanyCheck && multiCompanyCheck.toLowerCase() !== "yes" && multiCompanyCheck.toLowerCase() !== "no";
// }


/* below function is used to fetch site on comapny chagnes form global settings */

  // function getSiteDetails(globalArray, companyIdArray, defaultSiteArray) {
  //   // Extract company_id from globalArray
  //   const companyId = globalArray.company_id;
  
  //   // Convert companyIdArray and defaultSiteArray to arrays
  //   const companyIds = Object.values(companyIdArray);
  //   const defaultSites = Object.values(defaultSiteArray);
  
  //   // Find the index of the companyId in companyIds array
  //   const companyIndex = companyIds.indexOf(companyId);
  
  //   // Store the company_id in localStorage
  //   localStorage.setItem("company_id", companyId);
  
  //   // Get the corresponding default site ID using the index
  //   const defaultSiteId = defaultSites[companyIndex];
  
  //   // Set the value of the Default_Site_ID input field
  //   $("#Default_Site_ID").val(defaultSiteId);
  
  //   // Update globalArray with company_id and default_site_id
  //   globalArray.company_id = companyId;
  //   globalArray.default_site_id = defaultSiteId;
  // } 


async function createCustomerinSimPRO(globalArray)
{
  let simproerrors_customer = [];
            try{
          $('#Quote_Message_Log').text("Creating Customer In Simpro..."); 
          const customerData = {};
          customerData.CompanyName = globalArray.contactName; 
          customerData.Email = globalArray.email; 
          customerData.Phone = globalArray.phone;

          const quoteResponse = await client.request.invokeTemplate("createSimproCustomer", {
            context: { company_id: globalArray.company_id},
            body:JSON.stringify(customerData)
        });
            const dataArr = JSON.parse(quoteResponse.response); 
            if(dataArr.errors !== '' && dataArr.errors !== undefined )
            { 
              simproerrors_customer = dataArr.errors;  
              $('#Quote_Message_Log').text("");
              if(simproerrors_customer.length > 0){
                for (let i = 0; i < simproerrors_customer.length; i++) { 
                  $('#Quote_Message_Log').append(" "+simproerrors_customer[i].path+"-"+simproerrors_customer[i].message);  
                } 
              } 
            }
            else
            {
              const simpro_customer_id = dataArr.ID; 
              GlobalArr.simpro_customer_id = simpro_customer_id;
              $("#simpro_customer_id").val(simpro_customer_id);
              if(simpro_customer_id === "")
              {
                $('#Quote_Message_Log').text("Some Technical Error..."); 
                hide_loader();
              }
              else
              {
                $('#Quote_Message_Log').text("Customer Created Successfully...Now creating quote please wait...");  
                createQuoteinSimpro(GlobalArr);
              }
            } 
          
        }
        catch (error) {
        console.error("Error fetching - createQuote button:", error);
    }

}

// async function createQuoteinSimpro(GlobalArr)
//   {

//      try {
//         const iparams = await client.iparams.get();
//         GlobalArr.iparams = iparams;
   
//     if(GlobalArr.simpro_customer_site_id === "")
//     {
//       GlobalArr.simpro_customer_site_id = GlobalArr.default_site_id;
//     }
//     const customerData = {};
//     customerData.Customer = parseInt(GlobalArr.simpro_customer_id); 
//     customerData.Type = capitalizeFirstLetter(GlobalArr.simpro_project_type);
//     if(GlobalArr.ticket_subject !== "")
//     { 
//     customerData.Name = GlobalArr.ticket_subject;  
//     }
//     if(GlobalArr.due_date !== "")
//     { 
//     customerData.DueDate = GlobalArr.due_date;  
//     }
//     customerData.Description = GlobalArr.description; 
//     customerData.Site = parseInt(GlobalArr.simpro_customer_site_id); 
//     const quoteResponse = await client.request.invokeTemplate("createSimproQuote", {
//             context: { company_id: GlobalArr.company_id},
//             body:JSON.stringify(customerData)
//         });
//     const quoteData = JSON.parse(quoteResponse.response);

//     if (quoteData.errors && quoteData.errors.length > 0) {
//       for (const error of quoteData.errors) {
//         const msg = `${error.path} - ${error.message}`;
//         document.getElementById("Quote_Message_Log")?.insertAdjacentText("beforeend", msg);
//       }
//       hide_loader();
//       return;
//     }

//     if (quoteData.ID) {
//       globalArray.quote_number = quoteData.ID;
//       document.getElementById("Quote_Number").value = quoteData.ID;

//       const quoteURL = `https://${iparams.simpro_domain_prefix}.simprosuite.com/staff/editProject.php?quoteID=${quoteData.ID}`;
//       const quoteLink = document.getElementById("quote_link");
//       quoteLink.innerHTML = quoteURL;
//       quoteLink.setAttribute("href", quoteURL);
//       //console.log("Quote created successfully:", quoteData);
//       document.getElementById("Quote_Message_Log").innerText = "Quote Created Successfully!";
//       document.getElementById("createQuote").style.display = "none";

//       // Update SimPRO with Ticket ID if CustomFields contain it
//       const customFields = quoteData.CustomFields || [];
//       //console.log("customFields - "+customFields);
//       const ticketIdField = customFields.find(f => f.CustomField?.Name === "Ticket Id");
//       //console.log("ticketIdField - "+ticketIdField);
//       if (ticketIdField) {
//         updateDeskTicketIdInSimpro(globalArray, quoteData.ID, ticketIdField.CustomField.ID, "quotes");
//       }

//       // Post back to helpdesk system
//      const postedData = { cf_simpro_quote_number: String(quoteData.ID) };
//       createquotenote(GlobalArr, "quotes", quoteData.ID);
//      updateTicketDetails(GlobalArr, postedData);
//       hide_loader();
//       //notifysuccess("success", "Quote created successfully.");
//     }
//     //console.log("contactsFromSimPRO --"+quoteResponse);

  

//     }
//     catch (error) {
//         console.error("Error fetching - createQuoteinSimpro:", error);
//     }


    
//   } 
 
async function createQuoteinSimpro(globalArray) {
  try {
    const iparams = await client.iparams.get();
    globalArray.iparams = iparams;

    // Handle site ID and customer data creation
    handleCustomerSite(globalArray);
    const customerData = createCustomerData(globalArray);

    // Call the SimPro API to create the quote
    const quoteResponse = await client.request.invokeTemplate("createSimproQuote", {
      context: { company_id: globalArray.company_id },
      body: JSON.stringify(customerData)
    });

    // Handle quote response
    await handleQuoteResponse(quoteResponse, globalArray, iparams);
  } catch (error) {
    console.error("Error fetching - createQuoteinSimpro:", error);
  }
}

function handleCustomerSite(globalArray) {
  if (globalArray.simpro_customer_site_id === "") {
    globalArray.simpro_customer_site_id = globalArray.default_site_id;
  }
}

function createCustomerData(globalArray) {
  const customerData = {};
  customerData.Customer = parseInt(globalArray.simpro_customer_id);
  customerData.Type = capitalizeFirstLetter(globalArray.simpro_project_type);
  if (globalArray.ticket_subject !== "") {
    customerData.Name = globalArray.ticket_subject;
  }
  if (globalArray.due_date !== "") {
    customerData.DueDate = globalArray.due_date;
  }
  customerData.Description = globalArray.description;
  customerData.Site = parseInt(globalArray.simpro_customer_site_id);
  return customerData;
}

function handleQuoteResponse(quoteResponse, globalArray, iparams) {
  const quoteData = JSON.parse(quoteResponse.response);

  // Handle errors in the quote response
  if (quoteData.errors && quoteData.errors.length > 0) {
    for (const error of quoteData.errors) {
      const msg = `${error.path} - ${error.message}`;
      document.getElementById("Quote_Message_Log")?.insertAdjacentText("beforeend", msg);
    }
    hide_loader();
    return;
  }

  // Quote created successfully
  if (quoteData.ID) {
    GlobalArr.quote_number = quoteData.ID;
    document.getElementById("Quote_Number").value = quoteData.ID;

    const quoteURL = `https://${iparams.simpro_domain_prefix}.simprosuite.com/staff/editProject.php?quoteID=${quoteData.ID}`;
    const quoteLink = document.getElementById("quote_link");
    quoteLink.innerHTML = quoteURL;
    quoteLink.setAttribute("href", quoteURL);

    document.getElementById("Quote_Message_Log").innerText = "Quote Created Successfully!";
    document.getElementById("createQuote").style.display = "none";

    // Handle ticket ID update if present
    const customFields = quoteData.CustomFields || [];
    const ticketIdField = customFields.find(f => f.CustomField?.Name === "Ticket Id");
    if (ticketIdField) {
      updateDeskTicketIdInSimpro(GlobalArr, quoteData.ID, ticketIdField.CustomField.ID, "quotes");
    }

    // Post back to helpdesk system
    const postedData = { cf_simpro_quote_number: String(quoteData.ID) };
    createquotenote(globalArray, "quotes", quoteData.ID);
    updateTicketDetails(globalArray, postedData);
    hide_loader();
  }
}



/* below function is used to udpate freshdesk ticket id in simrpo as custom fields */

  async function updateDeskTicketIdInSimpro(globalArray,cf_sim_pro_quote_number,simpro_ticket_field_id,module_name)
  { 
    try{
      const iparams = await client.iparams.get();
        globalArray.iparams = iparams;
          const pushArr = {}; 
          pushArr.Value = globalArray.tic_id.toString();  

           const quoteUpdateResponse = await client.request.invokeTemplate("updateSimproDeskTicketId", {
            context: { company_id: globalArray.company_id, module: module_name, ticket_field_ID: simpro_ticket_field_id, simproquote_number: cf_sim_pro_quote_number},
            body:JSON.stringify(pushArr)
        });
           globalArray.quoteUpdateResponse = quoteUpdateResponse;
          //console.log(quoteUpdateResponse);
      }
      catch (error) {
      console.error("Error fetching - updateDeskTicketIdInSimpro:", error);
    }
  }  


/* below function is used to create quote note against quote */
  async function createquotenote(globalArray,module_name,module_id)
  {   
    try{
    let quote_job_note = globalArray.timeline_notes_quote;
    if(module_name === "quotes")
    quote_job_note = globalArray.timeline_notes_quote;
    else 
    quote_job_note = globalArray.timeline_notes_job;  

    const createnoteResponse = await client.request.invokeTemplate("createSimproNote", {
            context: { company_id: globalArray.company_id, module: module_name, moduleID: module_id},
            body:JSON.stringify(quote_job_note)
        });
    globalArray.createnoteResponse = createnoteResponse;
          //console.log(createnoteResponse);
      

   
  }catch (error) {
      console.error("Error fetching - createquotenote:", error);
    }

  }

/* below function is used update ticket details after creating qutoe/job */
  async function updateTicketDetails(globalArray,updateArr)
  { 
    try {
    const updateFreshdeskTicektResponse = await client.request.invokeTemplate("updateFreshdeskTicekt", {
      context: {
        ticketID: globalArray.tic_id  },
        body: JSON.stringify({'custom_fields': updateArr})
    });
    globalArray.updateFreshdeskTicektResponse = updateFreshdeskTicektResponse;
    //console.log( response);
  } catch (error) {
    console.error("Failed to update Freshdesk ticket:", error);
  }
  } 


/* below function is used to show the loader in front end */
  function show_loader(){
    $("#loader").addClass("spinner-border"); 
  }

/* below function is used to hide the loader in front end */
  function hide_loader(){
    $("#loader").removeClass("spinner-border"); 
  } 

/* below function is used to show the job loader in front end */
  function show_jobloader(){
    $("#jobloader").addClass("spinner-border"); 
  } 

/* below function is used to hide the job loader in front end */
  function hide_jobloader(){
    $("#jobloader").removeClass("spinner-border"); 
  }
  function capitalizeFirstLetter(string) 
  {
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
  }


async function fetchSimproSite() {
    try {
        const siteId = globalArray.default_site_id;
        const siteResponse = await client.request.invokeTemplate("getSimproSite", {
            context: { company_id: globalArray.company_id, site_id: siteId },
        });
        const statusCode = siteResponse.status;
        const responseBody = siteResponse.response;
        //console.log(statusCode);
        if (statusCode === 200 && responseBody) {
            const site = JSON.parse(siteResponse.response);
            //console.log(site);
            globalArray.push({ site });

            // // Show site info in UI
            // document.getElementById("apptext").innerHTML = `
            //   <h3>Site Details</h3>
            //   <p><strong>Name:</strong> ${site.name}</p>
            //   <p><strong>Address:</strong> ${site.address?.street}, ${site.address?.suburb}</p>
            // `;
            // //console.log("Site details fetched and added to GlobalArr:", GlobalArr);
            // //console.log("Site Found. Site ID:", site.id +"--"+GlobalArr.Default_Site_ID);
        } else {
            //console.log("Site not found or invalid response");
            document.getElementById("apptext").innerText = "Site not found.";
        }
    } catch (error) {
        console.error("Error fetching Simpro site:", error.status);
        document.getElementById("apptext").innerText = "Failed to fetch Simpro site details.";
    }

    
}

//    isInvalidProjectType,
    //isInvalidCustomerType,
    //isInvalidMultiCompany,
//    resetQuoteUI,

// Export functions for testing
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    capitalizeFirstLetter,
    addMessageOnError,
    displayError,
    show_loader,
    hide_loader,
    show_jobloader,
    hide_jobloader,
    showQuoteErrorUI,
    handleQuoteError,
    searchincontacts,
    fetchTicketData,
    loadSimproQuote,
    createCustomerinSimPRO,
    handleCustomerSite,
    createCustomerData,
    handleQuoteResponse,
    getContacts,
    getContactsSites,
    status404,
    getsitedetails,
    updateDeskTicketIdInSimpro,
    createquotenote,
    updateTicketDetails,
    fetchSimproSite
  };
}
