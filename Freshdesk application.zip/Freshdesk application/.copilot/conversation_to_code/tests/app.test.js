// Basic tests for your app functions

describe('Utility Functions', () => {
  test('capitalizeFirstLetter should work correctly', () => {
    const capitalizeFirstLetter = (string) => {
      return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
    };

    expect(capitalizeFirstLetter('service')).toBe('Service');
    expect(capitalizeFirstLetter('project')).toBe('Project');
    expect(capitalizeFirstLetter('SERVICE')).toBe('Service');
  });

  test('isInvalidProjectType should validate correctly', () => {
    const isInvalidProjectType = (projectType) => {
      return projectType && projectType.toLowerCase() !== "service" && projectType.toLowerCase() !== "project";
    };

    expect(isInvalidProjectType('service')).toBe(false);
    expect(isInvalidProjectType('project')).toBe(false);
    expect(isInvalidProjectType('invalid')).toBe(true);
    expect(isInvalidProjectType('')).toBe(false);
  });

  test('isInvalidCustomerType should validate correctly', () => {
    const isInvalidCustomerType = (customerType) => {
      return customerType && customerType.toLowerCase() !== "company" && customerType.toLowerCase() !== "individual";
    };

    expect(isInvalidCustomerType('company')).toBe(false);
    expect(isInvalidCustomerType('individual')).toBe(false);
    expect(isInvalidCustomerType('business')).toBe(true);
    expect(isInvalidCustomerType('')).toBe(false);
  });

  test('isInvalidMultiCompany should validate correctly', () => {
    const isInvalidMultiCompany = (multiCompanyCheck) => {
      return multiCompanyCheck && multiCompanyCheck.toLowerCase() !== "yes" && multiCompanyCheck.toLowerCase() !== "no";
    };

    expect(isInvalidMultiCompany('yes')).toBe(false);
    expect(isInvalidMultiCompany('no')).toBe(false);
    expect(isInvalidMultiCompany('true')).toBe(true);
    expect(isInvalidMultiCompany('')).toBe(false);
  });
});

describe('DOM Functions', () => {
  test('show_loader should add spinner class', () => {
    const mockElement = { addClass: jest.fn() };
    global.$ = jest.fn(() => mockElement);

    const show_loader = () => {
      $("#loader").addClass("spinner-border");
    };

    show_loader();
    expect(mockElement.addClass).toHaveBeenCalledWith("spinner-border");
  });

  test('hide_loader should remove spinner class', () => {
    const mockElement = { removeClass: jest.fn() };
    global.$ = jest.fn(() => mockElement);

    const hide_loader = () => {
      $("#loader").removeClass("spinner-border");
    };

    hide_loader();
    expect(mockElement.removeClass).toHaveBeenCalledWith("spinner-border");
  });

  // test('resetQuoteUI should reset all elements', () => {
  //   const resetQuoteUI = () => {
  //     document.getElementById("Quote_Number").value = "";
  //     document.getElementById("quote_link").textContent = "";
  //     document.getElementById("createQuote").style.display = "block";
  //     document.getElementById("Quote_Message_Log").textContent = "";
  //   };

  //   resetQuoteUI();
  //   expect(document.getElementById).toHaveBeenCalledWith("Quote_Number");
  //   expect(document.getElementById).toHaveBeenCalledWith("quote_link");
  // });
});

describe('Error Handling', () => {
  test('displayError should show error message', () => {
    const mockElement = { text: jest.fn() };
    global.$ = jest.fn(() => mockElement);

    const displayError = (logmesg, message) => {
      $('#' + logmesg).text(message);
    };

    displayError('Quote_Message_Log', 'Test error');
    expect(mockElement.text).toHaveBeenCalledWith('Test error');
  });

  test('addMessageOnError should validate GlobalArr', () => {
    const addMessageOnError = (GlobalArr, logmesg) => {
      if (!GlobalArr) return true;
      return false;
    };

    expect(addMessageOnError(null, 'test')).toBe(true);
    expect(addMessageOnError({}, 'test')).toBe(false);
  });
});

describe('API Functions', () => {
  beforeEach(() => {
    global.client = global.mockClient;
  });

  test('searchincontacts should make API call', async () => {
    const mockResponse = {
      response: JSON.stringify([{ ID: '123', Name: 'Test' }])
    };
    global.client.request.invokeTemplate.mockResolvedValue(mockResponse);

    const searchincontacts = async (GlobalArr) => {
      const contactResponse = await client.request.invokeTemplate("getSimproContact", {
        context: { company_id: GlobalArr.company_id, email: GlobalArr.email },
      });
      return JSON.parse(contactResponse.response);
    };

    const result = await searchincontacts({ company_id: '1', email: 'test@example.com' });
    expect(result).toEqual([{ ID: '123', Name: 'Test' }]);
  });

  test('fetchTicketData should handle success', async () => {
    const mockResponse = {
      response: JSON.stringify({ id: '456', custom_fields: {} })
    };
    global.client.request.invokeTemplate.mockResolvedValue(mockResponse);

    const fetchTicketData = async (ticketID) => {
      try {
        const response = await client.request.invokeTemplate("getFreshdeskTicket", {
          context: { ticketID }
        });
        return JSON.parse(response.response || "{}");
      } catch (error) {
        return null;
      }
    };

    const result = await fetchTicketData('456');
    expect(result.id).toBe('456');
  });

  test('fetchTicketData should handle errors', async () => {
    global.client.request.invokeTemplate.mockRejectedValue(new Error('API Error'));

    const fetchTicketData = async (ticketID) => {
      try {
        const response = await client.request.invokeTemplate("getFreshdeskTicket", {
          context: { ticketID }
        });
        return JSON.parse(response.response || "{}");
      } catch (error) {
        return null;
      }
    };

    const result = await fetchTicketData('456');
    expect(result).toBeNull();
  });
});

describe('Data Processing', () => {
  test('handleCustomerSite should use default when empty', () => {
    const handleCustomerSite = (GlobalArr) => {
      if (GlobalArr.simpro_customer_site_id === "") {
        GlobalArr.simpro_customer_site_id = GlobalArr.default_site_id;
      }
      return GlobalArr;
    };

    const testData = {
      simpro_customer_site_id: "",
      default_site_id: "999"
    };

    const result = handleCustomerSite(testData);
    expect(result.simpro_customer_site_id).toBe("999");
  });

  test('createCustomerData should format data correctly', () => {
    const createCustomerData = (GlobalArr) => {
      return {
        Customer: parseInt(GlobalArr.simpro_customer_id),
        Type: GlobalArr.simpro_project_type.charAt(0).toUpperCase() + GlobalArr.simpro_project_type.slice(1).toLowerCase(),
        Name: GlobalArr.ticket_subject,
        Description: GlobalArr.description,
        Site: parseInt(GlobalArr.simpro_customer_site_id)
      };
    };

    const testData = {
      simpro_customer_id: '456',
      simpro_project_type: 'service',
      ticket_subject: 'Test Quote',
      description: 'Test Description',
      simpro_customer_site_id: '789'
    };

    const result = createCustomerData(testData);
    expect(result.Customer).toBe(456);
    expect(result.Type).toBe('Service');
    expect(result.Name).toBe('Test Quote');
  });
});

describe('Global Array Initialization', () => {
  test('should set globalArray properties correctly', () => {
    const contactData = {
      contact: {
        name: 'John Doe',
        email: 'john@example.com',
        phone: '1234567890'
      }
    };

    const ticketData = {
      ticket: {
        subject: 'Test Subject',
        description_text: 'Test Description',
        ticket_number: '12345',
        id: '67890'
      }
    };

    const iparams = {
      admin_email: 'admin@example.com',
      freshdesk_subdomain: 'example.freshdesk.com',
      freshdesk_api_key: 'api_key_123',
      simpro_domain_prefix: 'example.simprosuite.com',
      multi_company: 'YES',
      simpro_api_key: 'simpro_api_key_123',
      simpro_customer_type: 'Companies',
      simpro_project_type: 'Service',
      create_customer_check: true
    };

    setGlobalArray(contactData, ticketData, iparams);

    expect(globalArray.email).toBe('john@example.com');
    expect(globalArray.phone).toBe('1234567890');
    expect(globalArray.contactName).toBe('John Doe');
    expect(globalArray.ticket_subject).toBe('Test Subject');
    expect(globalArray.description).toBe('Test Description');
    expect(globalArray.tic_number).toBe('12345');
    expect(globalArray.tic_id).toBe('67890');
    expect(globalArray.Freshdesk_admin_email).toBe('admin@example.com');
    expect(globalArray.freshdesk_subdomain).toBe('example.freshdesk.com');
    expect(globalArray.freshdesk_api_key).toBe('api_key_123');
    expect(globalArray.simpro_domain_prefix).toBe('example.simprosuite.com');
    expect(globalArray.multi_company).toBe('YES');
    expect(globalArray.simpro_api_key).toBe('simpro_api_key_123');
    expect(globalArray.simpro_customer_type).toBe('Companies');
    expect(globalArray.simpro_project_type).toBe('Service');
    expect(globalArray.create_customer_check).toBe(true);
  });
});
