function seachcustomerincontact(globarr)
{



	ZOHODESK.get('ticket').then(function (res) 
	{  
		email = res.ticket.email;  
		var ext = localStorage.getItem("domain_extension");
		var queury  = '?criteria=('; 
		queury = queury + '(Email:equals:'+email+')'; 


		if(globarr.extension_fields == "Yes")
		{
			ex_prefix = "szs__";
		}
		if(globarr.multi_company == "Yes" )
		{
		
		queury = queury + 'and('+ex_prefix+'SimPRO_Company_ID:equals:'+globarr.default_company_id+')';
		queury = queury + ')';
		//console.log(queury+"-"+ext);


		var reqObj= {
	      url : 'https://www.zohoapis.'+ext+'/crm/v2/Contacts/search'+queury,
	      headers : { 'Content-Type' : 'application/json' },
	      type : 'GET',
	      data : {},
	      postBody : {},
	      fileObj: [],
	      connectionLinkName: "zohocrmconnection"
		}  

	}
	else if(globarr.multi_company == "No" )
		{

	queury = queury + ')';


		var reqObj= {
	      url : 'https://www.zohoapis.'+ext+'/crm/v2/Contacts/search'+queury,
	      headers : { 'Content-Type' : 'application/json' },
	      type : 'GET',
	      data : {},
	      postBody : {},
	      fileObj: [],
	      connectionLinkName: "zohocrmconnection"
		}  

	}
console.log(queury);

		ZOHODESK.request( reqObj ).then(function(response){ 
			//hide_loader();
			var responseArr = JSON.parse(response);

			var dataArrJson = responseArr.response; 
			var dataArr = JSON.parse(dataArrJson);
			var accountDataArr = dataArr.statusMessage.data;
// 			console.log(dataArrJson);
// console.log("-------------");

			if(accountDataArr != undefined)
			{
				var found = null;
				var contactCount = 0 ;
				if(accountDataArr.length > 0)
				{  
					var Contact_Related_Site = $("#Contact_Related_Site").val();
					if(accountDataArr[contactCount].Customer_simPRO_ID == null && accountDataArr[contactCount].CustomerContactID == null)
					{
						if(accountDataArr[contactCount].Account_Name != null)
						{		
									var ext = localStorage.getItem("domain_extension");
						var Account_Related_Site = $("#Account_Related_Site").val();
						var accountArr = accountDataArr[contactCount].Account_Name;
						var account_id = accountArr['id'];
						var account_name = accountArr['name'];
						globarr.crm_account_with_nosimpro_found = "yes";
						globarr.crm_account_id = account_id;
						globarr.crm_account_name = account_name;
						var reqObj1= {
					      url : 'https://www.zohoapis.'+ext+'/crm/v2/Accounts/'+account_id,
					      headers : { 'Content-Type' : 'application/json' },
					      type : 'GET',
					      data : {},
					      postBody : {},
					      fileObj: [],
					      connectionLinkName: "zohocrmconnection"
						} 
						ZOHODESK.request( reqObj1 ).then(function(response){ 


				            var responseArr = JSON.parse(response);
							var contactCount = 0 ;
							var dataArrJson = responseArr.response; 
							var dataArr = JSON.parse(dataArrJson);
							var accountDataArr = dataArr.statusMessage.data;
							var acc_email = accountDataArr[contactCount].Email;

							var acc_phone = accountDataArr[contactCount].Phone;


							globarr.crm_account_email = acc_email;
							globarr.crm_account_phone = acc_phone;

								if( accountDataArr[0].Simpro_Id != null)
								{ 


									globarr.account_record = accountDataArr[0]; 
									var Simpro_Id = accountDataArr[0].Simpro_Id;
									var Customer_simPRO_ID = accountDataArr[0].Customer_simPRO_ID; 
									var Zoho_Customer_Id = accountDataArr[0].id;  
									$("#sendtosimpro").val("no");
									$("#Simpro_Customer_Id").val(Simpro_Id);
									$("#Zoho_Customer_Id").val(Zoho_Customer_Id); 
									$("#module_name").val("Accounts"); 


									getRelatedSites(globarr,"Accounts",Zoho_Customer_Id,Account_Related_Site); 
								} 
								else
								{
									globarr.contact_record = accountDataArr[contactCount]; 
									var Customer_simPRO_ID = accountDataArr[contactCount].Customer_simPRO_ID; 
									var Zoho_Customer_Id = account_id; 
									var first_name = accountDataArr[contactCount].First_Name; 
									var last_name = accountDataArr[contactCount].Last_Name; 
									$("#contact_first_name").val(first_name);
									$("#contact_last_name").val(last_name);
									$("#sendtosimpro").val("yes");
									$("#Simpro_Customer_Id").val(Customer_simPRO_ID);
									$("#Zoho_Customer_Id").val(Zoho_Customer_Id); 
									$("#module_name").val("Contacts");  
									//getRelatedSites(globarr,"Contacts",Zoho_Customer_Id,Contact_Related_Site);
									getRelatedSites(globarr,"Accounts",Zoho_Customer_Id,Account_Related_Site); 
								}



				         }).catch(function(err){
							       console.log(err);
								hide_loader();
							})


						


							hide_loader();
						
						}
						else
						{

						globarr.contact_record = accountDataArr[contactCount]; 
						var Customer_simPRO_ID = accountDataArr[contactCount].Customer_simPRO_ID; 
						var Zoho_Customer_Id = accountDataArr[contactCount].id; 
						var first_name = accountDataArr[contactCount].First_Name; 
						var last_name = accountDataArr[contactCount].Last_Name; 
						$("#contact_first_name").val(first_name);
						$("#contact_last_name").val(last_name);
						$("#sendtosimpro").val("yes");
						$("#Simpro_Customer_Id").val(Customer_simPRO_ID);
						$("#Zoho_Customer_Id").val(Zoho_Customer_Id); 
						$("#module_name").val("Contacts");  
						getRelatedSites(globarr,"Contacts",Zoho_Customer_Id,Contact_Related_Site);

							hide_loader();
						}


						
					
					} 
					else if(accountDataArr[contactCount].Customer_simPRO_ID != null)
					{
						globarr.contact_record = accountDataArr[contactCount]; 
						var Customer_simPRO_ID = accountDataArr[contactCount].Customer_simPRO_ID; 
						var Zoho_Customer_Id = accountDataArr[contactCount].id; 
						var first_name = accountDataArr[contactCount].First_Name; 
						var last_name = accountDataArr[contactCount].Last_Name; 
						$("#contact_first_name").val(first_name);
						$("#contact_last_name").val(last_name); 
						$("#sendtosimpro").val("no");
						$("#Simpro_Customer_Id").val(Customer_simPRO_ID);
						$("#Zoho_Customer_Id").val(Zoho_Customer_Id); 
						$("#module_name").val("Contacts");  
						getRelatedSites(globarr,"Contacts",Zoho_Customer_Id,Contact_Related_Site);

					}
					else if(accountDataArr[contactCount].CustomerContactID != null && accountDataArr[contactCount].Customer_simPRO_ID == null)
					{
						//console.log('herer');
						// search in parent account 
						$("#sendtosimpro").val("no"); 

						var ext = localStorage.getItem("domain_extension");
						//console.log('inside contact account');
						if(accountDataArr[contactCount].Account_Name != null)
						{						
							globarr.customer_contact_id = accountDataArr[contactCount].CustomerContactID;
							var Account_Related_Site = $("#Account_Related_Site").val();
							var accountArr = accountDataArr[contactCount].Account_Name;
							var account_id = accountArr['id'];
							var reqObj= {
						      url : 'https://www.zohoapis.'+ext+'/crm/v2/Accounts/'+account_id,
						      headers : { 'Content-Type' : 'application/json' },
						      type : 'GET',
						      data : {},
						      postBody : {},
						      fileObj: [],
						      connectionLinkName: "zohocrmconnection"
							}  
							ZOHODESK.request( reqObj ).then(function(response)
							{ 
								var inner_responseArr = JSON.parse(response);
								var inner_dataArrJson = inner_responseArr.response; 
								var inner_dataArr = JSON.parse(inner_dataArrJson);
								var inner_accountDataArr = inner_dataArr.statusMessage.data;
								
								if(inner_accountDataArr.length > 0 && inner_accountDataArr[0].Simpro_Id != null)
								{ 

									globarr.account_record = inner_accountDataArr[0]; 
									var Simpro_Id = inner_accountDataArr[0].Simpro_Id;
									var Customer_simPRO_ID = inner_accountDataArr[0].Customer_simPRO_ID; 
									var Zoho_Customer_Id = inner_accountDataArr[0].id;  
									$("#sendtosimpro").val("no");
									$("#Simpro_Customer_Id").val(Simpro_Id);
									$("#Zoho_Customer_Id").val(Zoho_Customer_Id); 
									$("#module_name").val("Accounts"); 
									getRelatedSites(globarr,"Accounts",Zoho_Customer_Id,Account_Related_Site); 
								} 
								else
								{ 
									globarr.account_record = inner_accountDataArr[0]; 
									var Zoho_Customer_Id = inner_accountDataArr[0].id;  
									$("#Zoho_Customer_Id").val(Zoho_Customer_Id); 
									$("#module_name").val("Accounts"); 
									$("#sendtosimpro").val("no");
									// $("#Job_Message_Log").text("Customer Not Found In CRM! Please ensure customer is in ZOHO CRM with simPRO Id.");   									
									hide_loader();
								}
							}).catch(function(err){
								hide_loader();
							});
						}
						else
						{ 
							hide_loader();
						}
					}

				} 
				else{
					hide_loader();
				}
			}
			else{ 

				var ext = localStorage.getItem("domain_extension");

	var reqObj= 
	{  
      url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/sites/'+globarr.default_site_id,
      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
      type : 'GET',
      data : {},
	  postBody : {},
	  fileObj: [],
	}

	
	ZOHODESK.request( reqObj ).then(function(response){ 

	var responseArr = JSON.parse(response);
	var dataArrJson = responseArr.response; 
	var dataArr = JSON.parse(dataArrJson); 
	globarr.default_site_name_simpro = dataArr.Name;

	hide_loader();
				$('#Simpro_Site_name_val').append($("<option></option>").attr("value", "").text(globarr.default_site_name_simpro));
				$("#Simpro_Site_Id").val(""); 
				console.log("Customer Not Found In CRM! Please ensure customer is in ZOHO CRM with simPRO Id.");
				//console.log("nm tts");

	}).catch(function(err){
	      // Error handling
	  console.log(err);
		hide_loader();
	})

				
			}
			// hide_loader();
		}).catch(function(err){
		       //console.log(err);
			hide_loader();
		})
	}).catch(function (res) {
		//error Handling
		hide_loader();
	});  
}
function synccustomer(globarr,customerData,module_name,record_id,cust_type,api_name,display_log){ 
	var ext = localStorage.getItem("domain_extension");
	var reqObj= 
	{
      url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/customers/'+cust_type+'/',
      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
      type : 'POST',
      data : {}, 
      postBody : customerData,
	}
	ZOHODESK.request( reqObj ).then(function(response)
	{ 
		var responseArr = JSON.parse(response); 
		if(responseArr.statusCode == 401)
		  	{
		  		token_message();
		  	}
		var dataArrJson = responseArr.response; 
		var dataArr = JSON.parse(dataArrJson);
		if(dataArr.errors != '' && dataArr.errors != undefined )
		{ 
			simproerrors = dataArr.errors;  
		$('#'+display_log).text("");
			if(simproerrors.length > 0){
				for (var i = 0; i < simproerrors.length; i++) { 
					$('#'+display_log).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
				}  
			hide_loader();
			} 
		}
		else
		{
			var simpro_customer_id = dataArr.ID; 
			globarr.simpro_customer_id = simpro_customer_id;
			$("#simpro_customer_id").val(globarr.simpro_customer_id);
			if(simpro_customer_id == "")
			{
				$('#'+display_log).text("Some Technical Error..."); 
				hide_loader();
			}
			else
			{
				pushdata = {};
				pushdata[api_name] = simpro_customer_id.toString();
				var jreqObj= { 
			     url : 'https://www.zohoapis.'+ext+'/crm/v2/'+module_name+'/'+record_id,
			      headers : { 'Content-Type' : 'application/json' },
			      type : 'PUT',
			      data : {},
			      postBody : {"data":[pushdata]},
			      fileObj: [],
			      connectionLinkName: "zohocrmconnection"
				}
				ZOHODESK.request( jreqObj ).then(function(response)
				{

					if(globarr.related_simpro_site_id == null && globarr.related_zoho_site_object != null )
					{

						var ex_prefix = "";
						if(globarr.extension_fields == "Yes")
						{
							ex_prefix = "szs__";
						}
						var siteObject = globarr.related_zoho_site_object;
						simPROsitedata = {};
						simPROsiteaddress = {};
						simPROsitedata.Name = siteObject.Name
						simPROsitedata.PublicNotes = siteObject[ex_prefix+"PublicNotes"];
						simPROsitedata.PrivateNotes = siteObject[ex_prefix+"PrivateNotes"];
						simPROsiteaddress.Country = siteObject[ex_prefix+"Country"];
						simPROsiteaddress.PostalCode = siteObject[ex_prefix+"PostalCode"];
						simPROsiteaddress.State = siteObject[ex_prefix+"State"];
						simPROsiteaddress.City = siteObject[ex_prefix+"City"];
						simPROsiteaddress.Address = siteObject[ex_prefix+"Address"];
						simPROsitedata.Address = simPROsiteaddress;
						simPROsitedata.Customer = [parseInt(globarr.simpro_customer_id)];
						syncsites(globarr,simPROsitedata,ex_prefix+"Sites",siteObject.id,"Simpro_Site_Id",display_log);
					}
					else{ 
						var reload = "0";
						var dmessage = "Sync Successful! Please press the button again to create quote/job in simPRO.";
						modalPopup(reload,dmessage);
					}
				});
			}
		}
	}).catch(function(err)
	{
		//console.log(err);
		$('#Hidden_Message_Log').text(err); 
		var responseArr = JSON.parse(err); 
		if(responseArr.statusCode == 401)
		  	{
		  		token_message();
		  	}
		var dataArrJson = responseArr.response; 
		var dataArr = JSON.parse(dataArrJson);
		if(dataArr.errors != '' && dataArr.errors != undefined )
		{ 
			simproerrors = dataArr.errors;  
		$('#'+display_log).text("");
			if(simproerrors.length > 0){
				for (var i = 0; i < simproerrors.length; i++) { 
					$('#'+display_log).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
				}  
			hide_loader();
			} 
		}
	}) 
}

function syncsites(globarr,customerData,module_name,record_id,api_name,display_log){ 
	var ext = localStorage.getItem("domain_extension");
	var reqObj= 
	{  
      url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/sites/',
      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
      type : 'POST',
      data : {}, 
      postBody : customerData,
	}
	ZOHODESK.request( reqObj ).then(function(response)
	{ 
		//console.log(response);
		var responseArr = JSON.parse(response); 
		if(responseArr.statusCode == 401)
		  	{
		  		token_message();
		  	}
		var dataArrJson = responseArr.response; 
		var dataArr = JSON.parse(dataArrJson);
		if(dataArr.errors != '' && dataArr.errors != undefined )
		{ 
			simproerrors = dataArr.errors;  
		$('#'+display_log).text("");
			if(simproerrors.length > 0){
				for (var i = 0; i < simproerrors.length; i++) { 
					$('#'+display_log).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
				}  
			hide_loader();
			} 
		}
		else
		{
			simpro_site_id = dataArr.ID; 
			globarr.related_simpro_site_id = simpro_site_id;
			$("#simpro_customer_id").val(globarr.related_simpro_site_id);
			if(simpro_site_id == "")
			{
				$('#'+display_log).text("Some Technical Error..."); 
				hide_loader();
			}
			else
			{
				//console.log(dataArrJson);
				pushdata = {};
				pushdata[api_name] = simpro_site_id.toString();
				var jreqObj= {
			     url : 'https://www.zohoapis.'+ext+'/crm/v2/'+module_name+'/'+record_id,
			      headers : { 'Content-Type' : 'application/json' },
			      type : 'PUT',
			      data : {},
			      postBody : {"data":[pushdata]},
			      fileObj: [],
			      connectionLinkName: "zohocrmconnection"
				}
				ZOHODESK.request( jreqObj ).then(function(response)
				{
					//console.log(response);
					var reload = "1";
					var dmessage = "Sync Successful! Please press the button again to create quote/job in simPRO.";
					modalPopup(reload,dmessage);
				});
			}
		}
	}).catch(function(err)
	{
		//console.log(err);
		$('#Hidden_Message_Log').text(err); 
		var responseArr = JSON.parse(err); 
		if(responseArr.statusCode == 401)
		  	{
		  		token_message();
		  	}
		var dataArrJson = responseArr.response; 
		var dataArr = JSON.parse(dataArrJson);
		if(dataArr.errors != '' && dataArr.errors != undefined )
		{ 
			simproerrors = dataArr.errors;  
		$('#'+display_log).text("");
			if(simproerrors.length > 0){
				for (var i = 0; i < simproerrors.length; i++) { 
					$('#'+display_log).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
				}  
			hide_loader();
			} 
		}
	}) 
}
function sendAccountToSimrpo(globarr,acc_Id,display_log)
{  
	//console.log(globarr);
	AccountData = globarr.account_record; 
	var customerData = {}; 
	customerData.CompanyName = AccountData.Account_Name; 

	if(globarr.extension_fields == "Yes")
	customerData.Email = AccountData.szs__Email; 
	else
	customerData.Email = "Email"; 

	customerData.Phone = AccountData.Phone;   
    synccustomer(globarr,customerData,"accounts",acc_Id,"companies","Simpro_Id",display_log);  
}


function getRelatedSites(globarr,module_api_name,record_id,related_list_api_name)
{ 

//console.log("123 - "+module_api_name+" - "+record_id+" - "+related_list_api_name);


	$("#Simpro_Site_name_val").empty();

	var ext = localStorage.getItem("domain_extension");
	var reqObj= {
     url : 'https://www.zohoapis.'+ext+'/crm/v2/'+module_api_name+'/'+record_id+'/'+related_list_api_name,
      headers : { 'Content-Type' : 'application/json' },
      type : 'GET',
      data : {}, 
      postBody : {},
      fileObj: [],
      connectionLinkName: "zohocrmconnection"
	}  
	ZOHODESK.request( reqObj ).then(function(response){ 
	// hide_loader();
	var responseArr = JSON.parse(response);
	var dataArrJson = responseArr.response; 
	var dataArr = JSON.parse(dataArrJson); 
	mainResponse = dataArr.statusMessage;
		if(mainResponse !== "" && mainResponse.data != undefined)
		{
		var accountDataArr = mainResponse.data;

		globarr.related_all_site_data = accountDataArr; 

		var counti = 0;
		var def_sit_check = 0;

		for (var i = 0; i < accountDataArr.length; i++)
		 { 
			var Simpro_Site_Id = accountDataArr[i].Simpro_Site_Id; 
			var Simpro_Site_Name = accountDataArr[i].Name;
			//console.log("Simpro_Site_Name - "+Simpro_Site_Name);


			if(Simpro_Site_Name.toUpperCase() == globarr.default_site_name_simpro )
			{
				def_sit_check = def_sit_check + 1;

			} 

counti = counti + 1;
			if(counti == 1)
			{
			$('#Simpro_Site_name_val').append($("<option></option>").attr("value", Simpro_Site_Id).attr("selected","selected").text(Simpro_Site_Name));

			$("#Simpro_Site_Id").val(Simpro_Site_Id);  
			globarr.related_simpro_site_id = Simpro_Site_Id; 
			globarr.related_zoho_site_object = accountDataArr[i];
			}
			else
			{
			 $('#Simpro_Site_name_val').append($("<option></option>").attr("value", Simpro_Site_Id).text(Simpro_Site_Name));
			} 

			

			if(Simpro_Site_Id == ""){
				globarr.related_zoho_site_id = null;
			}

			if(Simpro_Site_Id != "")
			{
				//break;
			}
			
		} 


		if(counti != 0 && def_sit_check == 0)
		{
			
		}
		else if( def_sit_check == 0 && counti == 0)
		{
			default_site_name(globarr);

			// $('#Simpro_Site_name_val').append($("<option></option>").attr("value", "").text(globarr.default_site_name_simpro));
			// $("#Simpro_Site_Id").val("");  
		}


	}
	else{
		default_site_name(globarr);

			// $('#Simpro_Site_name_val').append($("<option></option>").attr("value", "").text(globarr.default_site_name_simpro));
			// $("#Simpro_Site_Id").val("");  

			globarr.related_simpro_site_id = null; 
			globarr.related_zoho_site_object = null;
			hide_loader();
		return true;
	}

	hide_loader();
	}).catch(function(err){
	      // Error handling
	  console.log(err);
		hide_loader();
	})
}

function default_site_name(globarr)
{

	var ext = localStorage.getItem("domain_extension");

	var reqObj= 
	{  
      url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/sites/'+globarr.default_site_id,
      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
      type : 'GET',
      data : {},
	  postBody : {},
	  fileObj: [],
	}

	ZOHODESK.request( reqObj ).then(function(response){ 

	var responseArr = JSON.parse(response);
	var dataArrJson = responseArr.response; 
	var dataArr = JSON.parse(dataArrJson); 


	if(dataArr.errors != '' && dataArr.errors != undefined )
	{ 
		simproerrors = dataArr.errors;  
		$('#Quote_Message_Log').text("");
		if(simproerrors.length > 0){
		for (var i = 0; i < simproerrors.length; i++) { 
		$('#Quote_Message_Log').append("Default Site not found for this Site ID - "+globarr.default_site_id);  
		}
		hide_loader();   
		} 
	}
	else
	{
	globarr.default_site_name_simpro = dataArr.Name;

	$('#Simpro_Site_name_val').append($("<option></option>").attr("value", "").text(globarr.default_site_name_simpro));
	$("#Simpro_Site_Id").val("");  
}

	}).catch(function(err){
	      // Error handling
	  console.log(err);
		hide_loader();
	})


}

function default_site_name_check(globarr)
{
	var ext = localStorage.getItem("domain_extension");

	var reqObj= 
	{  
      url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/sites/'+globarr.default_site_id,
      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
      type : 'GET',
      data : {},
	  postBody : {},
	  fileObj: [],
	}

	ZOHODESK.request( reqObj ).then(function(response){ 

	var responseArr = JSON.parse(response);
	var dataArrJson = responseArr.response; 
	var dataArr = JSON.parse(dataArrJson); 


	if(dataArr.errors != '' && dataArr.errors != undefined )
	{ 
		simproerrors = dataArr.errors;  
		$('#Quote_Message_Log').text("");
		if(simproerrors.length > 0){
		for (var i = 0; i < simproerrors.length; i++) { 
		$('#Quote_Message_Log').append("Default Site not found for this Site ID - "+globarr.default_site_id);  
		}
		hide_loader();   
		} 
	}
	else
	{
	
	}

	}).catch(function(err){
	      // Error handling
	  console.log(err);
		hide_loader();
	})


}


function getTiketDetails(module_api_name,record_id)
{ 

	var ext = localStorage.getItem("domain_extension");
	var reqObj= {
     url : 'https://www.zohoapis.'+ext+'/crm/v2/'+module_api_name+'/'+record_id,
      headers : { 'Content-Type' : 'application/json' },
      type : 'GET',
      data : {}, 
      postBody : {},
      fileObj: [],
      connectionLinkName: "zohocrmconnection"
	} 
	ZOHODESK.request( reqObj ).then(function(response){ 
	//	hide_loader();
	var responseArr = JSON.parse(response);
	var dataArrJson = responseArr.response; 
	var dataArr = JSON.parse(dataArrJson);
	var accountDataArr = dataArr.statusMessage.data;
	if(accountDataArr != undefined){
		for (var i = 0; i < accountDataArr.length; i++) {   
			var Simpro_Site_Id = accountDataArr[i].Simpro_Site_Id; 
			//console.log(Simpro_Site_Id);
			$("#Simpro_Site_Id").val(Simpro_Site_Id);  
			if(Simpro_Site_Id != "")
			break;
		}
	}
	}).catch(function(err){
	      // Error handling
	  //console.log(err);
	})
}


function sendContactToSimrpo(globarr,contact_Id,display_log)
{ 

	//console.log(globarr);

	contactData = globarr.contact_record; 
	var customerData = {}; 
	var Full_Name = contactData.Full_Name; 
	if(contactData.First_Name != null)
	customerData.GivenName = contactData.First_Name; 
	else 
	customerData.GivenName = Full_Name; 
	if(contactData.Last_Name != null) 
	customerData.FamilyName = contactData.Last_Name; 
	else 
	customerData.FamilyName = Full_Name;  
	customerData.Email = "Email"; 

	customerData.Phone = contactData.Phone;   
    synccustomer(globarr,customerData,"contacts",contact_Id,"individuals","Customer_simPRO_ID",display_log);
}

function updateticket(ticket_id,updateData,refresh=1)
{

	console.log("in!!!"); 
	console.log(updateData);
	var ext = localStorage.getItem("domain_extension");
	var reqObj= {
		url : 'https://desk.zoho.'+ext+'/api/v1/tickets/'+ticket_id,
		headers : { 'Content-Type' : 'application/json' },
		type : 'PATCH',
		data : {},
		postBody : updateData,
		fileObj: [],
		connectionLinkName: "zohocrmconnection"
	}  
	ZOHODESK.request( reqObj ).then(function(response){  
	console.log(response);
	hide_loader();  
	if(refresh == 1){ 
		status == "1";
		var message = "Ticket Updated Successfully! ";
		modalPopup(status,message); 
		// location.reload();
	}else
	{
		// location.reload();
	}
							
	}).catch(function (err) {
	//error Handling
	//console.log(err);
	}); 
} 

function update_status(tick,refresh=1)
{

	
	hide_loader();  
	if(refresh == 1){ 
		status == "1";
		var message = "SimPRO Status Updated Successfully! ";
		modalPopup(status,message); 
		 location.reload();
	}else
	{
		 location.reload();
	}
							
	
}
		function quote_number_button_change(quote_job_id,quote_job_url)
		{

				 								const createQuoteButton = document.getElementById("createQuote");
							          const quoteButtonLink = document.createElement("a");
				                quoteButtonLink.href = quote_job_url;
				                quoteButtonLink.className  = createQuoteButton.className;
				                quoteButtonLink.innerHTML   =  "QN :"+quote_job_id ;
				                quoteButtonLink.target = '_blank';
				                quoteButtonLink.rel = 'noopener noreferrer';
				                quoteButtonLink.style.cssText = createQuoteButton.style.cssText;
				                createQuoteButton.parentNode.replaceChild(quoteButtonLink, createQuoteButton);

		}

		function job_number_button_change(quote_job_id,quote_job_url)
		{

				 								const createJobButton = document.getElementById("createJob");
							          const jobButtonLink = document.createElement("a");
				                jobButtonLink.href = quote_job_url;
				                jobButtonLink.className  = createJobButton.className;
				                jobButtonLink.innerHTML   =  "JN :"+quote_job_id ;
				                jobButtonLink.target = '_blank';
				                jobButtonLink.rel = 'noopener noreferrer';
				                jobButtonLink.style.cssText = createJobButton.style.cssText;
				                createJobButton.parentNode.replaceChild(jobButtonLink, createJobButton);

		}

function modalPopup(status,message)
{ 
	ZOHODESK.showpopup({ 
	    title : "Alert Message",
	    content: message, 
	    type : "alert",
	    contentType : "html", 
	    color : "red", 
	    okText : "Close",
	    cancelText : ""
	}).then(res=>{
	    //console.log("success");  
	    location.reload();
	},(err)=>{
	    //console.log(err);
	    location.reload();
	}); 
}

function getthreadData(ticket_id)
{ 
	var ext = localStorage.getItem("domain_extension");
	var reqObj= {
		url : 'https://desk.zoho.'+ext+'/api/v1/tickets/'+ticket_id+'/threads',
		headers : { 'Content-Type' : 'application/json' },
		type : 'GET',
		data : {},
		postBody : {},
		fileObj: [],
		connectionLinkName: "zohocrmconnection"
	}  
	ZOHODESK.request( reqObj ).then(function(response){    
		//console.log(response);
			var responseArr = JSON.parse(response);
			var dataArrJson = responseArr.response; 
			var dataArr = JSON.parse(dataArrJson);
			var threadDataArr = dataArr.statusMessage.data;
			if(threadDataArr.length != 0) { 
				var messageIndex = threadDataArr.length - 1; 
				$("#description").val(threadDataArr[messageIndex].summary);
			}
			// hide_loader();
			// var updateData = {"description":threadDataArr[messageIndex].summary};
			// updateticket(ticket_id,updateData,0); 
	}).catch(function (err) {
	//error Handling
	//console.log(err);
	}); 
}
function show_loader(){
	$("#loader").addClass("spinner-border");
  //event.preventDefault();
}

function hide_loader(){
	$("#loader").removeClass("spinner-border");
  //event.preventDefault();
} 

function show_jobloader(){
	$("#jobloader").addClass("spinner-border"); 
}

function hide_jobloader(){
	$("#jobloader").removeClass("spinner-border"); 
} 

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function runWithDelay(globarr) {
    console.log("Wait for 5 seconds...");
    await delay(5000); // 10,000 milliseconds = 10 seconds
    console.log("5 seconds have passed!");

    ticket_data_details(globarr);

}

function ticket_data_details(globarr)
{
	ZOHODESK.get('ticket').then(function (res) 
	{
		email = res.ticket.email;  
		ticket_id = res.ticket.id; 

		var reqObj= {
	      url : 'https://desk.zoho.com/api/v1/tickets/'+ticket_id+'/comments',
	      headers : { 'Content-Type' : 'application/json' },
	      type : 'GET',
	      data : {},
	      postBody : {},
	      fileObj: [],
	      connectionLinkName: "zohocrmconnection"
		}  

	ZOHODESK.request( reqObj ).then(function(response){ 

	var responseArr = JSON.parse(response);
	var dataArrJson = responseArr.response; 
	var dataArr = JSON.parse(dataArrJson); 
	var commentsDataArr = dataArr.statusMessage.data;
	var cf_quotenumber = globarr.cf_quotenumber;
	var cf_jobnumber = globarr.cf_jobnumber;
	var simpro_comment_subject_list_quotes = [];
	var simpro_comment_subject_list_jobs = [];
	let simproquotelist = [];

	if(cf_jobnumber != null)
	{
		module_name = "jobs";
		simpro_job_quote_id = cf_jobnumber;
	}

	else if(cf_quotenumber != null)
	{
		module_name = "quotes";
		simpro_job_quote_id = cf_quotenumber;
	}
	 

	if(commentsDataArr != undefined)
	{
		if(cf_jobnumber != null  || cf_quotenumber != null )
		{

			var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/'; 
			var reqObj=
				{
						url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/'+module_name+'/'+simpro_job_quote_id+'/notes/',
						headers : {  'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
						type : 'GET',
						data : {},
						postBody : {},
						fileObj: [],
				} 

			ZOHODESK.request( reqObj ).then(function(response){ 
			var responseArr = JSON.parse(response);  
			var responseResponseArr = JSON.parse(responseArr.response);
			const simproquotelist = responseResponseArr.map(item => item.Subject);
			for (var i = 0; i < commentsDataArr.length; i++)
			{   
				var content = commentsDataArr[i].content; 
				if(!content.startsWith('SimproActicityNote'))
				{
					var noteCreator = commentsDataArr[i].commenter.name; 
					var commentID = commentsDataArr[i].id; 
					var commentedTime = commentsDataArr[i].commentedTime; 
					var sub = "ZohoDeskCreated:"+noteCreator+" - "+commentedTime;
					const isValueInList = simproquotelist.includes(sub);
				//	console.log(sub +" -- "+isValueInList);
					if(isValueInList != true)
					{

						if(cf_jobnumber != null || cf_quotenumber != null )
						{ 

							var timeline_notes_quote = {"Subject":sub,"Note":content};
							
							var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/'; 
							var reqObj=
								{
									url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/'+module_name+'/'+simpro_job_quote_id+'/notes/',
									headers : {  'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
									type : 'POST',
									data : {},
									postBody : timeline_notes_quote,
								} 

							ZOHODESK.request( reqObj ).then(function(response){ 
							var responseArr = JSON.parse(response);  
							var responseResponseArr = JSON.parse(responseArr.response);
							//console.log(responseResponseArr);
							}).catch(function(err){
							      // Error handling
							  console.log(err);
								hide_loader();
							})
						}

					}
				}
			}
			}).catch(function(err){
			// Error handling
			console.log(err);
			hide_loader();
			})

		}
	}

	}).catch(function(err){
	      // Error handling
	  console.log(err);
		hide_loader();
	})

	}).catch(function (res) {
		//error Handling
		hide_loader();
	});  
}

function simpro_note_data_details(globarr)
{

	ZOHODESK.get('ticket').then(function (res) 
	{
		email = res.ticket.email;  
		ticket_id = res.ticket.id; 

		var reqObj= {
	      url : 'https://desk.zoho.com/api/v1/tickets/'+ticket_id+'/comments',
	      headers : { 'Content-Type' : 'application/json' },
	      type : 'GET',
	      data : {},
	      postBody : {},
	      fileObj: [],
	      connectionLinkName: "zohocrmconnection"
		}  

	ZOHODESK.request( reqObj ).then(function(response){ 

	var responseArr = JSON.parse(response);
	var dataArrJson = responseArr.response; 
	var dataArr = JSON.parse(dataArrJson); 
	var commentsDataArr = dataArr.statusMessage.data;
	var cf_quotenumber = globarr.cf_quotenumber;
	var cf_jobnumber = globarr.cf_jobnumber;
	var simpro_comment_subject_list_quotes = [];
	var simpro_comment_subject_list_jobs = [];
	let simproquotelist = [];

	if(cf_jobnumber != null)
	{
		module_name = "jobs";
		simpro_job_quote_id = cf_jobnumber;
	}

	else if(cf_quotenumber != null)
	{
		module_name = "quotes";
		simpro_job_quote_id = cf_quotenumber;
	}

	if(commentsDataArr != undefined)
	{
		if(cf_jobnumber != null  || cf_quotenumber != null )
		{

			var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/'; 
			var reqObj=
				{
						url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/'+module_name+'/'+simpro_job_quote_id+'/notes/',
						headers : {  'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
						type : 'GET',
						data : {},
						postBody : {},
						fileObj: [],
				} 

			ZOHODESK.request( reqObj ).then(function(response){ 
			var responseArr = JSON.parse(response);  
			var responseResponseArr = JSON.parse(responseArr.response);
			const simproquotelist = responseResponseArr.map(item => item.Subject);
			for (var i =0; i <responseResponseArr.length; i++)
			{

				var note_id = responseResponseArr[i].ID;
				var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/'; 
				var reqObj=
					{
						url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/'+module_name+'/'+simpro_job_quote_id+'/notes/'+note_id,
						headers : {  'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
						type : 'GET',
						data : {},
						postBody : {},
						fileObj: [],
					} 

				ZOHODESK.request( reqObj ).then(function(response){ 
				var responseArr = JSON.parse(response);  
				var responseResponseArr = JSON.parse(responseArr.response);
				//console.log(responseResponseArr);
				var note = responseResponseArr.Note;
				var subject = responseResponseArr.Subject;
				var note_id_new = responseResponseArr.ID;
				
				if (!subject.startsWith('ZohoDeskCreated')) 
				{
					if( !note.startsWith('Zoho Desk ticket URL'))
					{

					var starte_content = "SimproActicityNote:"+note_id_new;
					var desk_content =  "SimproActicityNote:"+note_id_new+" - "+note;
					var count_check = 0;
					for (var i = 0; i < commentsDataArr.length; i++)
					{   
						var content = commentsDataArr[i].content; 
						if (content.startsWith(starte_content)) 
						{

							count_check = 1;
						}
					}
					if(count_check == 0)
					{
					var jreqObj= {
				      url : 'https://desk.zoho.com/api/v1/tickets/'+ticket_id+'/comments',
				      headers : { 'Content-Type' : 'application/json' },
				      type : 'POST',
				      data : {},
				      postBody : {"content":desk_content,"isPublic":false,"contentType":"html"},
				      fileObj: [],
				      connectionLinkName: "zohocrmconnection"
					}  

						ZOHODESK.request( jreqObj ).then(function(response)
						{
							//console.log(response);
							hide_loader();
							hide_jobloader();
							

						}).catch(function(err)
						{ 
							//console.log(err); 
							hide_loader();
						});
					}
					}
				}
				}).catch(function(err){
				      // Error handling
				  console.log(err);
					hide_loader();
				})
			}
				
		}).catch(function(err){
		// Error handling
		 console.log(err);
		hide_loader();
		})

		}
	}
	}).catch(function(err){
	      // Error handling
	  console.log(err);
		hide_loader();
	})

	}).catch(function (res) {
		//error Handling
		hide_loader();
	});  
}  
 
	 
function isNumber(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}
const IsParsable = (data) => {
  try {
        JSON.parse(data);
       } catch (e) {
        return false;
      }
   return true;
}
window.onload = function () 
{
	let DefaultSiteArr = [];
	let comapnyIdArr = [];
	let PortalIdArr = [];
	let globarr = [];
	let DefaultCustomerArr = [];
	globarr.contact_record = null;
	globarr.account_record = null;
	globarr.simpro_ustomer_id_for_quote = null;
	globarr.customer_contact_id = null;


	var default_multicompany_value = "No";
	$("#Multi_Company").val(default_multicompany_value); 
	if(default_multicompany_value.toUpperCase() === 'YES')
	{
		$("#Simpro_Company_ID_Block").css("display","block");  
	} 
    globarr.multi_company = default_multicompany_value;
 

	show_loader();  
	const myTimeout = setTimeout(myGreeting, 5000); 

	function myGreeting() {
	    hide_loader(myTimeout);
	}  
	hide_jobloader();

	
	function searchcustomer(globarr)
	{
		//.log("search_cus");
		
		var ext = localStorage.getItem("domain_extension");
	var queury  = '?criteria=(';
	if(Extension_Fields == "No")
	queury = queury + '(Email:equals:'+globarr.email+')';
	else 
	queury = queury + '(szs__Email:equals:'+globarr.email+')';
//console.log(queury);
	if(globarr.extension_fields == "Yes")
	{
		ex_prefix = "szs__";
	}
	if(globarr.multi_company == "Yes" || globarr.multi_company == "No")
	queury = queury + 'and('+ex_prefix+'SimPRO_Company_ID:equals:'+globarr.default_company_id+')';
	queury = queury + ')';
	var reqObj= {
	  url : 'https://www.zohoapis.'+ext+'/crm/v2/Accounts/search'+queury,
	  headers : { 'Content-Type' : 'application/json' },
	  type : 'GET',
	  data : {},
	  postBody : {},
	  fileObj: [],
	  connectionLinkName: "zohocrmconnection"
	}
	ZOHODESK.request( reqObj ).then(function(response)
	{ 
		var responseArr = JSON.parse(response);
		var dataArrJson = responseArr.response; 
		var dataArr = JSON.parse(dataArrJson);
		var accountDataArr = dataArr.statusMessage.data;
		//console.log("accounts search-"+accountDataArr);
		if(accountDataArr != undefined){
			for (var i = 0; i < accountDataArr.length; i++) {   
				globarr.account_record = accountDataArr[i];
				var Simpro_Id = accountDataArr[i].Simpro_Id; 
				var Zoho_Customer_Id = accountDataArr[i].id; 
				$("#Simpro_Customer_Id").val(Simpro_Id);  
				$("#Zoho_Customer_Id").val(Zoho_Customer_Id); 
				$("#module_name").val("Accounts"); 
				var Account_Related_Site = $("#Account_Related_Site").val();
				getRelatedSites(globarr,"Accounts",Zoho_Customer_Id,Account_Related_Site);
				if(Simpro_Id != "")
				{ 
					break;
				}
			}
		}
		else{
			seachcustomerincontact(globarr);
		}

	}).catch(function(err){
	       //console.log(err);
	})
	}
	ZOHODESK.extension.onload().then(function (App) 
	{   
		var domainMap = new Map();
		domainMap.set("US","com");
		domainMap.set("EU","eu"); 
		domainMap.set("AU","com.au"); 
		let currentDomain = App.meta.dcType;  

		function getallquotenotes(globarr,module_name,module_id)
		{   
		 	var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/'; 
			var reqObj= {
			  url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/'+module_name+'/'+module_id+'/notes/',
			  headers : { 'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
		     type : 'GET',
		     data : {},
		     postBody : {},
		     fileObj: [],
		 	} 
		 	// console.log(reqObj);
			ZOHODESK.request( reqObj ).then(function(response)
			{
				var create_new = true;
				var responseArr = JSON.parse(response);  
				var responseResponseArr = JSON.parse(responseArr.response); 
				// console.log(responseResponseArr);
				// console.log(globarr.tic_number);
				if(responseResponseArr.length > 0)
				{
					for (var i = 0; i < responseResponseArr.length; i++) { 
					var ReferenceArr = responseResponseArr[i]['Reference'];
					var tic_Subject = responseResponseArr[i]['Subject'];
						if((tic_Subject.indexOf(globarr.tic_number) !== -1)){  
							var create_new = false;
							break;
						}
					}
					if(create_new == true)
					{ 
						createquotenote(globarr,module_name,module_id);
					}
				}
				else{ 
						createquotenote(globarr,module_name,module_id);
				}
				hide_loader(); 
			    hide_jobloader();
			}).catch(function(err){
				// console.log("getallquotenotes");
			    hide_loader(); 
			    hide_jobloader(); 
				// console.log(err); 
			}) 
		}

	
		localStorage.setItem("domain_extension", domainMap.get(currentDomain));  
		ZOHODESK.get("extension.config").then(function(response)
		{
			  // response returns the installation parameters of the extension 
				var configArr = response['extension.config']; 
				//console.log(configArr);
				var coufig_counter = 1;

				var fisrt_company_id = ""; 
				for (var i = 0; i < configArr.length; i++) 
				{ 
					//console.log(configArr[i].name);

					if("Default_Site_ID" == configArr[i].name)
					{
					var sitesArr = configArr[i].value;
					var sarray = sitesArr.split(',');  
					$.each(sarray,function(j)
					{  
						DefaultSiteArr[j] = sarray[j];
						if(j === 0){ 
					    $('#Default_Site_ID').append($("<option></option>")
					              .attr("value", sarray[j])
					              .attr("selected","selected")
					              .text(sarray[j]));
					              globarr.default_site_id = sarray[j];  
						}
						else
						{
						$('#Default_Site_ID').append($("<option></option>")
					              .attr("value", sarray[j])
					              .text(sarray[j])); 
						}
					});  
 
					} 
					if("Account_Related_Site" == configArr[i].name)
					{
						$("#Account_Related_Site").val(configArr[i].value);

					    globarr.account_related_site = configArr[i].value;
					} 
					if("Sync_To_Quotes" == configArr[i].name)
					{
						$("#Sync_To_Quotes").val(configArr[i].value); 
						var Sync_To_Quotes = configArr[i].value;
						if(Sync_To_Quotes == "Yes")
					 	{ 
							$("#Oppy_Number_main_div").css("display","block");  
					 	}else{
					 		$("#Oppy_Number").val("");
					 	}
					    globarr.sync_to_quotes = configArr[i].value;
					}
					// if("Hide_Due_Date" == configArr[i].name)
					// { 
					// 	var Hide_Due_Date = configArr[i].value;
					// 	if(Hide_Due_Date == "Yes")
					//  	{ 
					// 		$("#due_date_block").css("display","block");  
					//  	}else{
					// 		$("#due_date_block").css("display","none");
					//  	} 
					// } 
					// if("Hide_Followup_Date" == configArr[i].name)
					// {
					//  	var Hide_Followup_Date = configArr[i].value;
					// 	if(Hide_Followup_Date == "Yes")
					//  	{ 
					// 		$("#followup_date_block").css("display","block");  
					//  	}else{
					// 		$("#followup_date_block").css("display","none");
					//  	} 
					// }  					
					  
					if("Contact_Related_Site" == configArr[i].name)
					{
						$("#Contact_Related_Site").val(configArr[i].value);
					    globarr.contact_related_site = configArr[i].value;
					}
					if("Extension_Fields" == configArr[i].name)
					{
						$("#Extension_Fields").val(configArr[i].value);
					    globarr.extension_fields = configArr[i].value;
					}

					if("Multi_Company" == configArr[i].name)
					{ 
						$("#Multi_Company").val(configArr[i].value); 
						var Multi_Company_Value = configArr[i].value;
						globarr.multi_company = configArr[i].value;
						if(Multi_Company_Value.toUpperCase() === 'YES')
						{
							multicompany = true;
							$("div#Simpro_Company_ID_Block").css("display","block");  
						} 
  
								if(Multi_Company_Value.toUpperCase() != "YES" && Multi_Company_Value.toUpperCase() != "NO")
								{
									let _multicomany_error = "Please check the value for multi_company in configuration settings... Please set only the values Yes Or No"; 							
									$('#Quote_Message_Log').text(_multicomany_error); 
							    $('#Job_Message_Log').text(_multicomany_error);
						      hide_loader();
									return true; 
								}

					}   
					if("subdomainsimpro" == configArr[i].name)
					{ 
						globarr.subdomainsimpro = configArr[i].value;
					} 
					if("simpro_api_key" == configArr[i].name)
					{ 
						globarr.simpro_api_key = configArr[i].value;
					}
					if("Default_Customer_Type" == configArr[i].name)
					{  
						globarr.default_customer_type = configArr[i].value; 
						let default_customer_type = configArr[i].value;
						if(default_customer_type.toLowerCase() != "company" && default_customer_type.toLowerCase() != "individual")
						{
							let default_customer_type_error = "Please check the value for default customer type in configuration settings... Please set only the values Company or Individual"; 							
							$('#Quote_Message_Log').text(default_customer_type_error); 
					   		 $('#Job_Message_Log').text(default_customer_type_error);
				      		hide_loader();
							return true; 
						}
					} 
					if("Create_Customer_Check" == configArr[i].name)
					  { 
					    	var Create_Customer_Check_Value = configArr[i].value;
							if(Create_Customer_Check_Value.toUpperCase() == "YES")
						      globarr.create_customer = true;
						      else if(Create_Customer_Check_Value.toUpperCase() == "NO")
						      globarr.create_customer = false;
						  	else
						  	{
						  		var _default_cust_error = "Please check the configuration settings... Please set value for create customer only Yes/NO.";
					            $('#Quote_Message_Log').text(_default_cust_error); 
					            $('#Job_Message_Log').text(_default_cust_error);  
					            hide_loader();
					            hide_jobloader();
					            return true;
						  	}
					    }
					  if("Default_Customer_Id" == configArr[i].name)
					  {
					      var defaultcustArr = configArr[i].value;
					      var defaultcustArr = defaultcustArr.split(',');   
					      $.each(defaultcustArr,function(j)
					      {  
					        if(!isNumber(defaultcustArr[j])){
					           var _default_cust_error = "Please check the configuration settings... Please set value for default customer only number.";
					            $('#Quote_Message_Log').text(_default_cust_error); 
					            $('#Job_Message_Log').text(_default_cust_error);  
					            hide_loader();
					            return;
					          }
					          else{
					          	DefaultCustomerArr[j] = defaultcustArr[j];
							        if(j === 0){ 
							          $('#Default_Cusotmer_ID').append($("<option></option>")
							                .attr("value", defaultcustArr[j])
							                .attr("selected","selected")
							                .text(defaultcustArr[j]));    
							          globarr.default_customer_id = defaultcustArr[j];
							        }
							        else
							        {
							          $('#Default_Cusotmer_ID').append($("<option></option>")
							                .attr("value", defaultcustArr[j])
							                .text(defaultcustArr[j]));  
							        } 
					          } 
					      });  
					    } 	
					// if("Default_Project_Type" == configArr[i].name)
					// {
					// 	$("#Default_Project_Type").val(configArr[i].value);
					// 	$("#projectType").val(configArr[i].value);
					// 	globarr.default_project_type = configArr[i].value;
					// } 				
				 
					if("Simpro_Companies" == configArr[i].name)
					{
						const simprocompanylist = [];
						var Simpro_Companies = configArr[i].value;
						var scArray = Simpro_Companies.split(',');   
						$.each(scArray,function(j)
						{   
							if(scArray[j].includes("-"))
							{ 
								var companyArr = scArray[j].split('-'); 
								var comp_id = companyArr[0].trim();
								simprocompanylist.push(comp_id);
								var comp_name = companyArr[1].trim(); 
								comapnyIdArr[j] = comp_id; 
								if(j == 0)
								{
									fisrt_company_id = comp_id; 
									globarr.default_company_id = comp_id;   
									$('#Simpro_Company_ID').append($("<option></option>").attr("value", comp_id).attr("selected","selected").text(comp_name));
								}
								else
								{
									$('#Simpro_Company_ID').append($("<option></option>").attr("value", comp_id).text(comp_name));
								} 
							  
							}
							else{
								displayErrorMessage("Please check your simpro company settings.");
								return;
							}   
						});
						globarr.simprocompanylist = simprocompanylist;
					} 

					if("Update_simPRO_Status_from_Desk" == configArr[i].name)
					{ 
						globarr.Update_simPRO_Status_from_Desk = configArr[i].value;
					}

					// if("Auto_Adjust" == configArr[i].name)
					// {
					// 	$("#Auto_Adjust").val(configArr[i].value);
					// } 	

 
					/*********multicompany case**********/
					

					if( coufig_counter == configArr.length){
						$("#Simpro_Company_ID").val($("#Simpro_Company_ID option:first").val());
 
						// var company_id = localStorage.getItem("company_id");
						// if(company_id == "" || company_id == undefined)
						// {   
						//  company_id = fisrt_company_id;
						// } 
						// $("#Simpro_Company_ID").val(company_id).trigger('change'); 
						// $("#Simpro_Company_ID").val(company_id); 
					}

					coufig_counter = coufig_counter + 1; 
				}  

				default_site_name_check(globarr);
				fetch_quote_cost_center(globarr);
				fetch_quote_report_tag(globarr);


			// find data in crm
			ZOHODESK.get('ticket').then(function (res) 
			{
				// console.log(res);
				var tic_id = res.ticket.id;
				globarr.tic_id = tic_id; 
				var tic_number = res.ticket.number;
				globarr.tic_number = tic_number;
				globarr.ticket_url = res.ticket.link; 
				var timeline_notes_quote = {"Subject":"This quote has been linked from the Zoho Desk ticket ID #"+globarr.tic_number,"Note":"Zoho Desk ticket URL: <a target='_blank' href='"+globarr.ticket_url+"'>"+globarr.ticket_url+"</a>"};
				var timeline_notes_job = {"Subject":"This Job has been linked from the Zoho Desk ticket ID #"+globarr.tic_number,"Note":"Zoho Desk ticket URL: <a  target='_blank' href='"+globarr.ticket_url+"'>"+globarr.ticket_url+"</a>"};
				globarr.timeline_notes_quote = timeline_notes_quote; 
				globarr.timeline_notes_job = timeline_notes_job; 
				email = res.ticket.email;  
				phone = res.ticket.phone;  
				contactName = res.ticket.contactName;   

				globarr.contactName = contactName;  
				globarr.email = email;  
				globarr.phone = phone;  
				var description = res.ticket.description; 
				$("#description").val(description);
				$("#email").val(email); 



				var Extension_Fields= $("#Extension_Fields").val();
				if(description == null)
					{
						show_loader();
						getthreadData(globarr.tic_id);
					}
				$("#tic_id").val(globarr.tic_id);
				searchcustomer(globarr);
			}).catch(function (res) {
				//console.log(res);
			}); 

		
 			

			ZOHODESK.get('ticket.cf').then(function (res) 
			{  


				var Extension_Fields_Global= $("#Extension_Fields").val();  
				if(Extension_Fields_Global == "No")
				var job_module = 'Jobs';
				else 
				var job_module = 'szs__Jobs';  

				var Simpro_Domain_Prefix =  $("#Simpro_Domain_Prefix").val(); 
				var tic_id =  $("#tic_id").val();
				var Multi_Company = $("#Multi_Company").val();
			  	if(res['ticket.cf'] != null)
			  	{ 
					var cf_simpro_quote_number = res['ticket.cf'].cf_simpro_quote_number;
					var cf_simpro_job_number = res['ticket.cf'].cf_simpro_job_number;
					var cf_simpro_company_id = res['ticket.cf'].cf_simpro_company_id; 
					globarr.cf_quotenumber = cf_simpro_quote_number;
					globarr.cf_jobnumber = cf_simpro_job_number;

					
					if(cf_simpro_company_id != null)
					{
						var first_calue = $("#Simpro_Company_ID option:first").val();
						if(first_calue != parseInt(cf_simpro_company_id))
						{
							$("#Simpro_Company_ID").val(cf_simpro_company_id).trigger('change'); 
						}
					}  
			  	}
				else
				{ 
					var cf_simpro_job_number = null;
					var cf_simpro_quote_number = null; 
					globarr.cf_quotenumber = null;
					globarr.cf_jobnumber = null;
				}  
				

				var ext = localStorage.getItem("domain_extension"); 



				if(cf_simpro_quote_number != null )
				{  
 
					var reqObj= {
					     url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/quotes/'+cf_simpro_quote_number,
					     headers : { 'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
					     type : 'GET',
					     data : {},
					     postBody : {},
					     fileObj: [],
					 //    connectionLinkName: "zohodeskcon"
					}   
					ZOHODESK.request( reqObj ).then(function(response)
					{   
						var responseArr = JSON.parse(response); 
						if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
						var dataArrJson = responseArr.response; 
						var dataArr = JSON.parse(dataArrJson);
						if(dataArr.errors != '' && dataArr.errors != undefined )
						{ 
							simproerrors = dataArr.errors;  
						$('#Quote_Message_Log').text("");
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Quote_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}
								hide_loader();   
							} 
						}
						else
						{ 
							var quote_id = dataArr.ID;  
							if(quote_id != "")
							{ 
								var simpro_ustomer_id_for_quote = dataArr.Customer.ID;
								var CustomFields = dataArr.CustomFields; 
							    globarr.simpro_ustomer_id_for_quote = simpro_ustomer_id_for_quote;
							    getallquotenotes(globarr,"quotes",quote_id);

								$('#Quote_Message_Log').text("Quote linked successfully.");  
								quote_url =  "https://"+globarr.subdomainsimpro+".simprosuite.com/staff/editProject.php?quoteID="+quote_id;
								$("#Quote_Number").val(quote_id);
								$("#quote_link").text(quote_url);
								$("#quote_link").attr("href",quote_url); 
								//$("#createQuote").css("display","none");
								quote_number_button_change(quote_id,quote_url);
							}
						} 
					}).catch(function(err){  
						$('#Hidden_Message_Log').text(err); 
					})   

				}
				else{ 
				$("#createQuote").css("display","block");  
				}

				if(globarr.Update_simPRO_Status_from_Desk == "No")
				{

					$("#updatestatus").css("display","none");

				}
 


				if(cf_simpro_job_number != null )
				{ 
 
					var reqObj= {
					     url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/jobs/'+cf_simpro_job_number,
					     headers : { 'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
					     type : 'GET',
					     data : {},
					     postBody : {},
					     fileObj: [],
					}   
					ZOHODESK.request( reqObj ).then(function(response)
					{   
						var responseArr = JSON.parse(response); 
						if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
						var dataArrJson = responseArr.response; 
						var dataArr = JSON.parse(dataArrJson);
						if(dataArr.errors != '' && dataArr.errors != undefined )
						{ 
							simproerrors = dataArr.errors;  
						$('#Job_Message_Log').text("");
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Job_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}
								hide_loader();   
							} 
						}
						else{ 
								var job_id = dataArr.ID; 
								if(job_id != "")
								{
									var simpro_ustomer_id_for_quote = dataArr.Customer.ID;
								 	globarr.simpro_ustomer_id_for_quote = simpro_ustomer_id_for_quote;

								    getallquotenotes(globarr,"jobs",job_id);

									$('#Job_Message_Log').text("Job linked successfully.");
									job_url =  "https://"+globarr.subdomainsimpro+".simprosuite.com/staff/editProject.php?jobID="+job_id;
									$("#Job_Number").val(job_id);
									$("#job_link").text(job_url);
									$("#job_link").attr("href",job_url); 
									//$("#createJob").css("display","none");
									job_number_button_change(job_id,job_url);
								}
							} 
					}).catch(function(err){  
					 $('#Hidden_Message_Log').text(err); 
					})   
				}
				else
				{ 
					$("#createJob").css("display","block");   
				}  

			}).catch(function (err) { 
				//console.log(err);
			}); 

			// *********/

		}).catch(function(err){
			//console.log(err);
		})   

		// find data to extension area
	    
		// createQuote
		$("#Simpro_Company_ID").change(function()
		{ 

			//console.log("inside_company_change_event");
			//console.log(DefaultSiteArr);
			//console.log(PortalIdArr);  
			//console.log(comapnyIdArr);  
			//console.log(DefaultCustomerArr);  
			$('#Quote_Message_Log').text(""); 
			show_loader();
			let company_id =  $(this).val();
			let indexOfComapnyId = comapnyIdArr.indexOf(company_id); 
			localStorage.setItem("company_id",company_id);
			let relatedSiteId =  DefaultSiteArr[indexOfComapnyId];
			// let relatePortalId =  PortalIdArr[indexOfComapnyId];
			let relateDefaultCustomerId =  DefaultCustomerArr[indexOfComapnyId];
			$("#Default_Site_ID").val(relatedSiteId);    
			// $("#Portal_User_ID").val(relatePortalId);  
			$("#Default_Customer_Id").val(relateDefaultCustomerId);  
			 
			globarr.default_company_id =  company_id; 
			globarr.default_site_id =  relatedSiteId; 
			// globarr.default_portal_id =  relatePortalId; 
			globarr.default_customer_id =  relateDefaultCustomerId; 

			$("#Simpro_Site_name_val").empty();
			// $('#Simpro_Site_name_val').append($("<option></option>").attr("value", "").text("Default Site"));
			$("#Simpro_Site_Id").val("");  
		

			default_site_name_check(globarr);
			//searchcustomer(globarr);
			//hide_loader();
			// hide_jobloader();
		});	 

		$("#Simpro_Site_name_val").change(function()
		{

			show_loader();
			let site_id =  $(this).val();
			globarr.related_simpro_site_id = site_id;
			$("#Simpro_Site_Id").val(site_id); 
			hide_loader();


		});
		function testnm(reqObj, globarr,companyid)
		{
			//console.log(reqObj);
			ZOHODESK.request( reqObj ).then(function(response)
				{  
				if(IsParsable(response)) {
					var responseArr = JSON.parse(response); 

					if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
					var dataArrJson = responseArr.response; 
					// console.log("companyid - "+companyid);
					// console.log("dataArrJson - "+dataArrJson);
					if(IsParsable(response)) {
								var dataArr = JSON.parse(dataArrJson);
								if(dataArr.errors != '' && dataArr.errors != undefined )
								{ 
									simproerrors = dataArr.errors;  
									if(simproerrors.length > 0){

								$('#Quote_Message_Log').text("");
										for (var i = 0; i < simproerrors.length; i++) { 
											$('#Quote_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
										}
										$("#quote_link").html("");   
										$("#Quote_Number").val(""); 
										hide_loader();   
									}  
								}
								else{  
											let results = dataArr;
							  if(results.hasOwnProperty('ID'))
				              {
				                var quote_id = results.ID; 

				                let ticket_url = globarr.ticket_url; 
				                $('#Quote_Message_Log').text("Quote linked successfully.");  
				                quote_url =  "https://"+globarr.subdomainsimpro+".simprosuite.com/staff/editProject.php?quoteID="+quote_id;
				                $("#Quote_Number").val(quote_id);
				                $("#quote_link").text(quote_url);
				                $("#quote_link").attr("href",quote_url); 
				                //$("#createQuote").css("display","none");  

				                quote_number_button_change(quote_id,quote_url);

								getallquotenotes(globarr,'quotes',quote_id);
								globarr.breakpoint = true;

								var selectElement = document.getElementById('Simpro_Company_ID');


								selectElement.value = Company_id_current;
								console.log("current company "+Company_id_current);
								return "done";

								
				              }
				              else{
				                $('#Quote_Message_Log').text("Quote not found.");
				              }  
				              hide_loader(); 
									
								} 
							} else{
							  $('#Quote_Message_Log').text("Quote not found.");

				              hide_loader();  
						}
					} else{
						$('#Quote_Message_Log').text("Quote not found.");
				              hide_loader(); 
					}
				}).catch(function(err){
					////console.log(err);
                    $('#Hidden_Message_Log').text(err); 
				              hide_loader(); 
				})  
		}

		App.instance.on("ticket_customFields.changed", function(data)
		{ 

			var Extension_Fields_Global= $("#Extension_Fields").val();  

			if(Extension_Fields_Global == "No")
			var job_module = 'Jobs';
			else 
			var job_module = 'szs__Jobs'; 

			var tic_id =  $("#tic_id").val(); 
			var ext = localStorage.getItem("domain_extension");
			var sync_to_quotes = $("#Sync_To_Quotes").val();
			show_loader();  
			var Simpro_Domain_Prefix =  $("#Simpro_Domain_Prefix").val(); 
		 

			if(data['ticket.customFields']['Simpro Quote Number'] != null)
			{   



				$('#Quote_Message_Log').text("Processing...");  
				var cf_simpro_quote_number = data['ticket.customFields']['Simpro Quote Number']; 
				//var cf_company_id = data['ticket.customFields']['simPRO Company Id']; 

				// if(cf_company_id != "")
				// {

				// var reqObj= {
				//      url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/quotes/'+cf_simpro_quote_number,
				//      headers : { 'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				//      type : 'GET',
				//      data : {},
				//      postBody : {},
				//      fileObj: [],
				// }   
				// // console.log(reqObj);
				// ZOHODESK.request( reqObj ).then(function(response)
				// {  

				// // console.log(response);
				// if(IsParsable(response)) {
				// 	var responseArr = JSON.parse(response); 
				// 	if(responseArr.statusCode == 401)
				// 	  	{
				// 	  		token_message();
				// 	  	}
				// 	var dataArrJson = responseArr.response; 
				// 	if(IsParsable(response)) {
				// 				var dataArr = JSON.parse(dataArrJson);
				// 				if(dataArr.errors != '' && dataArr.errors != undefined )
				// 				{ 
				// 					simproerrors = dataArr.errors;  
				// 					if(simproerrors.length > 0){

				// 				$('#Quote_Message_Log').text("");
				// 						for (var i = 0; i < simproerrors.length; i++) { 
				// 							$('#Quote_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
				// 						}
				// 						$("#quote_link").html("");   
				// 						$("#Quote_Number").val(""); 
				// 						hide_loader();   
				// 					}  
				// 				}
				// 				else{  
				// 							let results = dataArr;
				// 							if(results.hasOwnProperty('ID'))
				//               {
				//                 var quote_id = results.ID; 

				//                 let ticket_url = globarr.ticket_url; 
				//                 $('#Quote_Message_Log').text("Quote linked successfully.");  
				//                 quote_url =  "https://"+globarr.subdomainsimpro+".simprosuite.com/staff/editProject.php?quoteID="+quote_id;
				//                 $("#Quote_Number").val(quote_id);
				//                 $("#quote_link").text(quote_url);
				//                 $("#quote_link").attr("href",quote_url); 
				//                 $("#createQuote").css("display","none");  
				// 				getallquotenotes(globarr,'quotes',quote_id);
				//               }else{
				//                 $('#Quote_Message_Log').text("Quote not found.");
				//               }  
				//               hide_loader(); 
									
				// 				} 
				// 			} else{
				// 			  $('#Quote_Message_Log').text("Quote not found.");

				//               hide_loader();  
				// 		}
				// 	} else{
				// 		$('#Quote_Message_Log').text("Quote not found.");
				//               hide_loader(); 
				// 	}
				// }).catch(function(err){
				// 	////console.log(err);
                //     $('#Hidden_Message_Log').text(err); 
				//               hide_loader(); 
				// })  
				// }
				// else
				// {
					var listcompany = globarr.simprocompanylist;

					for (let i = 0; i < listcompany.length; i++)
					{
					globarr.breakpoint = false;
					var Company_id_current = listcompany[i].toString();
				//	console.log("company "+Company_id_current);

					  var reqObj= {
				     url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+Company_id_current+'/quotes/'+cf_simpro_quote_number,
				     headers : { 'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				     type : 'GET',
				     data : {},
				     postBody : {},
				     fileObj: [],
				}   
				 //console.log(reqObj+""+Company_id_current);
				var nm =  testnm(reqObj, globarr,Company_id_current);

				
				if(globarr.breakpoint == true)
				{

					console.log("globarr.breakpoint "+globarr.breakpoint);
				}

					}

				//}

			}
			else if(data['ticket.customFields']['Simpro Job Number'] != null)
			{
				show_loader();
				$('#Job_Message_Log').text("Processing...");  
				var cf_simpro_job_number = data['ticket.customFields']['Simpro Job Number']; 
				var reqObj= {
				     url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/jobs/'+cf_simpro_job_number,
				     headers : { 'Accept' : 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				     type : 'GET',
				     data : {},
				     postBody : {},
				     fileObj: [],
				}   
				ZOHODESK.request( reqObj ).then(function(response)
				{   
					if(IsParsable(response)) 
					{ 
						var responseArr = JSON.parse(response); 
						if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
						var dataArrJson = responseArr.response;  
						if(IsParsable(dataArrJson)) { 
							var dataArr = JSON.parse(dataArrJson);
							if(dataArr.errors != '' && dataArr.errors != undefined )
							{ 
								simproerrors = dataArr.errors;  
								$('#Job_Message_Log').text("");
								if(simproerrors.length > 0){
									for (var i = 0; i < simproerrors.length; i++) { 
										$('#Job_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
									}
									$("#job_link").html("");   
									$("#Job_Number").val("");
									hide_loader();   
								} 
							}
							else{ 
								let results = dataArr;
								var job_id = results.ID; 
		                    let ticket_url = globarr.ticket_url; 
								// createquotenote(globarr,'jobs',job_id);
		                    $('#Job_Message_Log').text("Job linked successfully.");
		                    job_url =  "https://"+globarr.subdomainsimpro+".simprosuite.com/staff/editProject.php?jobID="+job_id;
		                    $("#Job_Number").val(job_id);
		                    $("#job_link").text(job_url);
		                    $("#job_link").attr("href",job_url); 
		                   // $("#createJob").css("display","none"); 
		                    job_number_button_change(job_id,job_url);

		                    getallquotenotes(globarr,'jobs',job_id);

								
								} 
						}else{
							$('#Job_Message_Log').text("Job not found.");

				              hide_loader();  
						} 
					}else{
						$('#Job_Message_Log').text("Job not found.");

				              hide_loader(); 
					}
					}).catch(function(err){ 
						////console.log(err);
                        $('#Hidden_Message_Log').text(err);

				              hide_loader(); 
					})  
			}
		}) 


		App.instance.on('ticket.comment', function (data)
		{
			console.log("Tickt nachi added");
			runWithDelay(globarr);
		})
 



		
		
		function addMessageOnError(default_project_type,multi_company,logmesg)
		{
 
				// default_project_type = default_project_type.toLowerCase();
				// if(default_project_type != "service" && default_project_type != "project")
				// {
				// 	$('#'+logmesg).text("Please check the value for project type in configuration settings... Please set only the values Service Or Project"); 
				// 	hide_loader();
				// 	hide_jobloader();
				// 	return false; 
				// } 
 
				multi_company = multi_company.toLowerCase();
				if(multi_company != "yes" && multi_company != "no")
				{  
				$('#'+logmesg).text("Please check the value for multi_company value in configuration settings... Please set only the values Yes Or No"); 
					hide_loader();
					hide_jobloader();
					return false;
				}   
				return true;
		}
		function isJson(str) 
		{
		    try {
		        JSON.parse(str);
		    } catch (e) {
		        return false;
		    }
		    return true;
		}

		function isJsonString(str) 
		{
		    try {
		        JSON.parse(str);
		    } catch (e) {
		        return false;
		    }
		    return true;
		}


		function token_message()
		{ 
			ZOHODESK.showpopup({ 
			    title : "Alert Message",
			    content: "Invalid api key! or please check your config settings properly!", 
			    type : "alert",
			    contentType : "html", 
			    color : "red", 
			    okText : "Close",
			    cancelText : ""
			}).then(res=>{ 
			    ////console.log("success");  
			    return; 
			},(err)=>{
			    ////console.log(err); 
			}); 
			return;  
		}

		
		function createcustomerinzoho(pushdata,module_name)
		{	
			var ext = localStorage.getItem("domain_extension"); 
			var jreqObj= { 
		     url : 'https://www.zohoapis.'+ext+'/crm/v2/'+module_name,
		      headers : { 'Content-Type' : 'application/json' },
		      type : 'POST',
		      data : {},
		      postBody : {"data":[pushdata]},
		      fileObj: [],
		      connectionLinkName: "zohocrmconnection"
			}
			ZOHODESK.request( jreqObj ).then(function(response)
			{
				//console.log(response);

			}).catch(function(err)
			{ 
				//console.log(err); 
			});
		}
		function createcustomerinsimpro(globarr,displaybox,operation)
		{
			//console.log(globarr); 
			// $('#'+displaybox).text("Creating Customer In Simpro..."); 
			var customerData = {}; 
			var customerDataForZoho = {}; 
			var Zoho_Customer_Id = $("#Zoho_Customer_Id").val();
			 if(globarr.crm_account_with_nosimpro_found == "yes")
			 {

			 	customerData.Email = globarr.crm_account_email; 
				customerData.Phone = globarr.crm_account_phone;  

				if(globarr.extension_fields == "Yes") 
				customerDataForZoho['szs__Email'] = globarr.crm_account_email; 
				else 
				customerDataForZoho['Email'] = globarr.crm_account_email; 

				customerDataForZoho.Phone = globarr.crm_account_phone;   
				var sentdata = {};  
				var module_name = "";
				var module_name = "";
				var default_customer_type_name = "";
					module_name = "Accounts";
					customerData.CompanyName = globarr.crm_account_name;
					customerDataForZoho.Account_Name = globarr.crm_account_name;
					default_customer_type_name = "companies";

				
								

			 }
			 else
			 {
				customerData.Email = globarr.email; 
				customerData.Phone = globarr.phone;  

				if(globarr.extension_fields == "Yes") 
				customerDataForZoho['szs__Email'] = globarr.email; 
				else 
				customerDataForZoho['Email'] = globarr.email; 

				customerDataForZoho.Phone = globarr.phone;   
				var sentdata = {};  
				var module_name = "";
				var module_name = "";
				var default_customer_type_name = "";
				let default_customer_type = globarr.default_customer_type;
		        default_customer_type = default_customer_type.toLowerCase();
			    if(default_customer_type == "company")
				{ 
					module_name = "Accounts";
					customerData.CompanyName = globarr.contactName;
					customerDataForZoho.Account_Name = globarr.contactName;
					default_customer_type_name = "companies";
				}
				else if(default_customer_type == "individual")
				{
					module_name = "Contacts";
					default_customer_type_name = "individuals";
					var flnameArr = globarr.contactName;
					flnameArr = flnameArr.split(" ");
					customerData.GivenName = flnameArr[0];
					customerDataForZoho.First_Name = flnameArr[0];

					if(flnameArr.length > 1){
						customerData.FamilyName = flnameArr[1]; 
						customerDataForZoho.FamilyName = flnameArr[1]; 
						customerDataForZoho.Last_Name = flnameArr[1]; 
					}
					else{
						customerData.FamilyName = flnameArr[0]; 	
						customerDataForZoho.Last_Name = flnameArr[0]; 	
					}

				}
				else
				{
					$('#'+displaybox).text("Please check your customers type configruation settings... Please set only Individual Or Company"); 
					hide_jobloader();
					return;
				}

			}

			  var reqObj= {
		      url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/customers/'+default_customer_type_name+'/',
		      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
		      type : 'POST',
		      data : {}, 
		      postBody : customerData,
			}
			ZOHODESK.request( reqObj ).then(function(response)
			{ 
				var responseArr = JSON.parse(response); 
				if(responseArr.statusCode == 401)
				  	{
				  		token_message();
				  	}
				var dataArrJson = responseArr.response; 
				var dataArr = JSON.parse(dataArrJson);
				if(dataArr.errors != '' && dataArr.errors != undefined )
				{ 
					simproerrors = dataArr.errors;  
					$('#'+displaybox).text("");
					if(simproerrors.length > 0){
						for (var i = 0; i < simproerrors.length; i++) { 
							$('#'+displaybox).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
						}  
						hide_jobloader();
					} 
				}
				else
				{
					simpro_customer_id = dataArr.ID;  
					globarr.simpro_customer_id = simpro_customer_id; 
					$("#Simpro_Customer_Id").val(globarr.simpro_customer_id);

					// test  

					if(simpro_customer_id == "")
					{
						$('#'+displaybox).text("Some Technical Error..."); 
						hide_jobloader();
					}
					else
					{


						//Simpro_Id
						//Customer_simPRO_ID
						// if(module_name == "Contacts")
						// {


						// pushdata = {};
						// pushdata[api_name] = Customer_simPRO_ID.toString();
						// }
						// else
						// {
						// 	pushdata = {};
						// pushdata[api_name] = Simpro_Id.toString();

						// }

						// var reqObj3= {
					    //   url : 'https://www.zohoapis.'+ext+'/crm/v8/'+module_name+'/'+Zoho_Customer_Id,
					    //   headers : { 'Content-Type' : 'application/json' },
					    //   type : 'PUT',
					    //   data : {},
					    //   postBody : {"data":[pushdata]},
					    //   fileObj: [],
					    //   connectionLinkName: "zohocrmconnection"
						// }  

						// 	ZOHODESK.request( reqObj3 ).then(function(response1)
						// 	{

						// 		//var responseArr = JSON.parse(response);
						// 		console.log("Inside********");
						// 		console.log(response1);
						// 		// var reload = "1";
						// 		// var dmessage = "Sync Successful! Please press the button again to create quote/job in simPRO.";
						// 		// modalPopup(reload,dmessage);
						// 	}).catch(function(err){
						// 		console.log(err);
						// 		$('#Hidden_Message_Log').text(err); 
						// 	})


						if(operation == "quote")
						{

						let tags =globarr.Simpro_Selected_Tag_Ids;
						let tagArray = tags.split(',');	
						processTags(tagArray,globarr,"Quote"); 

						//createquoteinfunction(globarr);
						}
						else if(operation == "job")
						{

						let tags =globarr.Simpro_Selected_Tag_Ids;
						let tagArray = tags.split(',');	
						processTags(tagArray,globarr,"Job");

						//createjobinfunction(globarr); 
						}
					}
				}
			}).catch(function(err)
			{ 
				//console.log(err); 
				var responseArr = JSON.parse(err); 
				if(responseArr.statusCode == 401)
				  	{
				  		token_message();
				  	}
				var dataArrJson = responseArr.response; 
				var dataArr = JSON.parse(dataArrJson);
				if(dataArr.errors != '' && dataArr.errors != undefined )
				{ 
					simproerrors = dataArr.errors;  
				$('#'+displaybox).text("");
					if(simproerrors.length > 0){
						for (var i = 0; i < simproerrors.length; i++) { 
							$('#'+displaybox).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
						}  
						hide_jobloader();
					} 
				}
			})  
		}
		
		function createquoteinfunction(globarr)
		{ 
			$('#Quote_Message_Log').append("Creating quote please wait.....");  

			var customerData  = {"AutoAdjustStatus":globarr.auto_adjust,"Site":parseInt(globarr.simpro_site_id),"Customer":parseInt(globarr.simpro_customer_id),"Description":globarr.description,"Type":globarr.default_project_type};  

			if(globarr.due_date) 
			customerData.DueDate = globarr.due_date;
			if(globarr.order_number)
			customerData.OrderNo = globarr.order_number

			// if (globarr.simpro_report_tag) {
			//   customerData.Tags = [parseInt(globarr.simpro_report_tag)];
			// }

			var All_Tag_Ids = $("#All_Tag_Ids").val();
			globarr.All_Tag_Ids = All_Tag_Ids;
 			//console.log("All_Tag_Ids - "+ All_Tag_Ids);

			if (All_Tag_Ids) {
			  var Tags_li = [All_Tag_Ids];
			  var Tags = Tags_li[0].split(',').map(Number);
			  customerData.Tags = Tags;

			}


			if(globarr.customer_contact_id != "" || globarr.customer_contact_id != undefined ||  globarr.customer_contact_id != null){
			    customerData.CustomerContact = globarr.customer_contact_id;
			  }

				/* updated code */
				var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/';

				var reqObj= {
				  url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/quotes/',
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'POST',
				  data : {}, 
				  postBody : customerData,
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{
						var responseArr = JSON.parse(response);
						if(responseArr.statusCode == 401)
						  	{
						  		token_message();
						  	}
						var dataArrJson = responseArr.response; 
						var quoteDataArr = JSON.parse(dataArrJson);    
						var messages="";
						if(responseArr.statusCode == 422 && quoteDataArr.errors != undefined && quoteDataArr.errors.length > 0)
						{
							simproerrors = quoteDataArr.errors; 
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Quote_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}   
								hide_loader(); 
							} 
						}
						else 
						{  
							var quote_id = quoteDataArr.ID; 
							globarr.quote_number = quote_id;
							// createquotenote(globarr,'quotes',quote_id);

							// var cusomter_id = quoteDataArr.Customer.ID; 
							// ZOHODESK.set('database', { 'key': globarr.tic_id, 'value': {'saved_simpro_customer_id': cusomter_id ,'quote_id' : quote_id,'company_id':globarr.default_company_id}}).then(function (response) {
							// //console.log(response);
							// }).catch(function (err) { 
							//  //console.log(err); 
							// })

							var CustomFieldsArr = quoteDataArr.CustomFields; 
							if(globarr.oppy_number != null)
							{    
								for (var i = 0; i < CustomFieldsArr.length; i++) 
								{
									if(CustomFieldsArr[i]['CustomField']['Name'] == "CRM Opportunity No")
									{  
										updateDeskTicketIdInSimpro(globarr,quote_id,CustomFieldsArr[i]['CustomField']['ID'],'quotes',"Quote_Message_Log",globarr.oppy_number);
									}               
									// if(CustomFieldsArr[i]['CustomField']['Name'] == "Followup Date" && globarr.followup_date != "")
									// {  
									// 	updateDeskTicketIdInSimpro(globarr,quote_id,CustomFieldsArr[i]['CustomField']['ID'],'quotes',"Quote_Message_Log",globarr.followup_date);
									// } 
								} 
							}
							var quote_url =  "https://"+globarr.subdomainsimpro+".simprosuite.com/staff/editProject.php?quoteID="+quoteDataArr.ID;
							$("#quote_link").html(quote_url); 
							$("#quote_link").attr("href",quote_url); 
							$("#Quote_Message_Log").html("Quote Created Successfully!");
							$("#Quote_Number").val(quoteDataArr.ID);  
							globarr.quote_number = quote_id; 
							var postedData = { "cf_simpro_quote_number":quoteDataArr.ID,"cf_simpro_company_id":globarr.default_company_id};
							var updateData = {"cf":postedData}; 

							if(globarr.simpro_cost_center != null)
							{
							create_costcenter(globarr,'quotes',quote_id);
							}
							getallquotenotes(globarr,'quotes',quote_id);
							updateticket(globarr.tic_id,updateData);		
						}
				}).catch(function(err){
					//console.log(err);
					$('#Hidden_Message_Log').text(err); 
				}) 

		}

		function fetch_quote_cost_center(globarr)
		{
			console.log("default comp id -"+ globarr.default_company_id);
		show_loader();  	
		//   url : baseurl+'api/v1.0/companies/'+globarr.company_id+'/setup/accounts/costCenters/',		
			var reqObj= 
			{
		      url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/setup/accounts/costCenters/',
		      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
		      type : 'GET',
				     data : {},
				     postBody : {},
				     fileObj: [],
			}

			ZOHODESK.request( reqObj ).then(function(response)
			{ 
				var responseArr = JSON.parse(response); 
				
				var dataArrJson = responseArr.response; 
				var dataArr = JSON.parse(dataArrJson);
				if(dataArr.length > 0)
				{
					for (var i = 0; i < dataArr.length; i++) {

					var  costcenter_name = dataArr[i].Name;
					var   costcenter_id = dataArr[i].ID;
					$('#Cost_Center').append($('<option></option>').val(costcenter_id).text(costcenter_name));
					}
				}

			}).catch(function(err)
			{
				//console.log(err);
				$('#Hidden_Message_Log').text(err); 
				var responseArr = JSON.parse(err); 
				if(responseArr.statusCode == 401)
				  	{
				  		token_message();
				  	}
				var dataArrJson = responseArr.response; 
				var dataArr = JSON.parse(dataArrJson);
				if(dataArr.errors != '' && dataArr.errors != undefined )
				{ 
					simproerrors = dataArr.errors;  
				$('#'+display_log).text("");
					if(simproerrors.length > 0){
						for (var i = 0; i < simproerrors.length; i++) { 
							$('#'+display_log).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
						}  
					hide_loader();
					} 
				}
			}) 

			show_jobloader();
			hide_loader();
			hide_jobloader();
		}

		function create_costcenter(globarr,module_name,quo_number)
		{ 
			 	var customerData1  = {};
				var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/';
				var reqObj= {
				  url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/'+module_name+'/'+quo_number+'/sections/',
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'POST',
				  data : {}, 
				  postBody : JSON.stringify(customerData1),
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{
						var responseArr = JSON.parse(response);						
						if(responseArr.statusCode == 401)
						  	{
						  		token_message();
						  	}
						
						var messages="";
						if(responseArr.statusCode == 422 )
						{
							var dataArrJson = responseArr.response; 
							var quoteDataArr = JSON.parse(dataArrJson);  
							simproerrors = quoteDataArr.errors; 
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Quote_Message_Log').html(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}   
								hide_loader(); 
							} 
						}
						else 
						{  
							var dataArrJson = responseArr.response; 
						var quoteDataArr = JSON.parse(dataArrJson); 

					var Simpro_Section_ID =  quoteDataArr.ID;
					globarr.Simpro_Section_ID = Simpro_Section_ID;
					if(Simpro_Section_ID != null)
					{

				var customerData1  = {"CostCenter":parseInt(globarr.simpro_cost_center)};
				var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/';
				var reqObj1= {
				  url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/'+module_name+'/'+quo_number+'/sections/'+Simpro_Section_ID+'/costCenters/',
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'POST',
				  data : {}, 
				  postBody : customerData1,
				}
				ZOHODESK.request( reqObj1 ).then(function(response)
				{
						var responseArr1 = JSON.parse(response);
						var responseArr = JSON.parse(response);
						if(responseArr.statusCode == 401)
						  	{
						  		token_message();
						  	}
						
						var messages="";
						if(responseArr.statusCode == 422 )
						{
							var dataArrJson = responseArr.response; 
							var quoteDataArr = JSON.parse(dataArrJson);  

							simproerrors = quoteDataArr.errors; 
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Quote_Message_Log').html(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}   
								hide_loader(); 
							} 
						}
						else 
						{  
							var dataArrJson = responseArr.response; 
							var quoteDataArr = JSON.parse(dataArrJson); 
							//$('#Quote_Message_Log').append("Quote Updated Successfully!");  
							hide_loader(); 
								
								
						}
				}).catch(function(err){
					//console.log(err);
					$('#Hidden_Message_Log').text(err); 
				}) 


					}
							
							
								
						}
				}).catch(function(err){
					console.log(err);
					$('#Hidden_Message_Log').text(err); 
				}) 

		}


		function fetch_quote_report_tag(globarr)
		{
		
			show_loader(); 
			var reqObj= 
			{
		      url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/setup/tags/projects/',
		      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
		      type : 'GET',
				     data : {},
				     postBody : {},
				     fileObj: [],
			}
			ZOHODESK.request( reqObj ).then(function(response)
			{ 
				var responseArr = JSON.parse(response); 
				var dataArrJson = responseArr.response; 
				var dataArr = JSON.parse(dataArrJson);
				if(dataArr.length > 0)
				{
					for (var i = 0; i < dataArr.length; i++) {
					var  reporttag_name = dataArr[i].Name;
					var   reporttag_id = dataArr[i].ID;
					$('#Report_Tag').append($('<option></option>').val(reporttag_id).text(reporttag_name));
					}
				}

			}).catch(function(err)
			{
				//console.log(err);
				$('#Hidden_Message_Log').text(err); 
				var responseArr = JSON.parse(err); 
				if(responseArr.statusCode == 401)
				  	{
				  		token_message();
				  	}
				var dataArrJson = responseArr.response; 
				var dataArr = JSON.parse(dataArrJson);
				if(dataArr.errors != '' && dataArr.errors != undefined )
				{ 
					simproerrors = dataArr.errors;  
				$('#'+display_log).text("");
					if(simproerrors.length > 0){
						for (var i = 0; i < simproerrors.length; i++) { 
							$('#'+display_log).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
						}  
					hide_loader();
					} 
				}
			}) 
			show_jobloader();
			hide_loader();
			hide_jobloader();
		}

		$("#createQuote").click(function(e)
		{    


			show_loader();  
			e.preventDefault();  
			$('#Quote_Message_Log').text("Processing..."); 
			var Report_Tag = $("#Report_Tag").val();
			var Selected_Tags = $("#Selected_Tags").val();
			var Simpro_New_Tag_ids = $("#New_Tag_Ids").val(); 
			var Simpro_Selected_Tag_Ids = $("#Selected_Tag_Ids").val(); 


			globarr.simpro_report_tag = Report_Tag;	
			globarr.Simpro_Selected_Tag_Ids = Simpro_Selected_Tag_Ids;	
			globarr.Simpro_New_Tag_ids = Simpro_New_Tag_ids;



			var Cost_Center = $("#Cost_Center").val();			
			var default_project_type_new = $("#default_project_type_new").val(); 
			globarr.simpro_cost_center = Cost_Center;
			if(default_project_type_new != "Service")
			{
				globarr.simpro_cost_center = null;
			}

			var tic_id = $("#tic_id").val();  
			var email = $("#email").val();  
			// var Portal_User_ID = $("#Portal_User_ID").val();
			var due_date = $("#due_date").val();
			var order_number = $("#Order_Number").val();

			var  followup_date = $("#followup_date").val();  
			globarr.due_date = due_date;
			globarr.order_number = order_number;
			globarr.followup_date = followup_date;

			var Simpro_Customer_Id = $("#Simpro_Customer_Id").val();
			var Zoho_Customer_Id = $("#Zoho_Customer_Id").val();
			var Simpro_Site_Id = $("#Simpro_Site_Id").val();
			var Default_Site_ID = $("#Default_Site_ID").val();
			var Sync_To_Quotes = $("#Sync_To_Quotes").val();
			var Oppy_Number = $("#Oppy_Number").val();

			var default_project_type_new = $("#default_project_type_new").val(); 
			globarr.default_project_type = default_project_type_new;

			if(Sync_To_Quotes == "No")
			  Oppy_Number = "";
			if(Oppy_Number != "")
					globarr.oppy_number = Oppy_Number; 
				else 
					globarr.oppy_number = null; 
			var Simpro_Domain_Prefix = $("#Simpro_Domain_Prefix").val();
			var description = $("#description").val();
			globarr.description = description; 
			var module_name = $("#module_name").val();
			
			var multi_company = $("#Multi_Company").val();    
			var res_check = addMessageOnError(projectType,multi_company,"Quote_Message_Log"); 
			if(!res_check)return; 
			if(projectType == "")
			projectType = "Service";
			var company_id = $("#simpro_company_id").val();   
			//var auto_adjust = $("#Auto_Adjust").val(); 
			var auto_adjust = true;
			globarr.auto_adjust = auto_adjust;
			globarr.simpro_customer_id = Simpro_Customer_Id;
			if(Simpro_Site_Id == "") 
				globarr.simpro_site_id = globarr.default_site_id; 
			else
			globarr.simpro_site_id =  Simpro_Site_Id;
			if(Zoho_Customer_Id == "")
			{ 
				if(globarr.quote_number != "" && globarr.simpro_ustomer_id_for_quote != null)
				{
					globarr.simpro_customer_id = globarr.simpro_ustomer_id_for_quote;
				}
				else
				{
					$("#Quote_Message_Log").text("Creating Customer In Simpro..."); 
					if(Simpro_Customer_Id == "" && globarr.create_customer == false)
					{ 
						$("#Simpro_Customer_Id").val(globarr.default_customer_id); 
						Simpro_Customer_Id = globarr.default_customer_id;
						globarr.simpro_customer_id = globarr.default_customer_id;
						Simpro_Customer_Id = globarr.default_customer_id;
					}else if(Simpro_Customer_Id == "" && globarr.create_customer == true){ 
						createcustomerinsimpro(globarr,"Quote_Message_Log","quote");  
					} 
				}
			}
			if(globarr.simpro_customer_id == "" && Zoho_Customer_Id != "")
			{
				if(globarr.quote_number != "" && globarr.simpro_ustomer_id_for_quote != null)
				{
					globarr.simpro_customer_id = globarr.simpro_ustomer_id_for_quote;
				}
				else
				{
					

					displaySuccess("Customer found in Zoho but not in simPRO! Please sync the customer details to simPRO then try to create quote again.");
					$("#Quote_Message_Log").text("Customer found in Zoho but not in simPRO! Please sync the customer details to simPRO then try to create quote again.");  
					createcustomerinsimpro(globarr,"Quote_Message_Log","quote");
				}
			}
			else if (globarr.simpro_customer_id != "")
			{   

				let tags =globarr.Simpro_Selected_Tag_Ids;
						let tagArray = tags.split(',');	

						processTags(tagArray,globarr,"Quote"); 

				//createquoteinfunction(globarr);
				/* updated code */
			}  

		});

		$("#refreshSite").click(function(e)
		{

			show_loader(); 
 			$("#Simpro_Site_name_val").empty();
			default_site_name_check(globarr);
			seachcustomerincontact(globarr);
			      show_jobloader();



		});


	$("#datafetch").click(function(e)
		{
		show_loader(); 

		ZOHODESK.get('ticket').then(function (res) 
			{  
				console.log(res);

								console.log("888888888");
								//cf_simpro_company_id
								//cf_simpro_company_id
								//cf_simpro_job_number
								//cf_simpro_quote_number


// 								cf_simpro_company_id
// : 
// null
// cf_simpro_job_number
// : 
// null
// cf_simpro_quote_number
// : 
// null

			
			// quo_status = res.ticket.status; 

			// quo_number = res.ticket.cf.cf_simpro_quote_number; 
			// job_number = res.ticket.cf.cf_simpro_job_number; 

			


	}).catch(function (res) {
		//error Handling
		hide_loader();
	});  
  	


		});
		


		$("#default_project_type_new").click(function(e)
		{

			show_loader(); 
 			
				var default_project_type_new = $("#default_project_type_new").val(); 
				if(default_project_type_new == "Project")
				{
					
		$("#Simpro_Type_Cost_Center_Block").css("display","none");  
	
				}
				else
				{

					$("#Simpro_Type_Cost_Center_Block").css("display","block"); 

				}

			globarr.default_project_type = default_project_type_new;

 			hide_loader();



		});

		

		$("#updatestatus").click(function(e)
		{
			var reqObj= 
			{
		      url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/setup/statusCodes/projects/',
		      headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
		      type : 'GET',
				     data : {},
				     postBody : {},
				     fileObj: [],
			}

			ZOHODESK.get('ticket').then(function (res) 
			{  
			
			quo_status = res.ticket.status; 

			quo_number = res.ticket.cf.cf_simpro_quote_number; 
			job_number = res.ticket.cf.cf_simpro_job_number; 

			ZOHODESK.request( reqObj ).then(function(response)
			{ 
				var responseArr = JSON.parse(response); 
				if(responseArr.statusCode == 401)
				{
				  	token_message();
				}
				var dataArrJson = responseArr.response; 
				var dataArr = JSON.parse(dataArrJson);
				
				var simpro_status_id = "";
				if(dataArr.length > 0)
				{
					for (var i = 0; i < dataArr.length; i++) { 
					var  quo_status_name = dataArr[i]['Name'];
					var  quo_status_id = dataArr[i]['ID'];

					//console.log(quo_status_name+" - "+quo_status_id);
					if((quo_status_name == quo_status)){  
					var simpro_status_id = quo_status_id;
					break;
					}
					}

					if(simpro_status_id != "")
					{ 
					globarr.simpro_status_code = simpro_status_id;
					
					if(job_number == null)
					{
					$('#Quote_Message_Log').text("Updating quote please wait.....");  
					quotestatusupdate(globarr,quo_number);
					}
					else
					{
						$('#Job_Message_Log').text("Updating Job please wait.....");  
					jobstatusupdate(globarr,job_number);
					}	

					}

					else
					{

					if(job_number == null)
					{
						$('#Quote_Message_Log').append("The Zoho Desk status does not match with a simPRO Status. Please change to another status and retry");  
					}
					else
					{
						$('#Job_Message_Log').append("The Zoho Desk status does not match with a simPRO Status. Please change to another status and retry");  
					}

					}
				}

				
			}).catch(function(err)
			{
				//console.log(err);
				$('#Hidden_Message_Log').text(err); 
				var responseArr = JSON.parse(err); 
				if(responseArr.statusCode == 401)
				  	{
				  		token_message();
				  	}
				var dataArrJson = responseArr.response; 
				var dataArr = JSON.parse(dataArrJson);
				if(dataArr.errors != '' && dataArr.errors != undefined )
				{ 
					simproerrors = dataArr.errors;  
				$('#'+display_log).text("");
					if(simproerrors.length > 0){
						for (var i = 0; i < simproerrors.length; i++) { 
							$('#'+display_log).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
						}  
					hide_loader();
					} 
				}
			}) 



	}).catch(function (res) {
		//error Handling
		hide_loader();
	});  


		});


		$("#updateTimeLine").click(function(e)
		{

			show_loader(); 

//seachcustomerincontact(globarr);
			//ticket_data_details(globarr);
			simpro_note_data_details(globarr);
	        show_jobloader();



		});



		function quotestatusupdate(globarr,quo_number)
		{ 
			
			
			 var customerData  = {"Status":globarr.simpro_status_code,"AutoAdjustStatus":false};
				/* updated code */
				var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/';
				var reqObj= {
				  url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/quotes/'+quo_number,
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'PATCH',
				  data : {}, 
				  postBody : customerData,
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{
						var responseArr = JSON.parse(response);
						if(responseArr.statusCode == 401)
						  	{
						  		token_message();
						  	}
						
						var messages="";
						if(responseArr.statusCode == 422 )
						{
							var dataArrJson = responseArr.response; 
							var quoteDataArr = JSON.parse(dataArrJson);  

							simproerrors = quoteDataArr.errors; 
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Quote_Message_Log').html(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}   
								hide_loader(); 
							} 
						}
						else 
						{  
							
							$('#Quote_Message_Log').append("Quote Updated Successfully!");  
							hide_loader(); 
							update_status(quo_number);
								
						}
				}).catch(function(err){
					//console.log(err);
					$('#Hidden_Message_Log').text(err); 
				}) 

		}
		function jobstatusupdate(globarr,job_number)
		{ 
			
			
			 var customerData  = {"Status":globarr.simpro_status_code,"AutoAdjustStatus":false};
				/* updated code */
				var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/';


				var reqObj= {
				  url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/jobs/'+job_number,
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'PATCH',
				  data : {}, 
				  postBody : customerData,
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{
						var responseArr = JSON.parse(response);
						//console.log(responseArr);
					
						if(responseArr.statusCode == 401)
						  	{
						  		token_message();
						  	}
						
						var messages="";
						if(responseArr.statusCode == 422 )
						{
							var dataArrJson = responseArr.response; 
						var quoteDataArr = JSON.parse(dataArrJson); 
					
							simproerrors = quoteDataArr.errors; 
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#Job_Message_Log').html(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
								}   
								hide_loader(); 
							} 
						}
						else 
						{  
							
							$('#Job_Message_Log').append("Job Updated Successfully!");  
							hide_loader(); 
							update_status(quo_number);
								
						}
				}).catch(function(err){
					console.log(err);
					$('#Hidden_Message_Log').text(err); 
				}) 

		}

		function updateDeskTicketIdInSimpro(globarr,cf_simpro_quote_number,simpro_ticket_field_id,module_name,displaybox,updated_value)
		{
			var pushArr = {}; 
			pushArr.Value = updated_value; 
			var reqObj= {
			     url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/'+module_name+'/'+cf_simpro_quote_number+'/customFields/'+simpro_ticket_field_id,
			     headers : { 'Content-Type' : 'multipart/form-data', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
			     type : 'PATCH',
			     data : {},
			     postBody : JSON.stringify(pushArr),
			     fileObj: [],
			}   
			ZOHODESK.request( reqObj ).then(function(response)
			{ 
				hide_loader();   
				var responseArr = JSON.parse(response); 
				if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
				if(responseArr.statusCode == 204)
				{
					$('#'+displaybox).append("\n Oppy Number synched successfully in simpro");
				}

				if(responseArr.response != "")
				{
					var dataArrJson = responseArr.response; 
					var dataArr = JSON.parse(dataArrJson);

						if(dataArr.errors != '' && dataArr.errors != undefined )
						{ 
							simproerrors = dataArr.errors;   
							if(simproerrors.length > 0){
								for (var i = 0; i < simproerrors.length; i++) { 
									$('#'+displaybox).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
									$('#'+displaybox).append("\n Unable to link Oppy Number to simPRO record.");
								} 
							} 
						}
						else
						{
							$('#'+displaybox).append("\n Oppy Number Synched Successfully");
						} 
				}
			}).catch(function(err){
				//console.log(err);
				// $('#Hidden_Message_Log').text(err); 
			}) 
		}

		function hidden_logs(err)
		{ 
				//console.log(err);
		}
		function displayErrors(err)
		{ 
			var errArr = JSON.parse(err);
			if(errArr.statusCode == 500)
			{
				ZOHODESK.notify({
				    title : "Notification",
				    content : "Server gets overloaded! Please reload your extension and try again.", 
				    icon:"failure", 
				    autoClose:"false"
				}); 
			}
			hidden_logs(err) 
		}

		function displayErrorMessage(message)
		{  
			ZOHODESK.notify({
			    title : "Notification",
			    content : message, 
			    icon:"failure", 
			    autoClose:"false"
			});  
		}
		function displaySuccess(message)
		{  
			
			ZOHODESK.notify({
			    title : "Notification",
			    content : message, 
			    icon:"success", 
			    autoClose:"true"
			});   
		}

		function createjobinfunction(globarr)
		{ 

			var customerData = {};
			customerData.Customer = parseInt(globarr.simpro_customer_id); 
			customerData.Type = globarr.default_project_type;
			customerData.AutoAdjustStatus = true;


			if(globarr.due_date) 
			customerData.DueDate = globarr.due_date;

			if(globarr.order_number)
			customerData.OrderNo = globarr.order_number;
			// if(globarr.followup_date) 
			// customerData.followup_date = globarr.followup_date; 

			// if (globarr.simpro_report_tag) {
			//   customerData.Tags = [parseInt(globarr.simpro_report_tag)];
			// }

			var All_Tag_Ids = $("#All_Tag_Ids").val();
			globarr.All_Tag_Ids = All_Tag_Ids;
 			//console.log("All_Tag_Ids - "+ All_Tag_Ids);

			if (All_Tag_Ids) {
			  var Tags_li = [All_Tag_Ids];
			  var Tags = Tags_li[0].split(',').map(Number);
			  customerData.Tags = Tags;

			}

			customerData.Description = globarr.description;   
			customerData.Site = parseInt(globarr.simpro_site_id);  

			if(globarr.customer_contact_id != "" || globarr.customer_contact_id != undefined ||  globarr.customer_contact_id != null){
		    customerData.CustomerContact = globarr.customer_contact_id;
		  	}

			var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/';
		 	var quote_aim = "jobs";
		 	if(globarr.quote_number == "")
		 	{   
				var reqObj= {
				  url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/jobs/',
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'POST',
				  data : {}, 
				  postBody : customerData,
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{  
					processJobinSimpro(globarr,response);
						
				}).catch(function(err){
					//console.log(err);
                    $('#Hidden_Message_Log').text(err); 
				})   
			}
			else if(globarr.quote_number != "")
			{  
				$('#Job_Message_Log').text("Processing...Converting quote to job.");  

				var reqObj= {
				  url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/quotes/'+globarr.quote_number+'/convert/',
				  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
				  type : 'POST',
				  data : {}, 
				  postBody : customerData,
				}
				ZOHODESK.request( reqObj ).then(function(response)
				{  
					processJobinSimpro(globarr,response);
						
				}).catch(function(err){
					//console.log(err);
                  $('#Hidden_Message_Log').text(err); 
				})  

			} 
		}
	 
		$("#createJob").click(function(e)
		{   
			//console.log(globarr);
			e.preventDefault();  
			$('#Job_Message_Log').text("Processing...");  
			show_jobloader();

			var Report_Tag = $("#Report_Tag").val();
			var Selected_Tags = $("#Selected_Tags").val();
			var Simpro_New_Tag_ids = $("#New_Tag_Ids").val(); 
			var Simpro_Selected_Tag_Ids = $("#Selected_Tag_Ids").val(); 


			globarr.simpro_report_tag = Report_Tag;	
			globarr.Simpro_Selected_Tag_Ids = Simpro_Selected_Tag_Ids;	
			globarr.Simpro_New_Tag_ids = Simpro_New_Tag_ids;

			var Cost_Center = $("#Cost_Center").val();			
			var default_project_type_new = $("#default_project_type_new").val(); 
			globarr.simpro_cost_center = Cost_Center;
			if(default_project_type_new != "Service")
			{
				globarr.simpro_cost_center = null;
			}

			var tic_id = $("#tic_id").val();
			var email = $("#email").val();  
			// var Portal_User_ID = $("#Portal_User_ID").val();
			var due_date = $("#due_date").val();  
			var order_number = $("#Order_Number").val();  
			var followup_date = $("#followup_date").val();  
			var Simpro_Customer_Id = $("#Simpro_Customer_Id").val();
			var Zoho_Customer_Id = $("#Zoho_Customer_Id").val();
			var Simpro_Site_Id = $("#Simpro_Site_Id").val();
			var Default_Site_ID = $("#Default_Site_ID").val();
			var Oppy_Number = $("#Oppy_Number").val();

			var default_project_type_new = $("#default_project_type_new").val(); 
			globarr.default_project_type = default_project_type_new;
			
			if(Sync_To_Quotes == "No")
			  Oppy_Number = "";
			if(Oppy_Number != "")
					globarr.oppy_number = Oppy_Number;  
				else 
					globarr.oppy_number = null; 

			var Simpro_Domain_Prefix = $("#Simpro_Domain_Prefix").val();
			var description = $("#description").val();
			var module_name = $("#module_name").val();    
			var multi_company = $("#Multi_Company").val(); 
			var res_check = addMessageOnError(globarr.default_project_type,multi_company,"Quote_Message_Log"); 
			if(!res_check)return; 
			var company_id = $("#simpro_company_id").val(); 
			


			// updating global variables
			var auto_adjust = true;
			globarr.auto_adjust = auto_adjust;

			globarr.description = description; 
			globarr.due_date = due_date; 
			globarr.order_number = order_number;
			globarr.followup_date = followup_date; 
			globarr.simpro_customer_id = Simpro_Customer_Id;
			if(Simpro_Site_Id == "") 
				globarr.simpro_site_id = globarr.default_site_id; 
			else
			globarr.simpro_site_id =  Simpro_Site_Id; 
			
			var cf_simpro_quote_number = $("#Quote_Number").val();  
			globarr.quote_number = cf_simpro_quote_number; 

			if(Zoho_Customer_Id == "")
			{ 
				if(globarr.quote_number != "" && globarr.simpro_ustomer_id_for_quote != null)
				{
					globarr.simpro_customer_id = globarr.simpro_ustomer_id_for_quote;
				}
				else{  
					$("#Job_Message_Log").text("Creating Customer In Simpro...");  
					if(globarr.simpro_customer_id == "" && globarr.create_customer == false)
					{  
						$("#Simpro_Customer_Id").val(globarr.default_customer_id); 
						Simpro_Customer_Id = globarr.default_customer_id;
						globarr.simpro_customer_id = globarr.default_customer_id;
						Simpro_Customer_Id = globarr.default_customer_id;
					}else if(globarr.simpro_customer_id == "" && globarr.create_customer == true){ 
						createcustomerinsimpro(globarr,"Quote_Message_Log","job");  
					} 
				}
			}
			if(globarr.simpro_customer_id == "" && Zoho_Customer_Id != "")
			{
				if(globarr.quote_number != "" && globarr.simpro_ustomer_id_for_quote != null)
				{
					globarr.simpro_customer_id = globarr.simpro_ustomer_id_for_quote;
				}
				else
				{
					displaySuccess("Customer found in Zoho but not in simPRO! Please sync the customer details to simPRO then try to create job again.");
					$("#Job_Message_Log").text("Customer found in Zoho but not in simPRO! Please sync the customer details to simPRO then try to create job again.");  
				} 
			} 
			else if (globarr.simpro_customer_id != "")
			{  
				let tags =globarr.Simpro_Selected_Tag_Ids;
				let tagArray = tags.split(',');	

				processTags(tagArray,globarr,"Job");
 				//createjobinfunction(globarr); 
			} 
		}); 


		async function processTags(tagArray,globarr,module) {

			if(globarr.Simpro_Selected_Tag_Ids != "")
			{
				//console.log("inside tag createio");

				let finalList = [];
				let newtag_list = "";

			    for (let i = 0; i < tagArray.length; i++) {
			    let tag = tagArray[i];

			    // Trim spaces
			    let trimmed = tag.trim();

			    if (!isNaN(trimmed) && trimmed !== '') {
			        finalList.push(Number(trimmed));
			    } else {

			        var reportTagData = {};
			        reportTagData.Name = trimmed;
			        reportTagData.Archived = false;



			        var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/';
			        var reqObj = {
			            url: baseurl + 'api/v1.0/companies/' + globarr.default_company_id + '/setup/tags/projects/',
			            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + globarr.simpro_api_key },
			            type: 'POST',
			            data: {},
			            postBody: JSON.stringify(reportTagData),
			        };

			        try {
							    const response = await ZOHODESK.request(reqObj); // wait for request to finish
							    const responseArr = JSON.parse(response);

							    if (responseArr.statusCode == 401) {
							        token_message();
							    } else if (responseArr.statusCode == 422) {
							        const quoteDataArr = JSON.parse(responseArr.response);
							        simproerrors = quoteDataArr.errors;
							        if (simproerrors.length > 0) {
							            for (let j = 0; j < simproerrors.length; j++) {
							                $('#Quote_Message_Log').html(" " + simproerrors[j].path + "-" + simproerrors[j].message);
							            }
							            hide_loader();
							        }
							    } else {
							        const quoteDataArr = JSON.parse(responseArr.response);
							        const simpro_Tag_creation_Id = quoteDataArr.ID;

							        //console.log("simpro_Tag_creation_Id -" + simpro_Tag_creation_Id);

							        finalList.push(simpro_Tag_creation_Id);

							        // Append to newtag_list and store in globarr
							        newtag_list = newtag_list + "," + simpro_Tag_creation_Id;
							        globarr.newtag_list = newtag_list;
							    }
							} catch (err) {
							    console.log(err);
							    $('#Hidden_Message_Log').text(err);
							}
			    }
			}


			   // console.log("All tags processed:", finalList);
			    globarr.tagfinalList = finalList;

			$("#All_Tag_Ids").val(finalList);
		}

			if(module == "Quote")
			{
				createquoteinfunction(globarr);

			}
			else if(module == "Job")
			{
			createjobinfunction(globarr);  
			}

}
 

		function createquotenote(globarr,module_name,module_id)
		{  
 
			var quote_job_note = globarr.timeline_notes_quote;
			if(module_name == "quotes")
			quote_job_note = globarr.timeline_notes_quote;
			else 
			quote_job_note = globarr.timeline_notes_job; 
			var baseurl = 'https://{{subdomainsimpro}}.simprosuite.com/'; 
			var reqObj= {
			  url : baseurl+'api/v1.0/companies/'+globarr.default_company_id+'/'+module_name+'/'+module_id+'/notes/',
			  headers : { 'Content-Type': 'application/json', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
			  type : 'POST',
			  data : {}, 
			  postBody : quote_job_note,
			}
			ZOHODESK.request( reqObj ).then(function(response)
			{
			//console.log(response); 
			}).catch(function(err){
				//console.log(err);
				// $('#Hidden_Message_Log').text(err); 
			}) 
		}

		

		function processJobinSimpro(globarr,response)
		{ 
			//console.log(response);
			var responseArr = JSON.parse(response);
			if(responseArr.statusCode == 401)
					  	{
					  		token_message();
					  	}
			var dataArrJson = responseArr.response; 
			var quoteDataArr = JSON.parse(dataArrJson);    
			var messages="";
			if(quoteDataArr.hasOwnProperty('errors') && quoteDataArr.errors != undefined  && quoteDataArr.errors.length > 0)
			{ 
				simproerrors = quoteDataArr.errors; 
				if(simproerrors.length > 0){
					for (var i = 0; i < simproerrors.length; i++) { 
						$('#Job_Message_Log').append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
					}    
				hide_jobloader();
				} 
			}
			else
			{
				////console.log(quoteDataArr);
				var job_id = quoteDataArr.ID; 
				// createquotenote(globarr,'jobs',job_id);
				if(globarr.quote_number != null){  
					var CustomFieldsArr = quoteDataArr.CustomFields; 
					for (var i = 0; i < CustomFieldsArr.length; i++) {
						if(CustomFieldsArr[i]['CustomField']['Name'] == "CRM Opportunity No")
						{  
							updateDeskTicketIdInSimpro(globarr,job_id,CustomFieldsArr[i]['CustomField']['ID'],'jobs',"Job_Message_Log",globarr.oppy_number); 
						}
						// if(CustomFieldsArr[i]['CustomField']['Name'] == "Followup Date" && globarr.followup_date != "")
						// {  
						// 	updateDeskTicketIdInSimpro(globarr,job_id,CustomFieldsArr[i]['CustomField']['ID'],'jobs',"Job_Message_Log",globarr.followup_date);
						// }  
					}  
				} 

				var quote_url =  "https://"+globarr.subdomainsimpro+".simprosuite.com/staff/editProject.php?jobID="+quoteDataArr.ID;
				$("#job_link").html(quote_url); 
				$("#job_link").attr("href",quote_url); 
				$("#Job_Message_Log").html("Job Created Successfully!");
				$("#Job_Number").val(quoteDataArr.ID);
				var postedData = { "cf_simpro_job_number":quoteDataArr.ID,"cf_simpro_company_id":globarr.default_company_id};
				var updateData = {"cf":postedData}; 
				//console.log("cost - "+globarr.simpro_cost_center);
				if(globarr.simpro_cost_center != null)
				{
				create_costcenter(globarr,'jobs',job_id);
				}
				
				getallquotenotes(globarr,'jobs',job_id);
				updateticket(globarr.tic_id,updateData);		
			} 
		}

		// $("#reporttag").click(function(e)
		// {

		// 	show_loader(); 
		// 	//get /api/v1.0/companies/{companyID}/setup/tags/projects/

		// 	var reqObj= 
		// 	{
		//       url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/setup/tags/projects/',
		//       headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
		//       type : 'GET',
		// 		     data : {},
		// 		     postBody : {},
		// 		     fileObj: [],
		// 	}
		// 	ZOHODESK.request( reqObj ).then(function(response)
		// 	{ 
		// 		var responseArr = JSON.parse(response); 
				
		// 		var dataArrJson = responseArr.response; 
		// 		var dataArr = JSON.parse(dataArrJson);

		// 		console.log(dataArr);

		// 		if(dataArr.length > 0)
		// 		{
		// 			for (var i = 0; i < dataArr.length; i++) {
		// 			var  reporttag_name = dataArr[i].Name;
		// 			var   reporttag_id = dataArr[i].ID;
		// 			$('#Report_Tag').append($('<option></option>').val(reporttag_id).text(reporttag_name));
		// 			}
		// 		}

		// 	}).catch(function(err)
		// 	{
		// 		//console.log(err);
		// 		$('#Hidden_Message_Log').text(err); 
		// 		var responseArr = JSON.parse(err); 
		// 		if(responseArr.statusCode == 401)
		// 		  	{
		// 		  		token_message();
		// 		  	}
		// 		var dataArrJson = responseArr.response; 
		// 		var dataArr = JSON.parse(dataArrJson);
		// 		if(dataArr.errors != '' && dataArr.errors != undefined )
		// 		{ 
		// 			simproerrors = dataArr.errors;  
		// 		$('#'+display_log).text("");
		// 			if(simproerrors.length > 0){
		// 				for (var i = 0; i < simproerrors.length; i++) { 
		// 					$('#'+display_log).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
		// 				}  
		// 			hide_loader();
		// 			} 
		// 		}
		// 	}) 

 			



		// });
		
		// $("#costcentre_btn").click(function(e)
		// {
		// 	//get /api/v1.0/companies/{companyID}/jobCostCenters/
		// 	show_loader();  			
		// 	var reqObj= 
		// 	{
		//       url : 'https://{{subdomainsimpro}}.simprosuite.com/api/v1.0/companies/'+globarr.default_company_id+'/quoteCostCenters/',
		//       headers : { 'Content-Type': 'application/json,charset=utf-8', 'Authorization' : 'Bearer '+globarr.simpro_api_key},
		//       type : 'GET',
		// 		     data : {},
		// 		     postBody : {},
		// 		     fileObj: [],
		// 	}

		// 	ZOHODESK.request( reqObj ).then(function(response)
		// 	{ 
		// 		var responseArr = JSON.parse(response); 
				
		// 		var dataArrJson = responseArr.response; 
		// 		var dataArr = JSON.parse(dataArrJson);

		// 		console.log(dataArr);

		// 		if(dataArr.length > 0)
		// 		{
		// 			for (var i = 0; i < dataArr.length; i++) {

		// 			//console.log( dataArr[i].ID);
		// 			var  costcenter_name = dataArr[i].CostCenter.Name;
		// 			var   costcenter_id = dataArr[i].CostCenter.ID;
		// 			//$('#Cost_Center').append($("<option></option>").attr("value", costcenter_id).text(costcenter_name));
		// 			$('#Cost_Center').append($('<option></option>').val(costcenter_id).text(costcenter_name));

		// 			}
		// 		}

		// 	}).catch(function(err)
		// 	{
		// 		//console.log(err);
		// 		$('#Hidden_Message_Log').text(err); 
		// 		var responseArr = JSON.parse(err); 
		// 		if(responseArr.statusCode == 401)
		// 		  	{
		// 		  		token_message();
		// 		  	}
		// 		var dataArrJson = responseArr.response; 
		// 		var dataArr = JSON.parse(dataArrJson);
		// 		if(dataArr.errors != '' && dataArr.errors != undefined )
		// 		{ 
		// 			simproerrors = dataArr.errors;  
		// 		$('#'+display_log).text("");
		// 			if(simproerrors.length > 0){
		// 				for (var i = 0; i < simproerrors.length; i++) { 
		// 					$('#'+display_log).append(" "+simproerrors[i].path+"-"+simproerrors[i].message);  
		// 				}  
		// 			hide_loader();
		// 			} 
		// 		}
		// 	}) 

		// 	show_jobloader();
		// 	hide_loader();
		// 	hide_jobloader();

		// });
		//default_project_type_new



	}).catch(function(err){
		//console.log(err);
		displayErrors(err);
	}) 

};


// var myKeyVals = { 'A1984' : 1, 'A9873' : 5}




